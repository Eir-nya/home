-- A basic encounter script skeleton you can copy and modify for your own creations.
currentstate = "NONE"
-- music = "shine_on_you_crazy_diamond" --Always OGG. Extension is added automatically. Remove the first two lines for custom music.
encountertext = "Poseur strikes a pose!" --Modify as necessary. It will only be read out in the action select screen.
nextwaves = {"rotating"}
wavetimer = math.huge
arenasize = {155, 130}

enemies = {
"poseur"
}

enemypositions = {
{0, 0}
}

sprites = {}
function EnteringState(newstate,oldstate) ; currentstate = newstate ; end
function Update()
	if Player.hp ~= ui.lasthp then
		ui.UpdateHP()
	end
	if currentstate == "ACTIONSELECT" or currentstate == "ENEMYDIALOGUE" then
		for i=1,4 do
			ui.CheckTouchingBox(ui.buttons[i])
		end
	end
	if ui.shaking then
		ui.updateShake()
	end
end

function EncounterStarting()
    -- If you want to change the game state immediately, this is the place.
	OnHitBG = CreateSprite("onhit")
	OnHitBG.Scale(0.6,0.6)
	OnHitBG.MoveTo(320 + 191,240 + 219)
	OnHit = CreateSprite("onhit")
	OnHit.Scale(0.6,0.6)
	OnHit.MoveTo(320 + 190,240 + 220)
	OnHit.color = {1,0,0}
	libraryBG = CreateSprite("rotational_collision_library")
	libraryBG.Scale(0.6,0.6)
	libraryBG.MoveTo(126,240+206)
	library = CreateSprite("rotational_collision_library")
	library.Scale(0.6,0.6)
	library.MoveTo(125,240+207)
	library.color = {1,0,0}
	ui = require "Libraries/fake ui"
	ui.UpdatePlayerLabels()
	ui.UpdateHPPos()
	ui.UpdateHP()
	enemies[1].Call("SetSprite","blank")
	local spritey = CreateSprite("poseur")
	spritey.MoveTo(320,346)
	table.insert(sprites, spritey)
	table.insert(sprites, OnHitBG)
	table.insert(sprites, OnHit)
	table.insert(sprites, libraryBG)
	table.insert(sprites, library)
end

function Shake(table)
	ui.Shake(table[1],table[2],table[3],table[4])
end

function DefenseEnding() --This built-in function fires after the defense round ends.
    encountertext = RandomEncounterText() --This built-in function gets a random encounter text from a random enemy.
end

function HandleSpare()
     State("ENEMYDIALOGUE")
end

function HandleItem(ItemID)
    BattleDialog({"Selected item " .. ItemID .. "."})
end