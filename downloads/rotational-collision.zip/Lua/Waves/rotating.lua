collision = require "rotational_collision"
rotator = CreateProjectile("Untitled",0,0)
rotator.sprite.Set("Untitled")
Player.MoveTo(0,-Arena.height/3,true)
Player.SetControlOverride(true)
box1 = CreateProjectile("UI/sq_white",0,200)
box1.sprite.Set("UI/sq_white")
box1.sprite.Scale(2,2)
box2 = CreateProjectile("UI/sq_white",0,200)
box2.sprite.Set("UI/sq_white")
box2.sprite.Scale(2,2)
box3 = CreateProjectile("UI/sq_white",0,200)
box3.sprite.Set("UI/sq_white")
box3.sprite.Scale(2,2)
box4 = CreateProjectile("UI/sq_white",0,200)
box4.sprite.Set("UI/sq_white")
box4.sprite.Scale(2,2)
box5 = CreateProjectile("UI/sq_white",0,200)
box5.sprite.Set("UI/sq_white")
box5.sprite.Scale(2,2)
box6 = CreateProjectile("UI/sq_white",0,200)
box6.sprite.Set("UI/sq_white")
box6.sprite.Scale(2,2)
box7 = CreateProjectile("UI/sq_white",0,200)
box7.sprite.Set("UI/sq_white")
box7.sprite.Scale(2,2)
box8 = CreateProjectile("UI/sq_white",0,200)
box8.sprite.Set("UI/sq_white")
box8.sprite.Scale(2,2)
positions = {}
Player.sprite.SendToTop()
function Update()
	if Input.Up > 0 then ; Player.MoveToAbs(Player.absx,Player.absy + 2,true) ; end
	if Input.Left > 0 then ; Player.MoveToAbs(Player.absx - 2,Player.absy,true) ; end
	if Input.Right > 0 then ; Player.MoveToAbs(Player.absx + 2,Player.absy,true) ; end
	if Input.Down > 0 then ; Player.MoveToAbs(Player.absx,Player.absy - 2,true) ; end
	if Input.Confirm == 1 and explodetimer == nil then
		explodetimer = 0
		Audio.Stop()
		for i=1,5 do ; Audio.PlaySound("evil revenge") ; end -- makes it more effective
		bg = CreateProjectileAbs("UI/sq_white",320,240)
		bg.sprite.Set("UI/sq_white")
		bg.sprite.Scale(320/2,240/2)
		bg.sprite.alpha = 0
		Player.sprite.SendToBottom()
		explodi = CreateProjectileAbs("spr_floweynuke_explosion_0",320,240)
		local table = {}
		for i=0,42 do
			table[i] = "spr_floweynuke_explosion_"..i
		end
		explodi.sprite.Scale(320/(170/3),240/(164/3))
		explodi.sprite.Set("spr_floweynuke_explosion_0")
		explodi.sprite.SetAnimation(table)
		explodi.sprite.SendToTop()
		Player.sprite.rotation = 0
		shake_table = {
		rotator,
		box1,
		box2,
		box3,
		box4,
		box5,
		box6,
		box7,
		box8,
		explodi
		}
		Encounter["parameters"] = {shake_table,16,6/15,{Arena.width,Arena.height}}
		Encounter.Call("Shake",Encounter["parameters"])
		Encounter["parameters"] = nil
	end
	
	if explodetimer ~= nil then
		explodetimer = explodetimer + 1
		if bg.sprite.alpha < 1 then ; bg.sprite.alpha = bg.sprite.alpha + 0.05 end
		if explodetimer == 45 then
			Player.Hurt(Player.hp)
		end
	end
	
	Player.sprite.rotation = Player.sprite.rotation + 0.005
	rotator.sprite.rotation = rotator.sprite.rotation + 0.5
	rotator.sprite.xscale = (math.sin(Time.time)/4) + 1
	rotator.MoveTo(math.cos(Time.time)*20,0)
	box1.MoveTo(collision.GetCorners(rotator)[1][1], collision.GetCorners(rotator)[1][2])
	box2.MoveTo(collision.GetCorners(rotator)[2][1], collision.GetCorners(rotator)[2][2])
	box3.MoveTo(collision.GetCorners(rotator)[3][1], collision.GetCorners(rotator)[3][2])
	box4.MoveTo(collision.GetCorners(rotator)[4][1], collision.GetCorners(rotator)[4][2])
	box1.sprite.color = collision.CheckCollision(Player,rotator) and {0,1,0} or {1,0,0}
	box2.sprite.color = collision.CheckCollision(Player,rotator) and {0,1,0} or {1,0,0}
	box3.sprite.color = collision.CheckCollision(Player,rotator) and {0,1,0} or {1,0,0}
	box4.sprite.color = collision.CheckCollision(Player,rotator) and {0,1,0} or {1,0,0}
	
	box5.MoveTo(rotator.x - rotator.sprite.width/2, rotator.y + rotator.sprite.height/2)
	box6.MoveTo(rotator.x + rotator.sprite.width/2, rotator.y - rotator.sprite.height/2)
	box7.MoveTo(rotator.x + rotator.sprite.width/2, rotator.y + rotator.sprite.height/2)
	box8.MoveTo(rotator.x - rotator.sprite.width/2, rotator.y - rotator.sprite.height/2)
	
	Encounter["library"].color = collision.CheckCollision(Player, rotator) and {0,1,0} or {1,0,0}
	if not hitting and Encounter["OnHit"].color ~= {1,0,0} then
		Encounter["OnHit"].color = {1,0,0}
		box5.sprite.color = {1,0,0}
		box6.sprite.color = {1,0,0}
		box7.sprite.color = {1,0,0}
		box8.sprite.color = {1,0,0}
	end
	hitting = false
	
	require "shake (goes in wave)"
end
function OnHit(bullet)
	if bullet == rotator then
		Encounter["OnHit"].color = {0,1,0}
		box5.sprite.color = {0,1,0}
		box6.sprite.color = {0,1,0}
		box7.sprite.color = {0,1,0}
		box8.sprite.color = {0,1,0}
		hitting = true
	end
end