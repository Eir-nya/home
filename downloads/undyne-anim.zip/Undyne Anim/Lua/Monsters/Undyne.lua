-- A basic monster script skeleton you can copy and modify for your own creations.
comments = {"Smells like the work\rof an enemy stand.", "Poseur is posing like his\rlife depends on it.", "Poseur's limbs shouldn't be\rmoving in this way."}
commands = {}
currentdialogue = {"[voice:v_undyne][effect:none]ALPHYS, [w:10]YOU LIED\nTO ME!!",
	"[voice:v_undyne][effect:none]FROM WHAT THE\nHUMAN TOLD ME,\n[w:10]ANIME ISN'T\nREAL!!",
	"[voice:v_undyne][effect:none]NGAAH! [w:10]MY\nWHOLE LIFE IS\nA LIE!!!!"}

sprite = "blank" --Always PNG. Extension is added automatically.
name = "Undyne"
hp = 1500
atk = 50
def = 20
check = "The heroine that NEVER\rgives up."
dialogbubble = "rightwide" -- See documentation for what bubbles you have available.
canspare = false
cancheck = true

-- Happens after the slash animation but before 
function HandleAttack(attackstatus)
    if attackstatus == -1 then
        -- player pressed fight but didn't press Z afterwards
    else
        -- player did actually attack
		SetSprite("undyne/hurt")
		Encounter["legs"].alpha = 0
		Encounter["pants"].alpha = 0
		Encounter["leftarm"].alpha = 0
		Encounter["armor"].alpha = 0
		Encounter["rightarm"].alpha = 0
		Encounter["hair"].alpha = 0
		Encounter["face"].alpha = 0
    end
end
 
-- This handles the commands; all-caps versions of the commands list you have above.
function HandleCustomCommand(command)
    if command == "ACT 1" then
        currentdialogue = {"Selected\nAct 1."}
    elseif command == "ACT 2" then
        currentdialogue = {"Selected\nAct 2."}
    elseif command == "ACT 3" then
        currentdialogue = {"Selected\nAct 3."}
    end
    BattleDialog({"You selected " .. command .. "."})
end