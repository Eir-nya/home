-- A basic encounter script skeleton you can copy and modify for your own creations.

music = "spear of justice"
encountertext = "Undyne attacks!"
nextwaves = {"bullettest_chaserorb"}
wavetimer = 4.0
arenasize = {155, 130}

enemies = {
"Undyne"
}

enemypositions = {
{-25, -10}
}

function Update()
	AnimateUndyne()
end

possible_attacks = {"bullettest_bouncy", "bullettest_chaserorb", "bullettest_touhou"}

function EncounterStarting()
    require "Animations/Undyne"
	Player.name = "ALPHYS"
	Player.lv = 8
	Player.hp = 99
end

function EnteringState(newstate,oldstate)
	if oldstate == "ATTACKING" then
		enemies[1].Call("SetSprite","blank")
		animtimer = 0
		legs.alpha = 1
		pants.alpha = 1
		leftarm.alpha = 1
		armor.alpha = 1
		rightarm.alpha = 1
		hair.alpha = 1
		face.alpha = 1
	end
end

function EnemyDialogueStarting()
    -- Good location for setting monster dialogue depending on how the battle is going.
end

function EnemyDialogueEnding()
    -- Good location to fill the 'nextwaves' table with the attacks you want to have simultaneously.
    -- This example line below takes a random attack from 'possible_attacks'.
    nextwaves = { possible_attacks[math.random(#possible_attacks)] }
end

function DefenseEnding() --This built-in function fires after the defense round ends.
end

function HandleSpare()
     State("ENEMYDIALOGUE")
end

function HandleItem(ItemID)
    BattleDialog({"Selected item " .. ItemID .. "."})
end