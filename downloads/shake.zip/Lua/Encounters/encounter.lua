currentstate = "NONE"
encountertext = "Poseur strikes a pose!"
nextwaves = {"bullettest_bouncy"}
wavetimer = 4.0
arenasize = {155, 130}

enemies = {
"poseur"
}

enemypositions = {
{0, 0}
}
sprites = {}
possible_attacks = {"bullettest_touhou","bullettest_bouncy","bullettest_chaserorb"}

function Update()
	-- DEBUG(sprites[1].isactive)
	if Player.hp ~= ui.lasthp then
		ui.UpdateHP()
	end
	if currentstate == "ACTIONSELECT" or currentstate == "ENEMYDIALOGUE" then
		for i=1,4 do
			ui.CheckTouchingBox(ui.buttons[i])
		end
	end
	if ui.shaking then
		ui.updateShake()
	end
end

function EncounterStarting()
	enemies[1].Call("SetSprite","blank")
	local spritey = CreateSprite("poseur")
	spritey.MoveTo(320,346)
	table.insert(sprites, spritey)
	Player.lv = math.random(1,20)
	Player.hp = 92
    ui = require "Libraries/fake ui"
	ui.UpdatePlayerLabels()
	ui.UpdateHPPos()
	ui.UpdateHP()
end

function Shake(table)
	ui.Shake(table[1],table[2],table[3],table[4])
end

function EnteringState(newstate,oldstate)
	currentstate = newstate
end

function EnemyDialogueStarting()
	enemies[1].Call("SetSprite","blank")
	sprites[1].alpha = 1
end

function EnemyDialogueEnding()
	nextwaves = { possible_attacks[ math.random(#possible_attacks) ] }
end

function DefenseEnding() --This built-in function fires after the defense round ends.
    encountertext = RandomEncounterText() --This built-in function gets a random encounter text from a random enemy.
end

function HandleSpare()
     State("ENEMYDIALOGUE")
end

function HandleItem(ItemID)
    BattleDialog({"Selected item " .. ItemID .. "."})
end