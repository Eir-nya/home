local self = {}
self.ArenaCover = {}
self.FakeArena = {}
self.defaultpositions = {}
self.shaking = false
self.shaketable = {}
self.shakeintensity = 0
self.shaketimer = 0

self.PlayerName = {}
self.PlayerLV = {}
self.lasthp = 0
self.color = {1.0,1.0,1.0}

self.mask = CreateSprite("uimask/mask")
self.mask.MoveTo(320,40)
self.hplabel = CreateSprite("UI/spr_hpname_0")
self.hplabel.SetPivot(0,0)
self.hplabel.color = self.color
self.hplabel.MoveTo(244,65)
self.l = CreateSprite("uimask/font/l")
self.l.color = self.color
self.l.SetPivot(0,0)
self.v = CreateSprite("uimask/font/v")
self.v.color = self.color
self.v.SetPivot(0,0)

self.buttons = {
{CreateSprite("UI/Buttons/fightbt_0"), hover = false, sprite = "UI/Buttons/fightbt_"},
{CreateSprite("UI/Buttons/actbt_0"), hover = false, sprite = "UI/Buttons/actbt_"},
{CreateSprite("UI/Buttons/itembt_0"), hover = false, sprite = "UI/Buttons/itembt_"},
{CreateSprite("UI/Buttons/mercybt_0"), hover = false, sprite = "UI/Buttons/mercybt_"}}
self.buttons[1][1].SetPivot(0,1)
self.buttons[1][1].MoveTo(32,48)
self.buttons[2][1].SetPivot(0,1)
self.buttons[2][1].MoveTo(185,48)
self.buttons[3][1].SetPivot(0,1)
self.buttons[3][1].MoveTo(345,48)
self.buttons[4][1].SetPivot(0,1)
self.buttons[4][1].MoveTo(500,48)

self.hp = {CreateSprite("uimask/font/0"), CreateSprite("uimask/font/0")}
self.hp[1].color = self.color
self.hp[1].SetPivot(0,0)
self.hp[2].color = self.color
self.hp[2].SetPivot(0,0)
self.slash = CreateSprite("uimask/font/slash")
self.slash.color = self.color
self.slash.SetPivot(0,0)
self.maxhp = {CreateSprite("uimask/font/0"),CreateSprite("uimask/font/0")}
self.maxhp[1].color = self.color
self.maxhp[1].SetPivot(0,0)
self.maxhp[2].color = self.color
self.maxhp[2].SetPivot(0,0)

self.redhp = CreateSprite("uimask/bar")
self.redhp.SetPivot(0,0)
self.redhp.color = {1.0,0.0,0.0}
self.redhp.MoveTo(275,60)
self.hpbar = CreateSprite("uimask/bar")
self.hpbar.SetPivot(0,0)
self.hpbar.SetAnchor(0,0)
self.hpbar.SetParent(self.redhp)
self.hpbar.MoveTo(0,0)
self.hpbar.color = {1.0,1.0,0.0}
function self.UpdatePlayerLabels()
	for k,v in pairs(self.PlayerName) do ; if not v.isactive then ; v.Remove() ; end ; end ; self.PlayerName = {}
	for k,v in pairs(self.PlayerLV) do ; if not v.isactive then ; v.Remove() ; end ; end ; self.PlayerLV = {}
	local nameoffset = 30
	for i=1,#Player.name do
		local letter = CreateSprite("uimask/font/"..string.sub(Player.name,i,i))
		letter.SetPivot(0,0)
		letter.color = self.color
		letter.MoveTo(nameoffset,62)
		nameoffset = nameoffset + letter.width + 3
		table.insert(self.PlayerName,letter)
	end
	nameoffset = nameoffset + 28
	self.l.MoveTo(nameoffset,62)
	nameoffset = nameoffset + 15
	self.v.MoveTo(nameoffset,62)
	nameoffset = nameoffset + 29
	for i=1,#tostring(Player.lv) do
		local number = CreateSprite("uimask/font/"..string.sub(tostring(Player.lv),i,i))
		number.color = self.color
		number.SetPivot(0,0)
		number.MoveTo(nameoffset,62)
		nameoffset = nameoffset + number.width + 3
		table.insert(self.PlayerLV,number)
	end
end
function self.UpdateHPPos()
	self.lasthp = Player.hp
	local offset = self.GetOffsetByLV()
	self.hp[1].MoveTo(offset,62)
	offset = offset + self.hp[1].width + 3
	self.hp[2].MoveTo(offset,62)
	offset = offset + self.hp[2].width + 3
	offset = offset + 14
	self.slash.MoveTo(offset,62)
	offset = offset + 29
	self.maxhp[1].MoveTo(offset,62)
	offset = offset + self.maxhp[1].width + 3
	self.maxhp[2].MoveTo(offset,62)
	offset = offset + self.maxhp[2].width + 3
	self.redhp.xscale = self.GetOffsetByLV(true)*1.2
end
function self.UpdateHP()
	self.hp[1].Set("uimask/font/"..math.floor(Player.hp/10))
	self.hp[2].Set("uimask/font/"..Player.hp%10)
	self.maxhp[1].Set("uimask/font/"..math.floor(self.GetOffsetByLV(true)/10))
	self.maxhp[2].Set("uimask/font/"..self.GetOffsetByLV(true)%10)
	self.hpbar.xscale = Player.hp*1.2
end
function self.GetOffsetByLV(maxhp)
	if maxhp == nil then
		local number = 308
		for i=1,Player.lv do
			local num = 0
			if i==2 or i==7 or i==12 or i==17 then
				num = 4
			elseif i==20 then
				num = 8
			else
				num = 5
			end
			number = number + num
		end
		return number
	else
		if Player.lv == 20 then
			return 99
		else
			return 16 + (Player.lv*4)
		end
	end
end
function self.CheckTouchingBox(box)
	if Player.absx + Player.sprite.width/2 >= box[1].x and Player.absx - Player.sprite.width/2 <= box[1].x + box[1].width and Player.absy + Player.sprite.height/2 >= box[1].y - box[1].height and not box["hover"] then
		box["hover"] = true
		box[1].Set(box["sprite"].."1")
		return true
	elseif (Player.absx + Player.sprite.width/2 < box[1].x or Player.absx - Player.sprite.width/2 > box[1].x + box[1].width or Player.absy + Player.sprite.height/2 < box[1].y - box[1].height) and box["hover"] then
		box["hover"] = false
		box[1].Set(box["sprite"].."0")
		return false
	end
end

function self.Shake(table,intensity,time,arenasize)
	self.shaking = true
	self.startingState = currentstate
	if table ~= nil then
		self.shaketable = table
	else
		self.shaketable = {}
	end
	if intensity ~= nil then
		self.shakeintensity = intensity
	else
		self.shakeintensity = 4
	end
	if time ~= nil then
		self.shaketimer = time*60
	else
		self.shaketimer = 8
	end
	self.shaketimermax = self.shaketimer
	self.bgmask = CreateSprite("UI/sq_white")
	self.bgmask.MoveTo(320,240)
	self.bgmask.Scale(320/2,240/2)
	self.bgmask.color = {0,0,0}
	self.fakebg = CreateSprite("bg")
	self.fakebg.MoveTo(320,240)
	self.fakebg.SendToBottom()
	self.bgmask.SendToBottom()
	if currentstate == "DEFENDING" and arenasize ~= nil and #arenasize > 0 then
		self.ArenaCover = {
		CreateProjectile("uimask/border",-arenasize[1]/2 - 2.5,0),
		CreateProjectile("uimask/border",0,arenasize[2]/2 + 2.5),
		CreateProjectile("uimask/border",arenasize[1]/2 + 2.5,0),
		CreateProjectile("uimask/border",0,-arenasize[2]/2 - 2.5)}
		self.ArenaCover[1].sprite.Set("uimask/border")
		self.ArenaCover[1].sprite.color = {0.0,0.0,0.0}
		self.ArenaCover[1].sprite.yscale = arenasize[2]/5
		self.ArenaCover[2].sprite.Set("uimask/border")
		self.ArenaCover[2].sprite.color = {0.0,0.0,0.0}
		self.ArenaCover[2].sprite.xscale = arenasize[1]/5 + 2
		self.ArenaCover[3].sprite.Set("uimask/border")
		self.ArenaCover[3].sprite.color = {0.0,0.0,0.0}
		self.ArenaCover[3].sprite.yscale = arenasize[2]/5
		self.ArenaCover[4].sprite.Set("uimask/border")
		self.ArenaCover[4].sprite.color = {0.0,0.0,0.0}
		self.ArenaCover[4].sprite.xscale = arenasize[1]/5 + 2
		
		self.FakeArena = {
		CreateProjectile("uimask/border",-arenasize[1]/2 - 2.5,0),
		CreateProjectile("uimask/border",0,arenasize[2]/2 + 2.5),
		CreateProjectile("uimask/border",arenasize[1]/2 + 2.5,0),
		CreateProjectile("uimask/border",0,-arenasize[2]/2 - 2.5)}
		self.FakeArena[1].sprite.Set("uimask/border")
		self.FakeArena[1].sprite.color = {1.0,1.0,1.0}
		self.FakeArena[1].sprite.yscale = arenasize[2]/5
		self.FakeArena[2].sprite.Set("uimask/border")
		self.FakeArena[2].sprite.color = {1.0,1.0,1.0}
		self.FakeArena[2].sprite.xscale = arenasize[1]/5 + 2
		self.FakeArena[3].sprite.Set("uimask/border")
		self.FakeArena[3].sprite.color = {1.0,1.0,1.0}
		self.FakeArena[3].sprite.yscale = arenasize[2]/5
		self.FakeArena[4].sprite.Set("uimask/border")
		self.FakeArena[4].sprite.color = {1.0,1.0,1.0}
		self.FakeArena[4].sprite.xscale = arenasize[1]/5 + 2
	end
	self.defaultpositions = {}
	for i=1,#self.PlayerName do
		self.defaultpositions[#self.defaultpositions + 1] = {self.PlayerName[i].x, self.PlayerName[i].y}
	end
	for i=1,#self.PlayerLV do
		self.defaultpositions[#self.defaultpositions + 1] = {self.PlayerLV[i].x,self.PlayerLV[i].y}
	end
	for i=1,#self.buttons do
		self.defaultpositions[#self.defaultpositions + 1] = {self.buttons[i][1].x,self.buttons[i][1].y}
	end
	for i=1,#self.hp do
		self.defaultpositions[#self.defaultpositions + 1] = {self.hp[i].x,self.hp[i].y}
	end
	self.defaultpositions[#self.defaultpositions + 1] = {self.slash.x,self.slash.y}
	for i=1,#self.maxhp do
		self.defaultpositions[#self.defaultpositions + 1] = {self.maxhp[i].x,self.maxhp[i].y}
	end
	self.defaultpositions[#self.defaultpositions + 1] = {self.hplabel.x,self.hplabel.y}
	self.defaultpositions[#self.defaultpositions + 1] = {self.redhp.x,self.redhp.y}
	self.defaultpositions[#self.defaultpositions + 1] = {self.l.x,self.l.y}
	self.defaultpositions[#self.defaultpositions + 1] = {self.v.x,self.v.y}
	if #self.FakeArena > 0 then ; for i=1,#self.FakeArena do
		self.defaultpositions[#self.defaultpositions + 1] = {self.FakeArena[i].x,self.FakeArena[i].y}
	end ; end
	self.countoffset = 17 + self.GetNumActiveSpriteInTable(self.PlayerName) + self.GetNumActiveSpriteInTable(self.PlayerLV)
	--[[if currentstate == "DEFENDING" then
		for i=1,#Encounter["sprites"] do ; if not Encounter["sprites"][i].isactive then
			DEBUG(i)
			self.defaultpositions["sprite "..i] = {Encounter["sprites"][i].x,Encounter["sprites"][i].y}
		end ; end
		-- DEBUG(self.defaultpositions["sprite 1"])
	else
		for i=1,#sprites do ; if not sprites[i].isactive then
			DEBUG(i)
			self.defaultpositions["sprite "..i] = {sprites[i].x,sprites[i].y}
		end ; end
	end]]--
	for i=1,#sprites do ; if not sprites[i].isactive then
		self.defaultpositions["sprite "..i] = {sprites[i].x,sprites[i].y}
	end ; end
	self.defaultpositions["player x"] = Player.absx
	self.defaultpositions["player y"] = Player.absy
	--[[local string = ""
	for k,v in pairs(self.defaultpositions) do
		string = string ..k.." "
	end
	DEBUG(string)]]--
end
function self.updateShake()
	if self.shaketimer > 0 then
		self.shaketimer = self.shaketimer - 1
		self.dist = (math.sin(self.shaketimer*2)*self.shakeintensity)*(self.shaketimer/self.shaketimermax)
		if math.random(1,2) == 2 then ; self.dist = self.dist * -1 ; end
		self.fakebg.MoveTo(320+self.dist,240+self.dist)
		local count = 0
		for i=1,#self.PlayerName do
			count = count + 1
			self.PlayerName[i].MoveTo(self.defaultpositions[count][1] - self.dist,self.defaultpositions[i][2] + self.dist)
		end
		for i=1,#self.PlayerLV do
			count = count + 1
			self.PlayerLV[i].MoveTo(self.defaultpositions[count][1] - self.dist,self.defaultpositions[count][2] + self.dist)
		end
		for i=1,#self.buttons do
			count = count + 1
			self.buttons[i][1].MoveTo(self.defaultpositions[count][1] - self.dist,self.defaultpositions[count][2] + self.dist)
		end
		for i=1,#self.hp do
			count = count + 1
			self.hp[i].MoveTo(self.defaultpositions[count][1] - self.dist,self.defaultpositions[count][2] + self.dist)
		end
		count = count + 1
		self.slash.MoveTo(self.defaultpositions[count][1] - self.dist,self.defaultpositions[count][2] + self.dist)
		for i=1,#self.maxhp do
			count = count + 1
			self.maxhp[i].MoveTo(self.defaultpositions[count][1] - self.dist,self.defaultpositions[count][2] + self.dist)
		end
		count = count + 1
		self.hplabel.MoveTo(self.defaultpositions[count][1] - self.dist,self.defaultpositions[count][2] + self.dist)
		count = count + 1
		self.redhp.MoveTo(self.defaultpositions[count][1] - self.dist,self.defaultpositions[count][2] + self.dist)
		count = count + 1
		self.l.MoveTo(self.defaultpositions[count][1] - self.dist,self.defaultpositions[count][2] + self.dist)
		count = count + 1
		self.v.MoveTo(self.defaultpositions[count][1] - self.dist,self.defaultpositions[count][2] + self.dist)
		count = count + 1
		if Player.absx - self.dist ~= self.defaultpositions["player x"] or Player.absy - self.dist ~= self.defaultpositions["player y"] then
			self.defaultpositions["player x"] = Player.absx - self.dist
			self.defaultpositions["player y"] = Player.absy - self.dist
		end
		Player.MoveToAbs(self.defaultpositions["player x"] + self.dist,self.defaultpositions["player y"] + self.dist,true)
		if #self.FakeArena > 0 then ; for i=1,#self.FakeArena do
			self.FakeArena[i].MoveTo(self.defaultpositions[count][1] + self.dist,self.defaultpositions[count][2] + self.dist)
			count = count + 1
		end ; end
		--[[if currentstate == "DEFENDING" then
			for i=1,#Encounter["sprites"] do ; if not Encounter["sprites"][i].isactive then
				Encounter["sprites"][i].MoveTo(self.defaultpositions["sprites "..i][1] + self.dist,self.defaultpositions["sprites "..i][2] + self.dist)
			end ; end
		else
			for i=1,#sprites do ; if not sprites[i].isactive then
				sprites[i].MoveTo(self.defaultpositions["sprites "..i][1] + self.dist,self.defaultpositions["sprites "..i][2] + self.dist)
			end ; end
		end]]--
		for i=1,#sprites do ; if not sprites[i].isactive then
			sprites[i].MoveTo(self.defaultpositions["sprite "..i][1] + self.dist, self.defaultpositions["sprite "..i][2] + self.dist)
			if sprites[i].x - self.dist ~= self.defaultpositions[i][1] or sprites[i].y - self.dist ~= self.defaultpositions[i][2] then
				self.defaultpositions["sprite "..i] = {sprites[i].x - self.dist,sprites[i].y - self.dist}
			end
		end ; end
	else
		self.shaking = false
		self.countoffset = nil
		self.dist = nil
		self.bgmask.Remove()
		self.fakebg.Remove()
		--[[if currentstate == "DEFENDING" then
			for i=1,#Encounter["sprites"] do ; if not Encounter["sprites"][i].isactive then
				Encounter["sprites"][i].MoveTo(self.defaultpositions["sprites "..i], self.defaultpositions["sprites "..i])
			end ; end
		else
			for i=1,#sprites do ; if not sprites[i].isactive then
				sprites[i].MoveTo(self.defaultpositions["sprites "..i], self.defaultpositions["sprites "..i])
			end ; end
		end]]--
		for i=1,#sprites do ; if not sprites[i].isactive then
			sprites[i].MoveTo(self.defaultpositions["sprite "..i][1],self.defaultpositions["sprite "..i][2])
		end ; end
		self.UpdatePlayerLabels()
		self.buttons[1][1].MoveTo(32,48)
		self.buttons[2][1].MoveTo(185,48)
		self.buttons[3][1].MoveTo(345,48)
		self.buttons[4][1].MoveTo(500,48)
		self.UpdateHPPos()
		self.hplabel.MoveTo(244,65)
		self.redhp.MoveTo(275,60)
		Player.MoveToAbs(math.floor(self.defaultpositions["player x"]), math.floor(self.defaultpositions["player y"]),true)
		if currentstate == self.startingState then Player.MoveToAbs(self.defaultpositions["player x"],self.defaultpositions["player y"],true) ; end
		for k,v in pairs(self.FakeArena) do ; if v.isactive then
			v.Remove()
		end ; end ; self.FakeArena = {}
		for k,v in pairs(self.ArenaCover) do ; if v.isactive then
			v.Remove()
		end ; end ; self.ArenaCover = {}
		self.defaultpositions = {}
	end
end
function self.GetNumActiveSpriteInTable(table)
	local count = 0
	for k,v in pairs(table) do
		if not v.isactive then -- because sprite
			count = count + 1
		end
	end
	return count
end
return self