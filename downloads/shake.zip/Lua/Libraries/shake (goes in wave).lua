if Encounter["ui"].shaking then
	local dist = Encounter["ui"].dist
	if #positions == 0 then
		for k,v in pairs(shake_table) do ; if v.isactive then
			positions[#positions + 1] = {v.x, v.y}
		end ; end
	else
		for k,v in pairs(shake_table) do ; if v.isactive and positions[k] ~= nil then
			v.Move(dist*Time.mult, dist*Time.mult)
			if v.x - dist ~= positions[k][1] or v.y - dist ~= positions[k][2] then
				positions[k][1] = v.x
				positions[k][2] = v.y
			end
		end ; end
	end
elseif not Encounter["ui"].shaking and #positions > 0 then
	positions = {}
	shake_table = {}
end