currentstate = "NONE"
encountertext = "Poseur strikes a pose!"
nextwaves = {"shake_test"} -- {"blaster_test"}
wavetimer = math.huge
arenasize = {155, 130}

enemies = {
"poseur"
}

enemypositions = {
{0, 0}
}
sprites = {}
possible_attacks = {"bullettest_touhou","bullettest_bouncy","bullettest_chaserorb"}--, "shake_test"}

function Update()
	--[[if Player.hp ~= ui.lasthp then
		ui.UpdateHP()
	end]]--
	if currentstate == "ACTIONSELECT" or currentstate == "ENEMYDIALOGUE" then
		for i=1,4 do
			ui.CheckTouchingBox(ui.buttons[i])
		end
	end
	if ui.shaking then
		ui.updateShake()
	end
end

function OnHit(bullet) ; end

function EncounterStarting()
	enemies[1].Call("SetSprite","blank")
	spritey = CreateProjectileAbs("poseur",320,346)
	table.insert(sprites, spritey)
	Player.lv = 19
	Player.hp = 92
    ui = require "Libraries/fake ui"
	ui.UpdatePlayerLabels()
	ui.UpdateHPPos()
	ui.UpdateHP()
end

function EnteringState(newstate,oldstate)
	currentstate = newstate
	if newstate == "ATTACKING" then
		enemies[1].Call("SetSprite","poseur")
		spritey.sprite.alpha = 0
	end
end

function EnemyDialogueStarting()
	enemies[1].Call("SetSprite","blank")
	sprites[1].sprite.alpha = 1
end

function EnemyDialogueEnding()
	-- nextwaves = { possible_attacks[ math.random(#possible_attacks) ] }
end

function DefenseEnding() --This built-in function fires after the defense round ends.
    encountertext = RandomEncounterText() --This built-in function gets a random encounter text from a random enemy.
	ui.CreateProjectiles()
end

function HandleSpare()
     State("ENEMYDIALOGUE")
end

function HandleItem(ItemID)
    BattleDialog({"Selected item " .. ItemID .. "."})
end