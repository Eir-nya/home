Player.SetControlOverride(true)
Encounter["parameters"] = {nil, 320, nil, 90}
Encounter.Call("Shake",Encounter["parameters"])
Encounter["parameters"] = nil
count = 0.75
mult = 0.5
function Update()
	local speed = 0
	if Input.Cancel > 0 then ; speed = 1 ; else ; speed = 2 ; end
	if Input.Up > 0 and Player.absy < 217 then
		Player.MoveToAbs(Player.absx,Player.absy + speed,true)
	elseif Input.Down > 0 and Player.absy > 104 then
		Player.MoveToAbs(Player.absx,Player.absy - speed,true)
	end
	if Input.Left > 0 and Player.absx - 12 > Encounter["ui"].FakeArena[1].absx then
		Player.MoveToAbs(Player.absx - speed,Player.absy,true)
	elseif Input.Right > 0 and Player.absx + 14 < Encounter["ui"].FakeArena[3].absx then
		Player.MoveToAbs(Player.absx + speed,Player.absy,true)
	end
	Audio.Volume(math.sin(Player.absx/320))
	if not Encounter["ui"].shaking and not debounce then
		for k,v in pairs(Encounter["ui"].PlayerName) do ; if v.isactive then ; v.Move(1280, 0) ; end ; end
		for k,v in pairs(Encounter["ui"].FakeArena) do ; if v.isactive then ; v.Move(1280, 0) ; end ; end
		for k,v in pairs(Encounter["ui"].PlayerLV) do ; if v.isactive then ; v.Move(1280, 0) ; end ; end
		for k,v in pairs(Encounter["ui"].buttons) do ; if v.isactive then ; v.Move(1280, 0) ; end ; end
		for k,v in pairs(Encounter["ui"].maxhp) do ; if v.isactive then ; v.Move(1280, 0) ; end ; end
		for k,v in pairs(Encounter["sprites"]) do ; if v.isactive then ; v.Move(1280, 0) ; end ; end
		for k,v in pairs(Encounter["ui"].hp) do ; if v.isactive then ; v.Move(1280, 0) ; end ; end
		Player.MoveTo(Player.x + 1280, Player.y + 0, true)
		Encounter["ui"].hplabel.Move(1280, 0)
		Encounter["ui"].krlabel.Move(1280, 0)
		Encounter["ui"].slash.Move(1280, 0)
		Encounter["ui"].redhp.Move(1280, 0)
		Encounter["ui"].hpbar.Move(1280, 0)
		Encounter["ui"].krbar.Move(1280,0)
		Encounter["ui"].bg.Move(1280, 0)
		Encounter["ui"].l.Move(1280, 0)
		Encounter["ui"].v.Move(1280, 0)
		mult = mult * 2
		debounce = true
	elseif debounce then
		debounce = nil
		Encounter["parameters"] = {4*mult, 640/math.ceil(mult*0.9), nil, 90}
		Encounter.Call("Shake",Encounter["parameters"])
		Encounter["parameters"] = nil
		if mult >= 4 then
			count = count + 0.5
			Audio.Pitch(count)
			if count > 3 and explodetimer == nil then
				explodetimer = 0
				for i=1,7 do ; Audio.PlaySound("evil revenge") ; end -- makes it more effective
				bg = CreateProjectileAbs("UI/sq_white",320,240)
				bg.sprite.Set("UI/sq_white")
				bg.sprite.Scale(320/2,240/2)
				bg.sprite.alpha = 0
				Player.sprite.SendToBottom()
				explodi = CreateProjectileAbs("spr_floweynuke_explosion_0",320,240)
				local table = {}
				for i=0,42 do
					table[i] = "spr_floweynuke_explosion_"..i
				end
				explodi.sprite.Scale(320/(170/3),240/(164/3))
				explodi.sprite.Set("spr_floweynuke_explosion_0")
				explodi.sprite.SetAnimation(table)
				explodi.sprite.SendToTop()
			end
		end
	end
	if explodetimer ~= nil then
		explodetimer = explodetimer + 1
		if bg.sprite.alpha < 1 then ; bg.sprite.alpha = bg.sprite.alpha + 0.05 end
		if explodetimer == 45 then
			Player.MoveToAbs(320,200,true)
			Player.Hurt(Player.hp)
		end
	end
end
function OnHit(bullet) ; end