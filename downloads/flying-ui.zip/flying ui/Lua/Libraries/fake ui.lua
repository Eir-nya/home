local self = {}
self.shaking = false
self.shakeintensity = 0
self.shaketimer = 0

self.PlayerName = {}
self.PlayerLV = {}
self.lasthp = 0

function self.CreateProjectiles()
	self.mask = CreateProjectileAbs("UI/sq_white",320,40)
	self.mask.sprite.Set("UI/sq_white")
	self.mask.sprite.color = {0,0,0}
	self.mask.sprite.Scale(320/2, 40/2)
	Player.sprite.SendToTop()
	self.hplabel = CreateProjectileAbs("UI/spr_hpname_0",236,69.5)
	self.krlabel = CreateProjectileAbs("uimask/kr",387,69.5)
	self.l = CreateProjectileAbs("uimask/font/l",139,69.5)
	self.v = CreateProjectileAbs("uimask/font/v",154,69.5)
	self.buttons = {CreateProjectileAbs("UI/Buttons/fightbt_0",87,27),
	CreateProjectileAbs("UI/Buttons/actbt_0",240,27),
	CreateProjectileAbs("UI/Buttons/itembt_0",400,27),
	CreateProjectileAbs("UI/Buttons/mercybt_0",555,27)}
	self.buttons[1].SetVar("sprite","UI/Buttons/fightbt_")
	self.buttons[2].SetVar("sprite","UI/Buttons/actbt_")
	self.buttons[3].SetVar("sprite","UI/Buttons/itembt_")
	self.buttons[4].SetVar("sprite","UI/Buttons/mercybt_")
	self.hp = {CreateProjectileAbs("uimask/font/9",420,69.5),
	CreateProjectileAbs("uimask/font/2",435,69.5)}
	self.slash = CreateProjectileAbs("uimask/font/slash",459,69.5)
	self.maxhp = {CreateProjectileAbs("uimask/font/9",488,69.5),
	CreateProjectileAbs("uimask/font/2",503,69.5)}
	self.redhp = CreateProjectileAbs("uimask/bar",257,62.5)
	self.redhp.sprite.Set("uimask/bar")
	self.redhp.sprite.SetPivot(0,0)
	self.redhp.sprite.xscale = 92*1.2
	self.redhp.sprite.color = {1,0,0}
	self.redhp.MoveToAbs(255,60)
	self.hpbar = CreateProjectileAbs("uimask/bar",257,62.5)
	self.hpbar.sprite.Set("uimask/bar")
	self.hpbar.sprite.SetPivot(0,0)
	self.hpbar.sprite.xscale = 92*1.2
	self.hpbar.sprite.color = {1,1,0}
	self.hpbar.MoveToAbs(255,60)
	self.krbar = CreateProjectileAbs("uimask/bar",257,62.5)
	self.krbar.sprite.Set("uimask/bar")
	self.krbar.sprite.SetPivot(0,0)
	self.krbar.sprite.xscale = 1.2
	self.krbar.sprite.color = {1,3/255,1}
	self.krbar.MoveToAbs(255 + (92*1.2), 60)
	
	self.mask.SetVar("safe",true)
	self.hplabel.SetVar("safe",true)
	self.krlabel.SetVar("safe",true)
	self.l.SetVar("safe",true)
	self.v.SetVar("safe",true)
	for i=1,#self.buttons do ; self.buttons[i].SetVar("safe",true) ; end
	for i=1,#self.hp do ; self.hp[i].SetVar("safe",true) ; end
	self.slash.SetVar("safe",true)
	for i=1,#self.maxhp do ; self.maxhp[i].SetVar("safe",true) ; end
	self.redhp.SetVar("safe",true)
	self.hpbar.SetVar("safe",true)
	self.krbar.SetVar("safe",true)
end

self.CreateProjectiles()

function self.UpdatePlayerLabels()
	for k,v in pairs(self.PlayerName) do ; if v.isactive then ; v.Remove() ; end ; end ; self.PlayerName = {}
	for k,v in pairs(self.PlayerLV) do ; if v.isactive then ; v.Remove() ; end ; end ; self.PlayerLV = {}
	local nameoffset = 36
	for i=1,#Player.name do
		local letter = CreateProjectileAbs("uimask/font/"..string.sub(Player.name,i,i),nameoffset,69.5)
		nameoffset = nameoffset + letter.sprite.width + 3
		table.insert(self.PlayerName,letter)
	end
	nameoffset = 182
	for i=1,#tostring(Player.lv) do
		local number = CreateProjectileAbs("uimask/font/"..string.sub(tostring(Player.lv),i,i),nameoffset,69.5)
		nameoffset = nameoffset + number.sprite.width + 4
		table.insert(self.PlayerLV,number)
	end
end
function self.UpdateHPPos()
	local offset = self.GetOffsetByLV() + 21
	self.hp[1].MoveToAbs(offset,69.5)
	offset = offset + self.hp[1].sprite.width + 3
	self.hp[2].MoveToAbs(offset,69.5)
	offset = offset + self.hp[2].sprite.width + 3
	offset = offset + 9
	self.slash.MoveToAbs(offset,69.5)
	offset = offset + 29
	self.maxhp[1].MoveToAbs(offset,69.5)
	offset = offset + self.maxhp[1].sprite.width + 3
	self.maxhp[2].MoveToAbs(offset,69.5)
	offset = offset + self.maxhp[2].sprite.width + 3
	self.redhp.sprite.xscale = self.GetOffsetByLV(true)*1.2
end
function self.UpdateHP()
	self.lasthp = Player.hp
	self.hp[1].sprite.Set("uimask/font/"..math.floor(Player.hp/10))
	self.hp[2].sprite.Set("uimask/font/"..Player.hp%10)
	self.maxhp[1].sprite.Set("uimask/font/"..math.floor(self.GetOffsetByLV(true)/10))
	self.maxhp[2].sprite.Set("uimask/font/"..self.GetOffsetByLV(true)%10)
	self.hpbar.sprite.xscale = Player.hp*1.2
end
function self.GetOffsetByLV(maxhp)
	if maxhp == nil then
		local number = 308
		for i=1,Player.lv do
			local num = 0
			if i==2 or i==7 or i==12 or i==17 then
				num = 4
			elseif i==20 then
				num = 8
			else
				num = 5
			end
			number = number + num
		end
		return number
	else
		if Player.lv == 20 then
			return 99
		else
			return 16 + (Player.lv*4)
		end
	end
end
function self.CheckTouchingBox(box)
	if Player.absx + Player.sprite.width/2 >= box.absx - box.sprite.width/2 and Player.absx - Player.sprite.width/2 <= box.absx + box.sprite.width/2 and Player.absy + Player.sprite.height/2 >= box.absy - box.sprite.height/2 and not box.GetVar("hover") then
		box.SetVar("hover",true)
		box.sprite.Set(box.GetVar("sprite").."1")
		return true
	elseif (Player.absx + Player.sprite.width/2 < box.absx - box.sprite.width/2 or Player.absx - Player.sprite.width/2 > box.absx + box.sprite.width/2 or Player.absy + Player.sprite.height/2 < box.absy - box.sprite.height/2) and box.GetVar("hover") then
		box.SetVar("hover",nil)
		box.sprite.Set(box.GetVar("sprite").."0")
		return false
	end
end

function Shake(table) -- (dist, time, arena, dir)
	self.shaking = true
	self.dist = 4 ; if table ~= nil and table[1] ~= nil then ; self.dist = math.floor(table[1]) ; end
	self.time = 2 ; if table ~= nil and table[2] ~= nil then ; self.time = math.floor(table[2]) ; end
	--[[
	arena format:
	{left edge pos relative to center, left edge height},
	{top edge pos relative to center, top edge width},
	{right edge pos relative to center, right edge height},
	{bottom edge pos relative to center, bottom edge width},
	arena x offset or nil,
	arena y offset or nil
	--]]
	self.arena = {{-(arenasize[1]/2), arenasize[2]},
	{arenasize[2]/2, arenasize[1]},
	{arenasize[1]/2, arenasize[2]},
	{-(arenasize[2]/2), arenasize[1]},
	0,
	0}
	if table ~= nil and table[3] ~= nil then
		if table[3][1] ~= nil then ; self.arena[1] = table[3][1] ; end
		if table[3][2] ~= nil then ; self.arena[2] = table[3][2] ; end
		if table[3][3] ~= nil then ; self.arena[3] = table[3][3] ; end
		if table[3][4] ~= nil then ; self.arena[4] = table[3][4] ; end
		if table[3][5] ~= nil then ; self.arena[5] = table[3][5] ; end
		if table[3][6] ~= nil then ; self.arena[6] = table[3][6] ; end
	end
	if self.ArenaCover == nil then
		self.ArenaCover = {
		CreateProjectile("uimask/border",self.arena[1][1] - 2.5, self.arena[6]),
		CreateProjectile("uimask/border",self.arena[5], (self.arena[2][1] + 2.5) + self.arena[6]),
		CreateProjectile("uimask/border",self.arena[3][1] + 2.5, self.arena[6]),
		CreateProjectile("uimask/border",self.arena[5], (self.arena[4][1] - 2.5) + self.arena[6])
		}
		for i=1,#self.ArenaCover do ; self.ArenaCover[i].sprite.Set("uimask/border") ; self.ArenaCover[i].sprite.color = {0,0,0} ; end
		self.ArenaCover[1].sprite.yscale = self.arena[1][2]/5 + 2
		self.ArenaCover[2].sprite.xscale = self.arena[2][2]/5
		self.ArenaCover[3].sprite.yscale = self.arena[3][2]/5 + 2
		self.ArenaCover[4].sprite.xscale = self.arena[4][2]/5
	end
	
	if self.FakeArena == nil then
		self.FakeArena = {
		CreateProjectile("uimask/border",self.arena[1][1] - 2.5, self.arena[6]),
		CreateProjectile("uimask/border",self.arena[5], (self.arena[2][1] + 2.5) + self.arena[6]),
		CreateProjectile("uimask/border",self.arena[3][1] + 2.5, self.arena[6]),
		CreateProjectile("uimask/border",self.arena[5], (self.arena[4][1] - 2.5) + self.arena[6])
		}
		for i=1,#self.FakeArena do ; self.FakeArena[i].sprite.Set("uimask/border") ; self.FakeArena[i].SetVar("safe",true) ; end
		self.FakeArena[1].sprite.yscale = self.arena[1][2]/5 + 2
		self.FakeArena[2].sprite.xscale = self.arena[2][2]/5
		self.FakeArena[3].sprite.yscale = self.arena[3][2]/5 + 2
		self.FakeArena[4].sprite.xscale = self.arena[4][2]/5
	end
	
	-- okay, this may or may not be the tricky part...
	-- I have to make it choose a random direction and move `self.dist` in that direction.
	
	self.dir = math.random(0,360) ; if table ~= nil and table[4] ~= nil then ; self.dir = table[4] ; end
	self.dist1 = math.sin(math.rad(self.dir))*self.dist
	self.dist2 = math.cos(math.rad(self.dir))*self.dist
	
	if self.bgcover == nil then
		self.bgcover = CreateSprite("UI/sq_white")
		self.bgcover.color = {0,0,0}
		self.bgcover.MoveTo(320,240)
		self.bgcover.Scale(320/2,240/2)
		self.bg = CreateProjectileAbs("bg",320,240)
		self.bg.SetVar("safe",true)
		self.bg.SendToBottom()
		self.bgcover.SendToBottom()
	end
	self.mask.SendToBottom()
	
	-- hey, that wasn't so bad!
	-- you know, I should stop leaving these comments
	-- yeah, you should
	-- I talk to myself a lot, but now it's leaking into my code, aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
	-----------------------------------------------------------------------------------------------------------------------------------------------------------
	-- and now we move everything by the distance, yaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaay
	-- this is going to be really time-consuming...here we go.
	
	for k,v in pairs(self.PlayerName) do ; if v.isactive then ; v.MoveTo(v.x + self.dist1, v.y + self.dist2) ; end ; end
	for k,v in pairs(self.PlayerLV) do ; if v.isactive then ; v.MoveTo(v.x + self.dist1, v.y + self.dist2) ; end ; end
	for k,v in pairs(self.buttons) do ; if v.isactive then ; v.MoveTo(v.x + self.dist1, v.y + self.dist2) ; end ; end
	for k,v in pairs(self.maxhp) do ; if v.isactive then ; v.MoveTo(v.x + self.dist1, v.y + self.dist2) ; end ; end
	for k,v in pairs(sprites) do ; if v.isactive then ; v.MoveTo(v.x + self.dist1, v.y + self.dist2) ; end ; end
	for k,v in pairs(self.hp) do ; if v.isactive then ; v.MoveTo(v.x + self.dist1, v.y + self.dist2) ; end ; end
	for k,v in pairs(self.FakeArena) do ; if v.isactive then ; v.Move(self.dist1, self.dist2) ; end ; end
	self.hplabel.MoveTo(self.hplabel.x + self.dist1, self.hplabel.y + self.dist2)
	self.krlabel.MoveTo(self.krlabel.x + self.dist1, self.krlabel.y + self.dist2)
	self.slash.MoveTo(self.slash.x + self.dist1, self.slash.y + self.dist2)
	self.redhp.MoveTo(self.redhp.x + self.dist1, self.redhp.y + self.dist2)
	self.hpbar.MoveTo(self.hpbar.x + self.dist1, self.hpbar.y + self.dist2)
	self.krbar.MoveTo(self.krbar.x + self.dist1,self.krbar.y + self.dist2)
	Player.MoveTo(Player.x + self.dist1, Player.y + self.dist2, true)
	self.bg.MoveTo(self.bg.x + self.dist1,self.bg.y + self.dist2)
	self.l.MoveTo(self.l.x + self.dist1, self.l.y + self.dist2)
	self.v.MoveTo(self.v.x + self.dist1, self.v.y + self.dist2)
	
	-- hey, that wasn't so bad.
	-- look, I even sorted them by line length, haha
	self.shaketimer = 0
	self.dist1 = self.dist1 * -1
	self.dist2 = self.dist2 * -1
	self.olddist1 = self.dist1
	self.olddist2 = self.dist2
	for i=1,#self.ArenaCover do ; self.ArenaCover[i].SendToBottom() ; self.ArenaCover[i].SetVar("safe",true) ; end
end
function self.updateShake()
	if self.shaketimer <= self.time then
		self.shaketimer = self.shaketimer + 1
		self.dist1 = self.olddist1 * (self.shaketimer/self.time) ; if self.shaketimer == self.time then ; self.dist1 = -self.olddist1 ; end
		self.dist2 = self.olddist2 * (self.shaketimer/self.time) ; if self.shaketimer == self.time then ; self.dist2 = -self.olddist2 ; end
		for k,v in pairs(self.PlayerName) do ; if v.isactive then ; v.MoveTo(v.x + self.dist1, v.y + self.dist2) ; end ; end
		for k,v in pairs(self.PlayerLV) do ; if v.isactive then ; v.MoveTo(v.x + self.dist1, v.y + self.dist2) ; end ; end
		for k,v in pairs(self.buttons) do ; if v.isactive then ; v.MoveTo(v.x + self.dist1, v.y + self.dist2) ; end ; end
		for k,v in pairs(self.maxhp) do ; if v.isactive then ; v.MoveTo(v.x + self.dist1, v.y + self.dist2) ; end ; end
		for k,v in pairs(sprites) do ; if v.isactive then ; v.MoveTo(v.x + self.dist1, v.y + self.dist2) ; end ; end
		for k,v in pairs(self.hp) do ; if v.isactive then ; v.MoveTo(v.x + self.dist1, v.y + self.dist2) ; end ; end
		for k,v in pairs(self.FakeArena) do ; if v.isactive then ; v.Move(self.dist1, self.dist2) ; end ; end
		self.hplabel.MoveTo(self.hplabel.x + self.dist1, self.hplabel.y + self.dist2)
		self.krlabel.MoveTo(self.krlabel.x + self.dist1, self.krlabel.y + self.dist2)
		self.slash.MoveTo(self.slash.x + self.dist1, self.slash.y + self.dist2)
		self.redhp.MoveTo(self.redhp.x + self.dist1, self.redhp.y + self.dist2)
		self.hpbar.MoveTo(self.hpbar.x + self.dist1, self.hpbar.y + self.dist2)
		self.krbar.MoveTo(self.krbar.x + self.dist1,self.krbar.y + self.dist2)
		Player.MoveTo(Player.x + self.dist1, Player.y + self.dist2, true)
		self.bg.MoveTo(self.bg.x + self.dist1,self.bg.y + self.dist2)
		self.l.MoveTo(self.l.x + self.dist1, self.l.y + self.dist2)
		self.v.MoveTo(self.v.x + self.dist1, self.v.y + self.dist2)
		
		-- LITERALLY COPIED AND PASTED WITH NO EFFORT XDDDDDD
		-- ok it's ascii art time 
		
		--[[
		       ██                        ██                 ████████████████████████████████
			     ██                    ██                   ████                          ████
				   ██                ██                     ████                            ████
				     ██            ██                       ████                              ████
					   ██        ██                         ████                              ████
					     ██    ██                           ████                              ████
						   ████                             ████                              ████
						 ██    ██                           ████                              ████
					   ██        ██                         ████                              ████
					 ██            ██                       ████                              ████
				   ██                ██                     ████                            ████
				 ██                    ██                   ████                          ████
			   ██                        ██                 ████████████████████████████████
				 HALF OF IT IS COPIED AND PASTED FROM THE TOP WITH NO EFFORT LOL
				 yeah yeah that will do it
		]]--
		if self.shaketimer == self.time then
			self.shaking = false
			self.olddist1 = nil
			self.olddist2 = nil
			self.dist1 = nil
			self.dist2 = nil
			self.shaketimer = nil
			self.time = nil
			self.dir = nil
			self.dist = nil
		end
	end
end
return self