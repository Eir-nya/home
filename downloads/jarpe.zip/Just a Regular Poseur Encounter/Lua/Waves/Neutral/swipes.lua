require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



timer = 0

function Update()
    timer = timer + 1
    
    if timer == 20 then
        swipe = CreateSprite("Waves/Neutral/slice_0", "Topper")
        swipe.MoveTo(Arena.x, Arena.y + (Arena.height/2))
        swipe.Scale(1.5, 1.5)
        swipe.SetAnimation({"slice_0", "slice_1", "slice_2", "slice_3", "slice_4", "slice_5"}, 1/9, "Waves/Neutral")
        swipe.loopmode = "ONESHOT"
        swipe.alpha = 0.25
        swipe.SetParent(Arena.sprite)
        swipe.SendToBottom()
        
        rotation = math.random(0, 360)
        swipe.rotation = rotation
        
        pos = {x = Player.x + math.random(-30, 30), y = Player.y + math.random(-30, 30)}
        swipe.MoveTo(pos.x, pos.y)
    elseif swipe and swipe.animcomplete then
        swipe.Remove()
        swipe = nil
        
        Audio.PlaySound("slice")
        
        slash = CreateProjectile("Waves/Neutral/slice_0", pos.x, pos.y)
        slash.sprite.Scale(1.5, 1.5)
        slash.sprite.SetAnimation({"slice_0", "slice_1", "slice_2", "slice_3", "slice_4", "slice_5"}, 1/16, "Waves/Neutral")
        slash.sprite.loopmode = "ONESHOT"
        slash.ppcollision = true
        slash.sprite.rotation = rotation
    elseif slash and slash.sprite.animcomplete then
        slash.sprite.StopAnimation()
        slash.Remove()
        timer = 0
    end
end

function OnHit(bullet)
    Player.Hurt(3, 1)
end

function EndingWave()
    if swipe then
        swipe.Remove()
    end
end
