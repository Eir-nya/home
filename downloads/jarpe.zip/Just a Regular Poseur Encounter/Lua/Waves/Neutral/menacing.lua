require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



if CYFversion >= "0.6.4" then
    maskparent = CreateSprite("px", "Topper")
    maskparent.xpivot = Arena.sprite.xpivot
    maskparent.ypivot = Arena.sprite.ypivot
    maskparent.MoveToAbs(Arena.sprite.absx, Arena.sprite.absy)
    maskparent.Scale(Arena.currentwidth, Arena.currentheight)
    maskparent.Mask("stencil")
end

bullets = {}
timer = 0

function Update()
    timer = timer + 1
    
    if timer%45 == 0 then
        local bullet = CreateProjectile("Waves/menacing", math.sin(math.rad(timer * 1)) * Arena.width/2, -Arena.height/2)
        bullet["offset"] = timer%10 == 0 and 0 or 30
        bullets[bullet] = bullet
        
        if CYFversion >= "0.6.4" then
            bullet.sprite.SetParent(maskparent)
        end
    end
    
    for bullet in pairs(bullets) do
        bullet.x = math.sin(math.rad((timer + bullet["offset"]) * 1)) * Arena.width/2
        bullet.y = bullet.y + 1.25
        
        if bullet.y > Arena.height/2 + bullet.sprite.height/2 then
            bullet.Remove()
            bullets[bullet] = nil
        end
    end
end

function OnHit(bullet)
    Player.Hurt(1, 1)
    bullet.Remove()
    bullets[bullet] = nil
end

function WaveEnding()
    for bullet in next, bullets, bullet do
        if bullet.isactive then
            bullet.Remove()
        end
    end
    
    if CYFversion >= "0.6.4" then
        maskparent.Remove()
    end
end
