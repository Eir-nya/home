require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



-- load the library!
blue = require "Libraries/bluesoul"
-- initialize the library (changes soul color and stuff)
blue.Initialize()

blue.speed = 3

Encounter["fakearena"].bottomleft.alpha  = 0
Encounter["fakearena"].bottomright.alpha = 0
Encounter["fakearena"].topleft.alpha     = 0
Encounter["fakearena"].topright.alpha    = 0

bl = CreateSprite("Waves/arrowblock", "Topper")
bl.SetPivot(0, 0)
bl.SetAnchor(0, 0)
bl.SetParent(Arena.sprite)
bl.MoveAbove(Encounter["fakearena"].bottomright)
bl.MoveTo(-5, -5)

br = CreateSprite("Waves/arrowblock", "Topper")
br.xscale = -1
br.SetPivot(0, 0)
br.SetAnchor(1, 0)
br.SetParent(Arena.sprite)
br.MoveAbove(Encounter["fakearena"].bottomright)
br.MoveTo(5, -5)

tl = CreateSprite("Waves/arrowblock", "Topper")
tl.yscale = -1
tl.SetPivot(0, 0)
tl.SetAnchor(0, 1)
tl.SetParent(Arena.sprite)
tl.MoveAbove(Encounter["fakearena"].bottomright)
tl.MoveTo(-5, 5)

tr = CreateSprite("Waves/arrowblock", "Topper")
tr.Scale(-1, -1)
tr.SetPivot(0, 0)
tr.SetAnchor(1, 1)
tr.SetParent(Arena.sprite)
tr.MoveAbove(Encounter["fakearena"].bottomright)
tr.MoveTo(5, 5)

transition = false
transitionDir = 0 -- 1 for right, -1 for left
transitionTimer = 0

angle = 0



-- blue soul overriding stuff
do
    blue.JumpInput = function()
        return Input.Up
    end    
    
    blue.GetSideInput = function()
        local mult = Input.Cancel > 0 and 0.5 or 1
            -- I don't know why this is this way, but it is
        if     blue.direction == "right" or blue.direction == "down" then
            return ((blue.SpeedByInput(Input.Right) - blue.SpeedByInput(Input. Left)) + blue.movex) * mult
        else
            return ((blue.SpeedByInput(Input. Left) - blue.SpeedByInput(Input.Right)) + blue.movex) * mult
        end
    end
end



function Update()
    if not transition then
        -- update blue soul! NECESSARY!
        blue.Update()
    end
    
    if not transition then
        local grounded = blue.CheckIfGrounded()
        local movement = blue.GetSideInput()
        
        -- bottom-left angle collisions
        if blue.direction == "down" and grounded and movement < 0 and Player.sprite.absx < bl.absx + bl.width then
            transition    = true
            transitionDir =   -1
            angle = (angle + (transitionDir * 90)) % 360
            
            Audio.PlaySound("Waves/grab")
            Player.sprite.alpha = 0.7
            Player.sprite.MoveToAbs(bl.absx + bl.width + 5, Player.absy)
        elseif blue.direction == "left" and grounded and movement < 0 and Player.sprite.absy < bl.absy + bl.height then
            transition    = true
            transitionDir =    1
            angle = (angle + (transitionDir * 90)) % 360
            
            Audio.PlaySound("Waves/grab")
            Player.sprite.alpha = 0.7
            Player.sprite.MoveToAbs(Player.absx, bl.absy + bl.height + 5)
        end
        
        -- bottom-right angle collisions
        if blue.direction == "down" and grounded and movement > 0 and Player.sprite.absx > br.absx - br.width then
            transition    = true
            transitionDir =    1
            angle = (angle + (transitionDir * 90)) % 360
            
            Audio.PlaySound("Waves/grab")
            Player.sprite.alpha = 0.7
            Player.sprite.MoveToAbs(br.absx - br.width - 5, Player.absy)
        elseif blue.direction == "right" and grounded and movement < 0 and Player.sprite.absy < br.absy + br.height then
            transition    = true
            transitionDir =   -1
            angle = (angle + (transitionDir * 90)) % 360
            
            Audio.PlaySound("Waves/grab")
            Player.sprite.alpha = 0.7
            Player.sprite.MoveToAbs(Player.absx, br.absy + br.height + 5)
        end
        
        -- top-left angle collisions
        if blue.direction == "left" and grounded and movement > 0 and Player.sprite.absy > tl.absy - tl.height then
            transition    = true
            transitionDir =   -1
            angle = (angle + (transitionDir * 90)) % 360
            
            Audio.PlaySound("Waves/grab")
            Player.sprite.alpha = 0.7
            Player.sprite.MoveToAbs(Player.absx, tl.absy - tl.height - 5)
        elseif blue.direction == "up" and grounded and movement < 0 and Player.sprite.absx < tl.absx + tl.width then
            transition    = true
            transitionDir =    1
            angle = (angle + (transitionDir * 90)) % 360
            
            Audio.PlaySound("Waves/grab")
            Player.sprite.alpha = 0.7
            Player.sprite.MoveToAbs(tl.absx + tl.width + 5, Player.absy)
        end
        
        -- top-right angle collisions
        if blue.direction == "right" and grounded and movement > 0 and Player.sprite.absy > tr.absy - tr.height then
            transition    = true
            transitionDir =    1
            angle = (angle + (transitionDir * 90)) % 360
            
            Audio.PlaySound("Waves/grab")
            Player.sprite.alpha = 0.7
            Player.sprite.MoveToAbs(Player.absx, tr.absy - tr.height - 5)
        elseif blue.direction == "up" and grounded and movement > 0 and Player.sprite.absx > tr.absx - tr.width then
            transition    = true
            transitionDir =   -1
            angle = (angle + (transitionDir * 90)) % 360
            
            Audio.PlaySound("Waves/grab")
            Player.sprite.alpha = 0.7
            Player.sprite.MoveToAbs(tr.absx - tr.width - 5, Player.absy)
        end
    -- animate going up or down
    elseif transitionTimer < 10 then
        transitionTimer = transitionTimer + 1
        
        Player.sprite.rotation = angle - ((1 - (transitionTimer/10)) * 90 * transitionDir)
        Player.Move(math.cos(math.rad(Player.sprite.rotation)) * 1.2 * transitionDir, math.sin(math.rad(Player.sprite.rotation)) * 1.2 * transitionDir, true)
        
        if transitionTimer == 10 then
            transitionTimer = 0
            transition = false
            Player.sprite.alpha = 1
            blue.Dir(({[90] = "right", [180] = "up", [270] = "left", [0] = "down"})[angle])
        end
        
        Player.sprite.rotation = Player.sprite.rotation + Arena.rotation
    end
end

function EndingWave()
    bl.Remove()
    br.Remove()
    tl.Remove()
    tr.Remove()
    
    if blue.fakeplayer and blue.fakeplayer.isactive then
        blue.fakeplayer.Remove()
    end
    
    Encounter["fakearena"].bottomleft.alpha  = 1
    Encounter["fakearena"].bottomright.alpha = 1
    Encounter["fakearena"].topleft.alpha     = 1
    Encounter["fakearena"].topright.alpha    = 1
end
