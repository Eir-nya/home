require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



Encounter.Call("loadstring",
    "enemies[1][\"anim\"].glitch = false ; "
 .. "musicIntroLoop.Pause()"
 .. "unescape = true"
)

-- attempt to stop sfx
for i = 0, 5 do
    if NewAudio.Exists("MusicPlaySound" .. (i == 0 and "" or i)) then
        NewAudio.DestroyChannel("MusicPlaySound" .. (i == 0 and "" or i))
    end
end

if windows then
    Misc.WindowName = "PLEASE DON'T CLOSE THE GAME IT'S A JOKE"
end

bg = CreateSprite("fakeout", "Topper")
bg.MoveToAbs(320, 240)
bg.Scale(0.5, 0.5)

dog = CreateSprite("dog", "Topper")
dog.MoveToAbs(580, 60)
dog.Scale(5, 5)



function Update()
    dog.rotation = dog.rotation + (Time.dt * 90)
end

function EndingWave()
    bg.Remove()
    dog.Remove()
    
    Encounter.Call("loadstring",
        "enemies[1][\"anim\"].glitch = true ; "
     .. "musicIntroLoop.Unpause()"
     .. "unescape = false"
    )
    
    if windows then
        Misc.WindowName = "Thanks <3"
    end
end
