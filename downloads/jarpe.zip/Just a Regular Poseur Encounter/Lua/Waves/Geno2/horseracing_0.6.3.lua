require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



-- name comes from https://www.youtube.com/watch?v=2juJWdmjKDo
Arena.currentheight = Arena.height
Player.y = 0

-- load the library!
blue = require "Libraries/bluesoul"
-- initialize the library (changes soul color and stuff)
blue.Initialize()
Audio.PlaySound("ding")

-- overwrite stuff so the wave can constantly push the player right
local movex = 0
blue.movex = nil
setmetatable(blue, {
    __index = function(t, k)
        if k == "movex" then
            return (movex ~= 0) and (movex - 2) or 0
        end
    end,
    __newindex = function(t, k, v)
        if k == "movex" then
            movex = v
        end
    end
})
blue.speed = 4



timer       =  0
horses      = {}
spikes      = {}
platforms   = {}

-- create invisible top and bottom spike bullets
bspike = CreateProjectile("empty", -Arena.width/2, -Arena.height/2)
bspike.sprite.SetPivot(0, 0)
bspike.sprite.alpha = 0
bspike.sprite.Scale(0, 8)
tspike = CreateProjectile("empty", -Arena.width/2,  Arena.height/2 - 4)
tspike.sprite.SetPivot(0, 1)
tspike.sprite.alpha = 0
tspike.sprite.Scale(0, 8)

function CreatePlatform(name, x, y, speed)
    local plat = CreateProjectile(name, x, y)
    
    plat["safe"] = true
    plat["speed"] = speed and speed or 1
    plat.sprite.layer = "Topper"
    plat.sprite.SetParent(Arena.sprite)
    plat.sprite.SendToBottom()
    plat.sprite.xpivot = 0
    plat.x = plat.x - plat.sprite.width/2
    
    return plat
end

-- create initial platform
platforms[1] = CreatePlatform("Waves/Geno2/platform_notsobig", 0, -14, 0.75)
lastheight = -30



function Update()
    timer = timer + 1
    blue.Update()
    if Input.Right < 1 or (Input.Right > 0 and Input.Left > 0) then
        Player.x = Player.x + 2
    end
    
    -- create and move spikes
    if timer % 25 == 0 then
        local bspike = CreateSprite("Waves/Geno2/spike", "Topper")
        bspike.SetParent(Arena.sprite)
        bspike["xdir"] = math.random(0, 1) == 0 and -1 or 1
        bspike.SetPivot(bspike["xdir"] < 0 and 1 or 0, 0)
        bspike.MoveTo(-Arena.width/2, (-Arena.height/2) - 2)
        bspike.xscale = 0
        
        spikes[bspike] = true
        
        local tspike = CreateSprite("Waves/Geno2/spike", "Topper")
        tspike.SetParent(Arena.sprite)
        tspike["xdir"] = math.random(0, 1) == 0 and -1 or 1
        tspike.SetPivot(tspike["xdir"] < 0 and 1 or 0, 0)
        tspike.MoveTo(-Arena.width/2,  (Arena.height/2) + 2)
        tspike.xscale = 0
        tspike.yscale = -1
        
        spikes[tspike] = true
    end
    
    for spike in next, spikes, spike do
        -- if not yet fully scaled AND on the left side of the arena, scale it first
        if spike.x < 0 and math.abs(spike.xscale) < 1 then
            spike.xscale = spike.xscale + (2 / spike.width) * spike["xdir"]
            spike.xscale = spike.xscale < 1 and spike.xscale or 1           -- limit xscale to 1
        -- otherwise, move right
        elseif spike.x + spike.width < Arena.width/2 then
            spike.x = spike.x + 2
        -- finally, squish it away and remove it
        elseif math.abs(spike.xscale) > 0 then
            spike.x = spike.x + 2
            spike.xscale = spike.xscale - (2 / spike.width) * spike["xdir"]
            
            -- remove condition
            if spike.x >= Arena.width/2 then
                spike.Remove()
                spikes[spike] = nil
            end
        end
    end
    
    -- resize spike hitbox
    bspike.sprite.xscale = (timer - 25) * 2
    bspike.sprite.xscale = bspike.sprite.xscale <           0 and           0 or bspike.sprite.xscale
    bspike.sprite.xscale = bspike.sprite.xscale > Arena.width and Arena.width or bspike.sprite.xscale
    tspike.sprite.xscale = bspike.sprite.xscale
    
    
    
    -- create platforms
    if timer % 60 == 0 or timer == 1 then
        -- choose new height for platform
        local newheight
        repeat
            newheight = lastheight + ((math.random(0, 1) == 0 and -1 or 1) * 25)
            newheight = (newheight < (-Arena.height/2) + 40) and (-Arena.height/2) + 40 or newheight
            newheight = (newheight > ( Arena.height/2) - 70) and ( Arena.height/2) - 70 or newheight
        until newheight ~= lastheight
        
        lastheight = newheight
        
        -- spawn platform
        local plat = CreatePlatform("Waves/Geno2/platform_big", -Arena.width/2 + 30, lastheight, 1 + (math.random(2, 4) / 4))
        plat.sprite.xscale = 0
        
        -- create pole
        local pole = CreateSprite("Waves/Geno2/pole0", "Topper")
        pole.SetAnimation({"pole0", "pole1", "pole2", "pole3", "pole4", "pole5"}, 1/12, "Waves/Geno2")
        pole.SetParent(plat.sprite)
        pole.MoveTo(0, -plat.y)
        
        plat["pole"] = pole
        table.insert(platforms, plat)
        
        -- create horse
        local horse = CreateProjectile("Waves/Geno2/horse" .. (timer > 1 and ((timer / 60) % 2) or 0), 0, 0)
        -- rare chance thingy
        if not everyman and math.random(1, 100) == 1 and horse.sprite.spritename == "Waves/Geno2/horse1" then
            everyman = true
            horse.sprite.Set("Waves/Geno2/horse2")
        end
        horse.sprite.SetParent(pole)
        horse.x = -Arena.width/2 - horse.sprite.width/2.25 + 10
        horse.y = math.random(-Arena.height/2 + horse.sprite.height, Arena.height/2 - horse.sprite.height)
        horse["offset"] = ((timer / 60) % 2) == 1 and 0 or math.deg(5) -- horse["offset"] = math.random(0, 30) + (((timer / 60) % 2) == 0 and 0 or math.deg(60))
        plat["horse"] = horse
        horses[horse] = true
    end
    
    -- work on all platforms
    -- must be done in ipairs because dumb old blue soul library
    for i, plat in ipairs(platforms) do
        if plat.isactive then
            plat.x = plat.x + plat["speed"]
            -- plat.y = plat.y + plat["vely"]
            
            -- if not yet fully scaled AND on left side of arena, scale first
            if plat.sprite.xscale < 1 and plat.x < 0 then
                plat.sprite.xscale = plat.sprite.xscale + (plat["speed"] / plat.sprite.width)
                plat.x = plat.x - plat["speed"]
            -- as we reach the right side of the arena, shrink the platform
            elseif plat.x + plat.sprite.width > Arena.width/2 then
                plat.sprite.xscale = (Arena.width/2 - plat.x) / plat.sprite.width
                
                -- remove condition
                if plat.x > Arena.width/2 then
                    -- exception for initial platform
                    if plat["horse"] then
                        plat["horse"].Remove()
                        horses[plat["horse"]] = nil
                        plat["pole"].Remove()
                    end
                    
                    plat.Remove()
                end
            end
        end
    end
    
    
    
    -- work on all horses
    for horse in next, horses, horse do
        horse.y = math.sin(math.rad(timer * 2) - horse["offset"]) * ((Arena.height/2) - horse.sprite.height)
    end
    
    blue.platforms = platforms
end

function OnHit(bullet)
    if not bullet["safe"] then
        Player.Hurt(2, 1)
        lastheight = -Arena.height/2
    end
end

function EndingWave()
    Player.sprite.color = {1, 0, 0}
    
    if blue.fakeplayer and blue.fakeplayer.isactive then
        blue.fakeplayer.Remove()
    end
    
    for spike in next, spikes, spike do
        if spike.isactive then
            spike.Remove()
        end
    end
    
    for i, plat in ipairs(platforms) do
        if plat.isactive then
            if plat["horse"] and plat["horse"].isactive then
                plat["horse"].Remove()
            end
            
            if plat["pole"] and plat["pole"].isactive then
                plat["pole"].Remove()
            end
            
            plat.Remove()
        end
    end
end
