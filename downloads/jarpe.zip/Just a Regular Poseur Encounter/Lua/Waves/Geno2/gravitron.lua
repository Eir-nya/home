require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



-- USE SOUND
-- Waves/blip

-- load the library!
blue = require "Libraries/bluesoul"
-- initialize the library (changes soul color and stuff)
blue.Initialize()
Audio.PlaySound("ding")

blue.speed = 3.5

blue.SetJump(2)

-- override blue soul to have terminal velocity
local _getVertInput = blue.GetVertInput
local terminalVelocity = 4.4
function blue.GetVertInput()
    local _ret = _getVertInput()
    if math.abs(_ret) > terminalVelocity then
        _ret = _ret > 0 and terminalVelocity or -terminalVelocity
    end
    return _ret
end


timer = -1
top = CreateSprite("px", "Topper")
top.MoveTo(Arena.x, Arena.y + Arena.height - 8)
top.Scale(Arena.currentwidth, 3)
topTimer = 0

bottom = CreateSprite("px", "Topper")
bottom.MoveTo(Arena.x, Arena.y + 8)
bottom.Scale(Arena.currentwidth, 3)
bottomTimer = 0



blasts     = {}

clubBombs  = {}
clubs      = {}
heartBombs = {}
hearts     = {}

diamonds   = {}

SetPPCollision(true)

function Update()
    blue.Update()
    
    top.xscale    = Arena.currentwidth
    bottom.xscale = Arena.currentwidth
    
    if     Player.absy - Player.sprite.height/2 < bottom.absy then
        blue.Dir("up")
        Audio.PlaySound("Waves/blip")
        bottom.color = {0.5, 0.5, 0.5}
        bottomTimer = 30
    elseif Player.absy + Player.sprite.height/2 > top   .absy then
        blue.Dir("down")
        Audio.PlaySound("Waves/blip")
        top.color = {0.5, 0.5, 0.5}
        topTimer = 30
    end
    
    
    
    -- turn them white after some time
    if bottomTimer > 0 then
        bottomTimer = bottomTimer - 1
        
        if bottomTimer == 0 then
            bottom.color = {1, 1, 1}
        end
    end
    
    if topTimer > 0 then
        topTimer = topTimer - 1
        
        if topTimer == 0 then
            top.color = {1, 1, 1}
        end
    end
    
    
    
    -- bullets!
    timer = timer + 1
    local timer = timer % 180 -- 45 * 4
    
    -- create club bomb
    if timer == 0 then
        local bomb = CreateSprite("Waves/Geno2/club_block0", "Topper")
        bomb.SetAnimation({"club_block0", "club_block1"}, 1/8, "Waves/Geno2")
        
        local side = math.random() < 0.5 and -1 or 1
        bomb.MoveToAbs(320 + (250 * side) + math.random(-40, 40), 480 + bomb.height)
        
        bomb["ydetonate"] = (Arena.y - 20) + math.random(0, Arena.height)
        
        clubBombs[bomb] = true
    
    -- create heart bomb
    elseif timer == 45 then
        local bomb = CreateSprite("Waves/Geno2/heart_block0", "Topper")
        bomb.SetAnimation({"heart_block0", "heart_block1"}, 1/8, "Waves/Geno2")
        
        local side = math.random() < 0.5 and -1 or 1
        bomb.MoveToAbs(320 + (250 * side) + math.random(-40, 40), 480 + bomb.height)
        
        bomb["ydetonate"] = (Arena.y - 20) + math.random(0, Arena.height)
        
        heartBombs[bomb] = true
    
    -- create diamonds
    elseif timer >= 135 and timer%6 == 0 then
        local diamond = CreateProjectile("Waves/Geno2/diamond", math.random(-Arena.width/2, Arena.width/2), -Arena.height/2 - 40)
        diamond.sprite.alpha = 0
        diamond.sprite.Scale(2, 2)
        diamond["velocity"] = 0
        
        diamonds[diamond] = true
    end
    
    
    -- handle blasts
    for blast in next, blasts, blast do
        blast["life"] = blast["life"] + 1
        
        blast.xscale = 0.5 + (blast["life"] / 60)
        blast.yscale = blast.xscale
        blast.alpha = 1 - ((blast.xscale - 0.5) * 2)
        
        if blast["life"] == 30 then
            blast.Remove()
            blasts[blast] = nil
        end
    end
    
    -- handle club bombs
    for bomb in next, clubBombs, bomb do
        bomb.y = bomb.y - 4
        
        -- remove condition
        if bomb.y <= bomb["ydetonate"] then
            Audio.PlaySound("Waves/bomb")
            
            -- create bomb blast
            local blast = CreateSprite("Waves/Geno2/blast", "Topper")
            blast.MoveToAbs(bomb.absx, bomb.absy)
            blast.Scale(0.5, 0.5)
            blast["life"] = 0
            blasts[blast] = true
            
            -- create clubs
            local angle = (math.deg(math.atan2(Player.absy - bomb.absy, Player.absx - bomb.absx)) + 90) % 360
            angle = angle + 45
            
            
            
            for i = 1, 3 do
                local club = CreateProjectileAbs("Waves/Geno2/club", bomb.absx, bomb.absy)
                club["xdir"] =  math.sin(math.rad(angle))
                club["ydir"] = -math.cos(math.rad(angle))
                club.sprite.rotation = angle + 180 -- club.sprite.rotation = math.deg(math.atan2(club["ydir"], club["xdir"])) - 90
                clubs[club] = true
                
                angle = angle - 45
            end
            
            bomb.Remove()
            clubBombs[bomb] = nil
        end
    end
    
    -- handle clubs
    for club in next, clubs, club do
        club.Move(club["xdir"] * 3.5, club["ydir"] * 3.5)
        
        -- remove condition
        if club.absx < -68 or club.absx > 640 + 68 or club.absy < -68 or club.absy > 480 + 68 then
            club.Remove()
            clubs[club] = nil
        end
    end
    
    -- handle heart bombs
    for bomb in next, heartBombs, bomb do
        bomb.y = bomb.y - 4
        
        -- remove condition
        if bomb.y <= bomb["ydetonate"] then
            Audio.PlaySound("Waves/bomb")
            
            -- create bomb blast
            local blast = CreateSprite("Waves/Geno2/blast", "Topper")
            blast.MoveToAbs(bomb.absx, bomb.absy)
            blast.Scale(0.5, 0.5)
            blast["life"] = 0
            blasts[blast] = true
            
            -- create hearts
            local angle = (math.deg(math.atan2(Player.absy - bomb.absy, Player.absx - bomb.absx)) + 90) % 360
            
            
            
            local heart = CreateSprite("empty", "Topper")
            heart.MoveToAbs(bomb.absx, bomb.absy)
            heart["xdir"] =  math.sin(math.rad(angle))
            heart["ydir"] = -math.cos(math.rad(angle))
            heart["animTimer"] = 0
            
            for i = 1, 4 do
                local hearty = CreateProjectileAbs("Waves/Geno2/heart2", bomb.absx, bomb.absy)
                hearty.sprite.SetParent(heart)
                hearty.sprite.MoveTo(0, 0)
                hearty.sprite.SetAnchor(i % 2, math.floor((i - 1) / 2))
                heart["heart" .. i] = hearty
            end
            
            hearts[heart] = true
            
            bomb.Remove()
            heartBombs[bomb] = nil
        end
    end
    
    -- handle hearts
    for heart in next, hearts, heart do
        heart["animTimer"] = heart["animTimer"] < 30 and heart["animTimer"] + 1 or 30
        heart.Scale(heart["animTimer"], heart["animTimer"])
        
        -- move
        if heart["animTimer"] == 30 then
            heart.Move(heart["xdir"] * 3, heart["ydir"] * 3)
            heart.rotation = heart.rotation + 3
            
            for i = 1, 4 do
                heart["heart" .. i].sprite.rotation = 0
            end
        end
    end
    
    -- handle diamonds
    for diamond in next, diamonds, diamond do
        -- animate in
        if diamond.sprite.alpha < 1 then
            diamond.sprite.alpha = diamond.sprite.alpha + (1/40)
            diamond.sprite.Scale(2 - diamond.sprite.alpha, 2 - diamond.sprite.alpha)
        
        -- move
        else
            diamond["velocity"] = diamond["velocity"] < 3 and diamond["velocity"] + 0.2 or 3
            diamond.y = diamond.y + diamond["velocity"]
        end
        
        -- remove condition
        if diamond.absy > 480 + diamond.sprite.height then
            diamond.Remove()
            diamonds[diamond] = nil
        end
    end
end

function OnHit(bullet)
    if not Player.isHurting then
        Player.Hurt(2, 1)
        if bullet.sprite.spritename == "Waves/Geno2/heart2" then
            bullet.Remove()
        elseif bullet.sprite.spritename == "Waves/Geno2/diamond" then
            bullet.Remove()
            diamonds[bullet] = nil
        end
    end
end

function EndingWave()
    Player.sprite.color = {1, 0, 0}
    
    if blue.fakeplayer and blue.fakeplayer.isactive then
        blue.fakeplayer.Remove()
    end
    
    top.Remove()
    bottom.Remove()
    
    -- remove all sprite objects
    for _, tab in pairs(({blasts, clubBombs, heartBombs})) do
        for obj in next, tab, obj do
            if obj.isactive then
                obj.Remove()
            end
        end
    end
    
    -- special case for heart bullets
    for heart in next, hearts, heart do
        if heart.isactive then
            if heart["heart1"].isactive then
                heart["heart1"].Remove()
            end
            if heart["heart2"].isactive then
                heart["heart2"].Remove()
            end
            if heart["heart3"].isactive then
                heart["heart3"].Remove()
            end
            if heart["heart4"].isactive then
                heart["heart4"].Remove()
            end
            heart.Remove()
        end
    end
end
