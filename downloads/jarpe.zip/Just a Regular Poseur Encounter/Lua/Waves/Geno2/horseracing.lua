require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



-- name comes from https://www.youtube.com/watch?v=2juJWdmjKDo
Arena.currentheight = Arena.height
Player.y = 0

-- load the library!
blue = require "Libraries/bluesoul"
-- initialize the library (changes soul color and stuff)
blue.Initialize()
Audio.PlaySound("ding")

-- overwrite stuff so the wave can constantly push the player right
local movex = 0
blue.movex = nil
setmetatable(blue, {
    __index = function(t, k)
        if k == "movex" then
            return (movex ~= 0) and (movex - 2) or 0
        end
    end,
    __newindex = function(t, k, v)
        if k == "movex" then
            movex = v
        end
    end
})
blue.speed = 4

-- CYF v0.6.4 and beyond: special mask stuff
maskUnder = CreateSprite("Waves/Geno2/horsemask")
maskUnder.SetParent(Arena.sprite)
maskUnder.MoveAbove(Encounter["fakearena"].textParent)
maskUnder.SetAnchor(0.5, 0.5)
maskUnder.MoveTo(0, 0)
maskUnder.Mask("stencil")

maskOver = CreateSprite("Waves/Geno2/horsemask")
maskOver.SetParent(Arena.sprite)
maskOver.MoveAbove(Player.sprite)
maskOver.SetAnchor(0.5, 0.5)
maskOver.MoveTo(0, 0)
maskOver.Mask("stencil")



timer       =  0
horses      = {}
spikes      = {}
spikepool   = {}
platforms   = {}

-- create invisible top and bottom spike bullets
bspike = CreateProjectile("empty", -Arena.width/2, -Arena.height/2)
bspike.sprite.SetPivot(0, 0)
bspike.sprite.alpha = 0
bspike.sprite.Scale(0, 8)
tspike = CreateProjectile("empty", -Arena.width/2,  Arena.height/2 - 4)
tspike.sprite.SetPivot(0, 1)
tspike.sprite.alpha = 0
tspike.sprite.Scale(0, 8)

function CreatePlatform(name, x, y, speed)
    local plat = CreateProjectile(name, x, y)
    
    plat["safe"] = true
    plat["speed"] = speed and speed or 1
    plat.sprite.layer = "Topper"
    plat.sprite.SetParent(maskUnder)
    plat.sprite.SendToBottom()
    plat.sprite.xpivot = 0
    plat.x = plat.x - plat.sprite.width/2
    
    return plat
end

-- create initial platform
platforms[1] = CreatePlatform("Waves/Geno2/platform_notsobig", 0, -14, 0.75)
lastheight = -30



function Update()
    timer = timer + 1
    maskUnder.Scale(Arena.currentwidth / Arena.width, Arena.currentheight / Arena.height)
    maskOver.Scale(maskUnder.xscale, maskUnder.yscale)
    blue.Update()
    if Input.Right < 1 or (Input.Right > 0 and Input.Left > 0) then
        Player.x = Player.x + 2
    end
    
    -- create and move spikes
    if timer % 25 == 0 then
        -- first, check the spike pool
        local bspike
        if #spikepool > 0 then
            bspike = table.remove(spikepool, #spikepool)
            bspike.alpha = 1
        else
            bspike = CreateSprite("Waves/Geno2/spike", "Topper")
        end
        bspike.SetParent(maskOver)
        local xdir = math.random() < 0.5 and -1 or 1
        bspike.SetPivot(xdir < 0 and 1 or 0, 0)
        bspike.MoveTo(-Arena.width/2, (-Arena.height/2) - 2)
        bspike.Scale(-xdir,  1)
        
        spikes[bspike] = true
        
        -- first, check the spike pool
        local tspike
        if #spikepool > 0 then
            tspike = table.remove(spikepool, #spikepool)
            tspike.alpha = 1
        else
            tspike = CreateSprite("Waves/Geno2/spike", "Topper")
        end
        tspike.SetParent(maskOver)
        local xdir = math.random() < 0.5 and -1 or 1
        tspike.SetPivot(xdir < 0 and 1 or 0, 0)
        tspike.MoveTo(-Arena.width/2,  (Arena.height/2) + 2)
        tspike.Scale(-xdir, -1)
        
        spikes[tspike] = true
    end
    
    for spike in next, spikes, spike do
        -- move right
        if spike.x < Arena.width/2 + spike.width then
            spike.x = spike.x + 2
        -- finally, remove it
        else
            spike.alpha = 0 -- spike.Remove()
            table.insert(spikepool, spike)
            spikes[spike] = nil
        end
    end
    
    -- resize spike hitbox
    bspike.sprite.xscale = (timer - 25) * 2
    bspike.sprite.xscale = bspike.sprite.xscale <           0 and           0 or bspike.sprite.xscale
    bspike.sprite.xscale = bspike.sprite.xscale > Arena.width and Arena.width or bspike.sprite.xscale
    tspike.sprite.xscale = bspike.sprite.xscale
    
    
    
    -- create platforms
    if timer % 60 == 0 or timer == 1 then
        -- choose new height for platform
        local newheight
        repeat
            newheight = lastheight + ((math.random() < 0.5 and -1 or 1) * 25)
            newheight = (newheight < (-Arena.height/2) + 40) and (-Arena.height/2) + 40 or newheight
            newheight = (newheight > ( Arena.height/2) - 70) and ( Arena.height/2) - 70 or newheight
        until newheight ~= lastheight
        
        lastheight = newheight
        
        -- spawn platform
        local plat = CreatePlatform("Waves/Geno2/platform_big", -Arena.width/2 - 45, lastheight, 1 + (math.random(2, 4) / 4))
        
        -- create pole
        local pole = CreateSprite("Waves/Geno2/pole0", "Topper")
        pole.SetAnimation({"pole0", "pole1", "pole2", "pole3", "pole4", "pole5"}, 1/12, "Waves/Geno2")
        pole.SetParent(plat.sprite)
        pole.MoveTo(0, -plat.y)
        
        plat["pole"] = pole
        table.insert(platforms, plat)
        
        -- create horse
        local horse = CreateProjectile("Waves/Geno2/horse" .. (timer > 1 and ((timer / 60) % 2) or 0), 0, 0)
        -- rare chance thingy
        if not everyman and math.random() <= 0.01 and horse.sprite.spritename == "Waves/Geno2/horse1" then
            everyman = true
            horse.sprite.Set("Waves/Geno2/horse2")
        end
        horse.sprite.SetParent(pole)
        horse.sprite.x = 0
        horse.y = math.random(-Arena.height/2 + horse.sprite.height, Arena.height/2 - horse.sprite.height)
        horse["offset"] = ((timer / 60) % 2) == 1 and 0 or math.deg(5)
        plat["horse"] = horse
        horses[horse] = true
    end
    
    -- work on all platforms
    -- must be done in ipairs because dumb old blue soul library
    for i, plat in ipairs(platforms) do
        if plat.isactive then
            plat.x = plat.x + plat["speed"]
            
            -- remove condition
            if plat.x >= Arena.width/2 then
                -- exception for initial platform
                if plat["horse"] then
                    plat["horse"].Remove()
                    horses[plat["horse"]] = nil
                    plat["pole"].Remove()
                end
                
                plat.Remove()
            end
        end
    end
    
    
    
    -- work on all horses
    for horse in next, horses, horse do
        horse.y = math.sin(math.rad(timer * 2) - horse["offset"]) * ((Arena.height/2) - horse.sprite.height)
    end
    
    blue.platforms = platforms
end

function OnHit(bullet)
    if not bullet["safe"] then
        Player.Hurt(2, 1.2)
        lastheight = -Arena.height/2
    end
end

function EndingWave()
    Player.sprite.color = {1, 0, 0}
    
    if blue.fakeplayer and blue.fakeplayer.isactive then
        blue.fakeplayer.Remove()
    end
    
    for spike in next, spikes, spike do
        if spike.isactive then
            spike.Remove()
        end
    end
    
    for i = 1, #spikepool do
        if spikepool[i].isactive then
            spikepool[i].Remove()
        end
    end
    
    for i, plat in ipairs(platforms) do
        if plat.isactive then
            if plat["horse"] and plat["horse"].isactive then
                plat["horse"].Remove()
            end
            
            if plat["pole"] and plat["pole"].isactive then
                plat["pole"].Remove()
            end
            
            plat.Remove()
        end
    end
end
