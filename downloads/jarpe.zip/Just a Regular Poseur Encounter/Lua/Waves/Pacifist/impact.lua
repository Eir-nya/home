require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



-- use sound Waves/fire

side = 0        -- 0: left, 1: top, 2: right
lastside = 0    -- keeps track of `side`'s value when the Arena got hit
frequency = 110 -- time between attacks
dist = 260      -- distance away from arena to spawn big fireball
speed = 6       -- pixels per frame to move the big fireball
bounce = 0      -- keeps track of how far along in the bounce the Arena is
bouncetimer = 0 -- timer for bouncing the arena

bullets = {}
timer = math.floor(-frequency/3)

arenaspeed = Arena.speed

function Update()
    timer = timer + 1
    
    if timer%frequency == 0 then
        Audio.PlaySound("BeginBattle2")
        side = math.random(0, 2)
        
        fireball = CreateSprite("Waves/Pacifist/fireball0", "Topper")
        fireball.MoveBelow(Arena.sprite)
        fireball.SetAnimation({"fireball0", "fireball1"}, 1/8, "Waves/Pacifist")
        fireball.xpivot = 1 - (side/2)
        fireball.ypivot = side == 1 and 0 or 0.5
        fireball.x = side == 0 and Arena.x - Arena.width/2 - dist or side == 1 and Arena.x or Arena.x + Arena.width/2 + dist
        fireball.y = side == 1 and Arena.y + Arena.height + dist or Arena.y + Arena.height/2
    elseif fireball and bouncetimer == 0 then
        fireball.Move(speed * (1 - side), speed * -(side % 2))
        
        -- collision
        if fireball.x >= Arena.x - Arena.width/2 - 5 and fireball.x <= Arena.x + Arena.width/2 + 5 and fireball.y <= Arena.y + Arena.height then
            Audio.PlaySound("Waves/fire")
            
            lastside = side
            bounce = 0
            bouncetimer = 1
            Arena.speed = 0
            
            -- create bullets
            for i = 1, 8 + (math.random() * 5) do
                local bullet = CreateProjectileAbs("Waves/Pacifist/flame1", fireball.absx, fireball.absy)
                bullet.sprite.SetAnimation({"flame1", "flame2"}, 1/6, "Waves/Pacifist")
                bullet["xvel"] = side ~= 1 and (math.random() * -4) * (side - 1) or -2 + (math.random() * 4)
                bullet["yvel"] = math.random() * 4
                bullets[bullet] = true
            end
            
            fireball.Remove()
            fireball = nil
        end
    elseif bouncetimer > 0 and bouncetimer <= 20 then
        bouncetimer = bouncetimer + 1
        bounce = lerp(bounce, Arena.height / 2, 0.2)
        
        if side ~= 1 then
            Arena.currentx = (320 + bounce) - (side * bounce)
        else
            Arena.currenty = 95 - bounce
        end
        
        -- stop bounce
        if bouncetimer == 20 then
            bounce = 0
            bouncetimer = 0
            Arena.speed = arenaspeed / 12
        end
    end
    
    
    
    -- update bullets
    for bul in next, bullets, bul do
        bul.Move(bul["xvel"], bul["yvel"])
        bul["yvel"] = bul["yvel"] - (1/20)
        
        if bul.absy - bul.sprite.height/2 < 0 then
            bul.sprite.StopAnimation()
            bul.Remove()
            bullets[bul] = nil
        end
    end
end

function lerp(a, b, t)
    return a + ((b - a) * t)
end

function OnHit(bullet)
    if not Player.isHurting then
        Player.Hurt(3, 1)
        bullet.sprite.StopAnimation()
        bullet.Remove()
        bullets[bullet["wrapped"]] = nil
    end
end

function EndingWave()
    Arena.speed = arenaspeed
    
    if fireball then
        fireball.Remove()
    end
end
