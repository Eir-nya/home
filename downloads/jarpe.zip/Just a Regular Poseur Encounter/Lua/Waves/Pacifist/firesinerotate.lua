require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



Arena.sprite.SetPivot(0.5, 0.5)
Arena.y = Arena.y + Arena.height/2
Arena.sprite.y = Arena.sprite.y + Arena.height/2

-- all bullets, active and inactive
bullets = {}

-- frame timer
timer = 0

-- 0: up, 1: left, 2: down, 3: right
dir = 0
-- time in frames between rotations
rotationtime = 145

NewAudio.CreateChannel("rotate")

function Update()
    timer = timer + 1
    
    -- create 1 fire projectile every 6 frames
    if timer%6 == 0 then
        local fire = CreateProjectile("Waves/Pacifist/Flame1", 0, Arena.height + (20 * math.sin(timer/57.5)))
        fire.sprite.SetAnimation({"flame1", "flame2"}, 1/6, "Waves/Pacifist")
        fire.sprite.SetParent(Arena.sprite)
        fire.sprite.rotation = Arena.rotation
        fire.sprite.MoveTo(fire.x, fire.y)
        fire.sprite.alpha = 0
        fire.SetVar("side", timer/6 % 2)
        fire.SetVar("stamp", timer)
        bullets[fire] = true
    end
    
    -- rotate arena
    if timer % rotationtime == rotationtime - 80 then
        NewAudio.PlaySound("rotate", "Waves/chain", true)
        Misc.ShakeScreen(3, 3, true)
    elseif timer % rotationtime >= rotationtime - 40 then
        Arena.rotation = (dir * 90) + (math.sin(math.rad(((timer % rotationtime - (rotationtime - 40)) / 40) * 90)) * 90)
    -- finish rotation
    elseif timer % rotationtime == 0 then
        dir = (dir + 1) % 4
        Arena.rotation = dir * 90
        NewAudio.Stop("rotate")
        Audio.PlaySound("Waves/drop")
        Misc.ShakeScreen(3, 3, true)
    end
    
    -- update all bullets
    for bullet in next, bullets, bullet do
        -- move them by certain amounts on x and y
        local xdif = (4*math.sin((timer - bullet.GetVar("stamp")) / ((15/2))))
        bullet.sprite.x = bullet.sprite.x + (bullet.GetVar("side") == 0 and xdif or -xdif)
        bullet.sprite.y = bullet.sprite.y - 1.5
        
        -- update for arena rotation
        bullet.sprite.rotation = Arena.rotation
        
        -- they are only visible when in the arena
        if bullet.sprite.y < Arena.height/2 and bullet.sprite.y > -Arena.height/2 then
            bullet.sprite.alpha = 1
        -- remove them when they exit the arena
        elseif bullet.sprite.y < 0 then
            bullet.sprite.StopAnimation()
            bullet.Remove()
            bullets[bullet] = nil
        end
    end
end

function OnHit(bullet)
    if not Player.isHurting then
        Player.Hurt(2, 1)
        bullet.sprite.StopAnimation()
        bullet.Remove()
        bullets[bullet["wrapped"]] = nil
    end
end

function EndingWave()
    NewAudio.DestroyChannel("rotate")
    
    Arena.rotation = 0
    
    Arena.sprite.ypivot = 0
    Arena.y = 95
    Arena.currenty = 95
    
    for bullet in next, bullets, bullet do
        if bullet.isactive then
            bullet.sprite.StopAnimation()
            bullet.Remove()
        end
    end
end
