require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



-- You've seen this one in the trailer (if you've seen the trailer).

soul = require "Libraries/shield"

--================================--
--[[
do
    local outline = CreateSprite("shield/outline", "Topper")
    outline.SetParent(Player.sprite)
    outline.MoveTo(0, 0)
    Player.sprite["outline"] = outline
end
]]--
--================================--

Encounter["enemies"][1].Call("loadstring", "anim.jojo = true ; anim.posecount = 3")

bullets = {}
timer = 0
mult = 0.5

deadline = 160

function Update()
    timer = timer + 1
    soul.Update()
    
    if timer < deadline and timer%30 == 0 then
        for i = 1, 10 do
            local bullet = CreateProjectile("Waves/Pacifist/bullet", 0, 260)
            bullet["timer"] = 0
            bullet["offset"] = math.pi * 2 * i / 10
            bullet["negmult"] = mult
            bullet["lerp"] = 0
            bullets[bullet] = true
            
            bullet["OnShield"] = function()
                bullet.Remove()
                bullets[bullet] = nil
                soul.bullets[bullet] = nil
            end
        end
        mult = mult + 0.05
        
        soul.bullets = bullets
    
    -- shake the screen #1
    elseif timer == deadline + 140 then
        Audio.PlaySound("Waves/fwoosh", 1)
        Misc.ShakeScreen(12, 4, true)
        
        Encounter["enemies"][1].Call("loadstring", "anim.posecount = 0")
    elseif timer == deadline + 230 then
        -- remove all bullets and shake the screen
        local bulletleft = false
        for bul in next, bullets, bul do
            bulletleft = true
            bul.Remove()
        end
        bullets = {}
        soul.bullets = bullets
        
        -- only activate if there is at least one bullet left
        if bulletleft then
            Misc.ShakeScreen(20, 12, true)
            Audio.PlaySound("Waves/drop", 0.9)
        end
    end
    
    -- sound time
    if timer == deadline then
        Audio.PlaySound("transform1", 0.5)
    elseif timer == deadline + 100 then
        Audio.PlaySound("bighit", 0.5)
    end
    
    -- update bullets
    for bul in next, bullets, bul do
        if timer <= deadline + 80 then
            bul.x = (70*bul["lerp"])*math.sin(bul["timer"]*bul["negmult"] + bul["offset"])
            bul.y = (70*bul["lerp"])*math.cos(bul["timer"] + bul["offset"]) + 260 - bul["lerp"]*50
            bul["timer"] = bul["timer"] + (timer < deadline and 1/40 or (1 - ((timer - deadline)/80))/40)
            bul["lerp"] = (bul["lerp"] + 1/90 > 4.0 and 4.0 or bul["lerp"] + 1/90)
            
        -- target the player
        elseif timer == deadline + 100 then
            local angle = math.deg(math.atan2(Player.y - bul.y, Player.x - bul.x)) + 90
            bul["xdir"] =  math.sin(math.rad(angle))
            bul["ydir"] = -math.cos(math.rad(angle))
        elseif timer > deadline + 100 and timer <= deadline + 120 then
            local mult = 1 - ((timer - (deadline + 100)) / 20)
            bul.Move(-bul["xdir"] * mult, -bul["ydir"] * mult)
        
        -- fly at the player
        elseif timer >= deadline + 140 then
            bul.Move(bul["xdir"] * 8, bul["ydir"] * 8)
        end
    end
end

function OnHit(bullet)
    if not Player.isHurting then
        Player.Hurt(3, 1)
        bullet.Remove()
        bullets[bullet["wrapped"]] = nil
    end
end

function EndingWave()
    Encounter["enemies"][1].Call("loadstring", "anim.jojo = false ; anim.posecount = 0")
    soul.EndWave()
end
