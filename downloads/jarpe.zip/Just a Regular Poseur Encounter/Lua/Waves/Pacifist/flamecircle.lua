require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



bullets = {}
local timer = -30

-- bg cover
local cover = CreateSprite("black", "Topper", 4)
cover.alpha = 0

local stamp = Time.time

function Update()
    timer = timer + 1
    
    if timer%15 == 0 then
        Audio.PlaySound("BeginBattle2", 0.4)
        
        -- create bullets
        local x = math.sin(math.rad(timer * 1.5)) * 300
        
        for i = 1, 10 do
            local ang = math.rad(((i / 10) * 360) % 360)
            local bul
            
            -- use a sprite object instead if the bullet can't possibly hit the player
            if -math.cos(ang) < 0 then
                bul = CreateProjectile("Waves/Pacifist/flame1", x, 220)
                bul.sprite.SetAnimation({"flame1", "flame2"}, 1/6, "Waves/Pacifist")
            else
                bul = CreateSprite("Waves/Pacifist/flame1", "Topper")
                bul.MoveToAbs(Arena.x + x, Arena.y + Arena.height/2 + 220)
                bul.SetAnimation({"flame1", "flame2"}, 1/6, "Waves/Pacifist")
            end
            
            bul["xdir"] =  math.sin(ang)
            bul["ydir"] = -math.cos(ang)
            bullets[bul] = true
        end
    end
    
    -- update bullets
    for bullet in next, bullets, bullet do
        bullet.Move(bullet["xdir"] * 3, bullet["ydir"] * 3)
    end
    
    
    
    -- cover shenanigans
    if timer <= 60 then
        cover.alpha = cover.alpha + (1/120)
    elseif Time.time - stamp >= (Encounter["realwavetimer"] - 1) then
        cover.alpha = cover.alpha - (1/120)
    end
end

function OnHit(bullet)
    if not Player.isHurting then
        Player.Hurt(2, 1)
        bullet.sprite.StopAnimation()
        bullet.Remove()
        bullets[bullet["wrapped"]] = nil
    end
end

function EndingWave()
    for bullet in next, bullets, bullet do
        if bullet.isactive then
            if tostring(bullet) == "ProjectileController" then
                bullet.sprite.StopAnimation()
            end
            bullet.Remove()
        end
    end
    
    cover.Remove()
end
