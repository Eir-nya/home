require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



local hand = CreateSprite("Waves/Pacifist/hand", "Topper")
hand.SetPivot(0, 0)
hand.rotation = 180
hand.Scale(-1, -1)
hand.x = Arena.x + Arena.width/2 - hand.width
hand.y = Arena.y
hand.alpha = 0

bullets = {}
local timer = -30

startSnap = 200

-- bg cover
local cover = CreateSprite("black", "Topper", 4)
cover.alpha = 0

local stamp = Time.time

function Update()
    timer = timer + 1
    
    if timer > 0 then
        -- move hand right
        if hand then
            -- generate second row of bullets
            if timer == startSnap then
                local toAdd = {}
                for bullet in next, bullets, bullet do
                    local bul = CreateProjectile("Waves/Pacifist/flame1", bullet.x, bullet.y)
                    bul.sprite.SetAnimation({"flame1", "flame2"}, 1/6, "Waves/Pacifist")
                    bul.sprite.MoveBelow(hand)
                    bul["ydir"] = 2
                    toAdd[bul] = true
                end
                
                for bul in next, toAdd, bul do
                    bullets[bul] = true
                end
            end
            
            -- move left
            if timer < 99 then
                hand.x = hand.x - 2.5
                
                -- create bullets
                if timer%16 == 2 then
                    Audio.PlaySound("BeginBattle2", 0.4)
                    
                    local bullet = CreateProjectile("Waves/Pacifist/flame1", hand.x - Arena.x + (hand.width/2), hand.y - (Arena.y + Arena.height/2) + (hand.height/2))
                    bullet.sprite.SetAnimation({"flame1", "flame2"}, 1/6, "Waves/Pacifist")
                    bullet.sprite.MoveBelow(hand)
                    bullet["ydir"] = 4
                    bullets[bullet] = true
                end
            
            -- animate
            elseif timer >= startSnap and timer <= startSnap + 10 then
                hand.y = lerp(hand.y, Arena.y - 7.5, 0.2)
                hand.rotation = lerp(hand.rotation, 187.5, 0.2)
            elseif timer >= startSnap + 40 and timer <= startSnap + 50 then
                -- it's a snap!
                if timer == startSnap + 40 then
                    hand.Set("Waves/Pacifist/hand_snap")
                    Audio.PlaySound("Waves/snap", 1)
                    
                    snap = CreateSprite("star0", "Topper")
                    snap.MoveBelow(hand)
                    snap.MoveToAbs(hand.absx + hand.width/2, hand.absy + hand.height)
                    snap.Scale(3, 3)
                    snap.rotation = math.random(0, 360)
                    snap.color = {1, 1, 0}
                
                -- animate snap
                else
                    snap.alpha = snap.alpha - (1/10)
                    snap.rotation = lerp(snap.rotation, 0, 0.025)
                    
                    -- remove condition
                    if timer == startSnap + 50 then
                        snap.Remove()
                        snap = nil
                    end
                end
                
                hand.y = lerp(hand.y, Arena.y, 0.2)
                hand.rotation = lerp(hand.rotation, 180, 0.2)
            
            -- enflame each bullet
            elseif timer > startSnap + 50 and timer % 3 == 0 then
                for bullet in next, bullets, bullet do
                    if not bullet["charge"] then
                        -- make bullet fly at player
                        bullet["charge"] = true
                        local angle = math.deg(math.atan2(Player.y - bullet.y, Player.x - bullet.x)) + 90
                        bullet["xdir"] =  math.sin(math.rad(angle))
                        bullet["ydir"] = -math.cos(math.rad(angle))
                        break
                    end
                end
            end
            
            -- remove condition
            if hand.alpha <= 0 then
                hand.Remove()
                hand = nil
            end
        end
        
        
        
        -- update bullets
        for bullet in next, bullets, bullet do
            -- move up
            if not bullet["charge"] and bullet["ydir"] > 0 then
                bullet["ydir"] = bullet["ydir"] - 0.04
                bullet.y = bullet.y + bullet["ydir"]
            
            -- skyrocket down
            elseif bullet["charge"] then
                bullet.Move(bullet["xdir"] * 12, bullet["ydir"] * 12)
            end
        end
    else
        -- fade in hand
        hand.alpha = hand.alpha + (1/20)
    end
    
    -- cover shenanigans
    if timer <= 60 then
        cover.alpha = cover.alpha + (1/120)
    elseif Time.time - stamp >= (Encounter["realwavetimer"] - 1) then
        cover.alpha = cover.alpha - (1/120)
    end
end

function lerp(a, b, t)
    return a + ((b - a) * t)
end

function OnHit(bullet)
    if not Player.isHurting then
        Player.Hurt(2, 1)
        bullet.sprite.StopAnimation()
        bullet.Remove()
        bullets[bullet["wrapped"]] = nil
    end
end

function EndingWave()
    if hand then
        hand.Remove()
    end
    
    if snap then
        snap.Remove()
    end
    
    cover.Remove()
    
    for bullet in next, bullets, bullet do
        if bullet.isactive then
            bullet.sprite.StopAnimation()
            bullet.Remove()
        end
    end
end
