require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



soul = require "Libraries/shield"

--================================--
--[[
do
    local outline = CreateSprite("shield/outline", "Topper")
    outline.SetParent(Player.sprite)
    outline.MoveTo(0, 0)
    Player.sprite["outline"] = outline
end
]]--
--================================--

do
    maskL = CreateSprite("px", "Topper")
    maskL.color = {0, 0, 0}
    maskL.SetPivot(1, 0)
    maskL.x = Arena.x - Arena.currentwidth/2 - 5
    maskL.y = Arena.y - 5
    maskL.Scale(320, 140)

    maskR = CreateSprite("px", "Topper")
    maskR.color = {0, 0, 0}
    maskR.SetPivot(0, 0)
    maskR.x = Arena.x + Arena.currentwidth/2 + 5
    maskR.y = Arena.y - 5
    maskR.Scale(320, 140)
end

timer  = -60
fballs =  {}

big1 = CreateProjectile("Waves/Pacifist/fireball0", -320,  30)
big1.sprite.MoveBelow(maskL)
big1.sprite.SetAnimation({"fireball0", "fireball1"}, 1/8, "Waves/Pacifist")
big1.sprite.Scale(2, 2)
big1.rotation = -90

big2 = CreateProjectile("Waves/Pacifist/fireball0", -320, -30)
big2.sprite.MoveBelow(maskL)
big2.sprite.SetAnimation({"fireball0", "fireball1"}, 1/8, "Waves/Pacifist")
big2.sprite.Scale(2, 2)
big2.rotation = -90

function Update()
    timer = timer + 1
    soul.Update()
    
    -- update masks
    maskL.x = Arena.x - Arena.currentwidth/2 - 5
    maskR.x = Arena.x + Arena.currentwidth/2 + 5
    
    -- move the player left
    if timer > 0 then
        local diff = (math.min(timer, 180) / 240)
        Player.x = math.max(Player.x - diff, -Arena.width/2 + Player.sprite.width/2)
        
        -- update fireballs here
        for fball in next, fballs, fball do
            fball.x = (fball.x - diff)
            
            if fball.x < -Arena.width/2 - 20 then
                fball.sprite.StopAnimation()
                fball.Remove()
                fballs[fball] = nil
            end
        end
        
        -- move big
        big1.x = big1.x + 0.4
        big2.x = big2.x + 0.4
    end
    
    -- create and update fireballs
    if timer > 0 and timer%120 == 0 then
        for i = 1, Arena.height/16 do
            local fball = CreateProjectile("Waves/Pacifist/flame3", Arena.width/2 + 16, -Arena.height/2 + (i * 16) - 8)
            fball.x = fball.x + math.random(-2, 2)
            fball.sprite.xscale = math.random() < 0.5 and -1 or 1
            fball.sprite.SetAnimation({"flame3", "flame4"}, 1/6, "Waves/Pacifist")
            fball.sprite.MoveBelow(maskL)
                
            fball["OnShield"] = function()
                fball.sprite.StopAnimation()
                fball.Remove()
                fballs[fball] = nil
            end
            
            fballs[fball] = true
        end
        
        soul.bullets = fballs
    end
    
    -- update big fireball
end

function OnHit(bullet)
    if bullet == big1 or bullet == big2 then
        Player.Hurt(5)
        Player.invulTimer = 1
        EndWave()
    else
        if not Player.isHurting then
            Player.Hurt(2, 1)
            bullet.sprite.StopAnimation()
            bullet.Remove()
            fballs[bullet["wrapped"]] = nil
        end
    end
end

function EndingWave()
    maskL.Remove()
    maskR.Remove()
    soul.EndWave()
    
    for fball in next, fballs, fball do
        if fball.isactive then
            fball.sprite.StopAnimation()
            fball.Remove()
            fballs[fball] = nil
        end
    end
end
