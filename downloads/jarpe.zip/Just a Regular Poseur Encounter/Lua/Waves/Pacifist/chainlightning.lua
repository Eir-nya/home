require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



timer = 0

bul = CreateProjectile("bullet", 0, Arena.height/2 - 8)
bul["xdir"] = math.random() < 0.5 and -1 or 1                   -- bul["xdir"] = -0.400625
bul["ydir"] = -1                                                -- bul["ydir"] = -0.6

speed = 3

-- axis: number: 0 for horizontal, 1 for vertical
function Reflect(axis)
    if axis == 0 then
        bul["xdir"] = -bul["xdir"]
        bul.x = (Arena.width/2 - bul.sprite.width/2) * (bul.x < 0 and -1 or 1)
    else
        bul["ydir"] = -bul["ydir"]
        bul.y = (Arena.height/2 - bul.sprite.height/2) * (bul.y < 0 and -1 or 1)
    end
    
    local ang = math.deg(math.atan2(bul["ydir"], bul["xdir"])) + 90
    ang = ang + (-15 + (math.random() * 30))
    bul["xdir"] =  math.sin(math.rad(ang))
    bul["ydir"] = -math.cos(math.rad(ang)) 
    
    
    
    lines[currentline] = true
    currentline = CreateProjectile("px", bul.x, bul.y)
    currentline.sprite.alpha = 0.25
    currentline.ppcollision = true
    currentline.sprite.xpivot = 0
    currentline.sprite.rotation = ang - 90
end

lines = {}
currentline = CreateProjectile("px", bul.x, bul.y)
currentline.sprite.alpha = 0.25
currentline.ppcollision = true
currentline.sprite.xpivot = 0
local ang = math.deg(math.atan2(bul["ydir"], bul["xdir"]))
currentline.sprite.rotation = ang

function Update()
    timer = timer + 1
    
    if bul.sprite.spritename ~= "Waves/Pacifist/dvd" then
        bul.sprite.rotation = bul.sprite.rotation + (2.5 * (bul["xdir"] < 0 and 1 or -1))
    end
    bul.Move(bul["xdir"] * speed, bul["ydir"] * speed)
    
    
    
    currentline.sprite.xscale = math.sqrt((bul.y - currentline.y)^2 + (bul.x - currentline.x)^2)
    
    
    
    -- reflect
    -- first: calculate if it hit the corner (not PERFECTLY, mind you, just close enough)
    if Arena.width/2 - bul.sprite.width/2 - math.abs(bul.x) < 1 and Arena.height/2 - bul.sprite.height/2 - math.abs(bul.y) < 1 then
        bul.sprite.Set("Waves/Pacifist/dvd")
        bul.sprite.rotation = 0
    end
    
    if bul.x - bul.sprite. width/2 < -Arena. width/2 or bul.x + bul.sprite. width/2 > Arena. width/2 then
        Reflect(0)
    end
    
    if bul.y - bul.sprite.height/2 < -Arena.height/2 or bul.y + bul.sprite.height/2 > Arena.height/2 then
        Reflect(1)
    end
    
    
    
    -- update lines
    for line in next, lines, line do
        
        -- decrease alpha
        if line.sprite.alpha < 1 and line.sprite.alpha > 0then
            line.sprite.alpha = line.sprite.alpha - 0.0125
        
        -- set animation
        elseif line.sprite.alpha == 0 then
            Misc.ShakeScreen(8, 4)
            Audio.PlaySound("Waves/shock" .. math.random(1, 2), 0.3)
            
            line.sprite.alpha = 1
            line.sprite.Set("Waves/bolt1")
            line.sprite.SetAnimation({"bolt1", "bolt2", "bolt3"}, 1/8, "Waves")
            line.sprite.loopmode = "ONESHOT"
            line.sprite.xscale = line.sprite.xscale / line.sprite.width
        
        -- remove condition
        elseif line.sprite.animcomplete then
            line.sprite.StopAnimation()
            line.Remove()
            lines[line] = nil
        end
    end
end

function OnHit(bullet)
    if bullet == bul then
        Player.Hurt(1, 1)
    elseif bullet.sprite.alpha == 1 then
        Player.Hurt(3, 1)
    end
end
