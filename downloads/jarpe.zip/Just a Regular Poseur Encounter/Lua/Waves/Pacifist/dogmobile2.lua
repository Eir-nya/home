require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



blue = require "Libraries/bluesoul"
blue.Initialize({})
-- blue.speed = 4
Audio.PlaySound("ding")

soul = require "Libraries/shield"
soul.jump = false

--================================--
--[[
do
    local outline = CreateSprite("shield/outline", "Topper")
    outline.SetParent(Player.sprite)
    outline.MoveTo(0, 0)
    Player.sprite["outline"] = outline
end
]]--
--================================--



plat = CreateProjectile("Waves/Pacifist/plat4", 0, 0)
plat.sprite.SetParent(Arena.sprite)
plat.sprite.SendToBottom()
blue.platforms = { plat }

-- car sound effects, very important
NewAudio.CreateChannel("car")
NewAudio.PlaySound("car", "Waves/engine", true, 0.5)

timer = 238

fallingdogs = {}
smokes = {}
pattern = 0 -- 0: lDog on top, rDog on bottom. 1: lDog on bottom, rDog on top

function Update()
    timer = timer + 1
    
    blue.Update()
    --[[
    if Input.Confirm == 1 then
        soul.jump = not blue.CheckIfGrounded()
    else
        soul.jump = false
    end
    ]]--
    soul.Update()
    
    -- make dog appear
    if timer%240 < 120 then
        if not safe then
            lDog.y = lerp(lDog.y, pattern == 0 and 10 or -lDog.sprite.height*1.25, 0.1) + (math.sin(timer/12) * 1.5)
            rDog.y = lerp(rDog.y, pattern == 1 and 10 or -rDog.sprite.height*1.25, 0.1) + (math.sin(timer/12) * 1.5)
        else
            lDog.y = lDog.y + (math.min(math.abs(lDog.y - (pattern == 0 and 10 or -lDog.sprite.height*1.25)), 8) * ((pattern == 0 and 10 or -lDog.sprite.height*1.25) < lDog.y and -1 or 1))
            rDog.y = rDog.y + (math.min(math.abs(rDog.y - (pattern == 1 and 10 or -rDog.sprite.height*1.25)), 8) * ((pattern == 1 and 10 or -rDog.sprite.height*1.25) < rDog.y and -1 or 1))
        end
    elseif timer%240 == 120 then
        Audio.PlaySound("flash", 0.5)
        Misc.ShakeScreen(6, 30, false)
    elseif timer%240 > 120 and timer%240 < 239 then
        if lDog then
            lDog.x = lDog.x + (((timer%240)-120) / 3.5)
        end
        if rDog then
            rDog.x = rDog.x - (((timer%240)-120) / 3.5)
        end
        
        if lDog or rDog then
            NewAudio.SetVolume("car", NewAudio.GetVolume("car") - (1/240))
        else
            NewAudio.SetVolume("car", 0)
        end
    elseif timer%240 == 239 then
        -- remove all dogs
        if lDog then
            lDog.Remove()
        end
        if rDog then
            rDog.Remove()
        end
        
        -- create new dogs
        pattern = math.random() < 0.5 and 0 or 1
        
        lDog = CreateProjectile("Waves/Pacifist/dogmobile" .. (math.random() < 0.5 and 1 or 2), -Arena.width/2 - 100, 480)
        lDog.sprite.ypivot = 0
        lDog.ppcollision = true
        
        rDog = CreateProjectile("Waves/Pacifist/dogmobile" .. (lDog.sprite.spritename:sub(-1, -1) == "2" and (math.random() < 0.5 and 1 or 2) or "2"),  Arena.width/2 + 100, 480)
        rDog.sprite.ypivot = 0
        rDog.sprite.xscale = -1
        rDog.ppcollision = true
        
        if lDog.sprite.spritename:sub(-1, -1) == "2" then
            soul.bullets[lDog] = true
            lDog["OnShield"] = function()
                local spr = CreateSprite("Waves/Pacifist/dogmobile3", "Topper")
                spr.MoveToAbs(lDog.absx, lDog.absy + lDog.sprite.height/2)
                spr["ydir"] = -1 + (math.random() * 2)
                fallingdogs[spr] = true
                
                lDog.Remove()
                lDog = nil
            end
        end
        if rDog.sprite.spritename:sub(-1, -1) == "2" then
            soul.bullets[rDog] = true
            rDog["OnShield"] = function()
                local spr = CreateSprite("Waves/Pacifist/dogmobile3", "Topper")
                spr.MoveToAbs(rDog.absx, rDog.absy + rDog.sprite.height/2)
                spr.xscale = -1
                spr["ydir"] = -1 + (math.random() * 2)
                fallingdogs[spr] = true
                
                rDog.Remove()
                rDog = nil
            end
        end
    end
    
    -- update falling dogs
    for fdog in next, fallingdogs, fdog do
        fdog.x = fdog.x - (fdog.xscale * 6)
        fdog.y = fdog.y + fdog["ydir"]
        fdog.rotation = fdog.rotation + (fdog.xscale * 3)
        
        -- remove condition
        if fdog.x < -fdog.width or fdog.x > 640 + fdog.width then
            fdog.Remove()
            fallingdogs[fdog] = nil
        end
    end
    
    -- smoak
    if timer%32 == 16 then
        if not safe or (safe and timer%240 >= 48 and timer%240 <= 128) then
            local played = false
            for i = 1, 2 do
                if ({lDog, rDog})[i] then
                    -- play little puff sound
                    if not played then
                        Audio.PlaySound("BeginBattle2", (timer%240 <= 120) and 0.3 or 0.5 - ((((timer%240) - 120)/120)/2))
                        played = true
                    end
                    
                    local smoke = CreateSprite("paper", "Topper")
                    smoke.rotation = math.random() * 360
                    smoke.Scale(0.75, 0.75)
                    smoke.xscale = smoke.xscale * ({lDog, rDog})[i].sprite.xscale
                    smoke.color = (timer%240 < 48 or timer%240 > 128) and {0.3, 0.3, 0.3}
                        or ({
                             [48] = {  1, 0.3, 0.3},  [64] = {  1, 0.3, 0.3},
                             [80] = {  1,   1, 0.3},  [96] = {  1,   1, 0.3},
                            [112] = {0.3,   1, 0.3}, [128] = {0.3,   1, 0.3},
                    })[timer%240]
                    
                    smoke.MoveToAbs(({lDog, rDog})[i].absx - (48 * ({lDog, rDog})[i].sprite.xscale), ({lDog, rDog})[i].absy + 10)
                    
                    smokes[smoke] = true
                end
            end
        end
    end
    
    -- update smoak
    for smoke in next, smokes, smoke do
        smoke.rotation = smoke.rotation + 1
        smoke.alpha = smoke.alpha - (1/30)
        smoke.x = smoke.x - ((1 + (1/3)) * smoke.xscale)
        
        if smoke.alpha == 0 then
            smoke.Remove()
            smokes[smoke] = nil
        end
    end
end

function lerp(a, b, t)
    return a + ((b - a) * t)
end

function OnHit(bullet)
    if bullet ~= plat then
        Player.Hurt(3, 1)
    end
end

function EndingWave()
    NewAudio.DestroyChannel("car")
    
    for fdog in next, fallingdogs, fdog do
        fdog.Remove()
    end
    
    for smoke in next, smokes, smoke do
        smoke.Remove()
    end
    
    soul.EndWave()
end
