local shield = {}

NewAudio.CreateChannel("block")

shield.maxcooldown = 60     -- time between shield bursts
shield.cooldown = 0         -- actual number that gets counted down to 0 between shield bursts
shield.coolingdown = false  -- whether cooldown is currently going on

shield.projectiles = {}     -- shields that come out and block damage
shield.speed1 = 0.1         -- speed at which the normal projectile lerps to its destination
shield.speed2 = 0.025       -- speed at which the bouncy projectile lerps to its destination
shield.distance = 16        -- distance in pixels for shields to travel
shield.bullets = {}         -- a table of projectiles that can be blocked by the shield projectiles. set this from the wave script

shield.active = true        -- whether the player can press Z to Protecc
shield.jump = blue ~= nil   -- whether an executed Protecc() call will spawn a jumpy shield. set this from the wave script
shield.jumpamount = 5.4     -- amount of jump to apply to the blue soul library upon touching the boost shield
shield.bouncyexists = false -- whether a bouncy shield projectile already exists. if it does, remove the old one for a new one
shield.rings = {}           -- rings created to show boost whenever the player does a shield jump
shield.ringtimer = 0        -- counts down from 24 whenever you bounce. on 12 and 0, creates a ring particle.
shield.ringstart = {}       -- the position the player was at whenever they started the bounce

shield.sparkles = {}        -- sparkles made when blocking something

local bolt                  -- lightning strike that appears whenever you spawn your shield projectiles



if Player.sprite["outline"] then
    Player.sprite["outline"].alpha = 1
end



-- update function
shield.Update = function()
    -- test for input
    if Input.Confirm == 1 and shield.active and shield.cooldown == 0 then
        shield.Protecc()
    
    -- cooldown
    elseif shield.cooldown > 0 and shield.coolingdown then
        shield.cooldown = shield.cooldown - 1
        
        shield.coolingdown = shield.cooldown > 0
    end
    
    -- alpha stuff
    if shield.active then
        Player.sprite["outline"].alpha = (1 - (shield.cooldown / shield.maxcooldown)) * Player.sprite.alpha
    end
    
    
    
    -- update sparkles
    for sparkle in next, shield.sparkles, sparkle do
        sparkle.rotation = sparkle.rotation + sparkle["turnspeed"]
        sparkle.SetVar("turnspeed", sparkle.GetVar("turnspeed") - (sparkle.GetVar("turnspeed")/10))
        sparkle.Move(math.sin(math.rad(sparkle.GetVar("direction"))) / 10,
                     math.cos(math.rad(sparkle.GetVar("direction"))) / 10)
        
        sparkle.alpha = sparkle.alpha - 0.0125
        if sparkle.alpha == 0 then
            sparkle.Remove()
            shield.sparkles[sparkle] = nil
        end
    end
    
    -- update shield thing
    if shield.shield and shield.shield.isactive then
        shield.shield.xscale = shield.shield.xscale + 0.05
        shield.shield.yscale = shield.shield.xscale
        shield.shield.alpha = shield.shield.alpha - 0.025
        
        if shield.shield.alpha == 0 then
            shield.shield.Remove()
        end
    end
    
    -- handle all shield projectiles
    for proj in next, shield.projectiles, proj do
        -- normal shield
        if proj.spritename:sub(-7, -2) ~= "bounce" then
            -- if active
            if not proj["dying"] then
                proj.x = proj.x + (((proj["startx"] + (proj["xdir"] * shield.distance)) - proj.x) * shield.speed1)
                proj.y = proj.y + (((proj["starty"] + (proj["ydir"] * shield.distance)) - proj.y) * shield.speed1)
                
                -- remove condition
                if  math.abs((proj["startx"] + (proj["xdir"] * shield.distance)) - proj.x) < 0.1
                and math.abs((proj["starty"] + (proj["ydir"] * shield.distance)) - proj.y) < 0.1 then
                    proj["dying"] = true
                    proj.SetAnimation({proj.spritename,
                                       "shield/protecc" .. (tonumber(proj.spritename:sub(-1, -1)) + 1),
                                       "shield/protecc" .. (tonumber(proj.spritename:sub(-1, -1)) + 2)}, 1/16)
                    proj.loopmode = "ONESHOT"
                    
                    shield.coolingdown = true
                end
            
            
            
            -- CHECK COLLISION WITH BLOCKABLE BULLETS
            for bul in next, shield.bullets, bul do
                if math.abs(bul.absx - proj.absx) > math.max(bul.sprite.width, bul.sprite.height) + proj.width then
                    goto next
                elseif bul.isactive then
                    -- handle collision with bullet
                    local   left_side = proj.absx - ((1 - ((proj["xdir"] + 1) / 2)) * (proj["xdir"] == 0 and proj. width or proj.height))
                    local  right_side = proj.absx + (     ((proj["xdir"] + 1) / 2)  * (proj["xdir"] == 0 and proj. width or proj.height))
                    local bottom_side = proj.absy - ((1 - ((proj["ydir"] + 1) / 2)) * (proj["ydir"] == 0 and proj. width or proj.height))
                    local    top_side = proj.absy + (     ((proj["ydir"] + 1) / 2)  * (proj["ydir"] == 0 and proj. width or proj.height))
                    
                    if  bul.absx - bul.sprite. width/2 <  right_side and bul.absx + bul.sprite. width/2 > left_side
                    and bul.absy + bul.sprite.height/2 > bottom_side and bul.absy - bul.sprite.height/2 <  top_side then
                        if bul["OnShield"] then
                            bul["OnShield"]()
                        else
                            bul.Remove()
                            shield.bullets[bul] = nil
                        end
                        
                        -- sparkle efect and sound effect
                        NewAudio.PlaySound("block", "shield/block")
                        Misc.ShakeScreen(2, 1, false)
                        
                        if not safe then
                            local sparkle = CreateSprite("Waves/Pacifist/tetris/star", "Topper")
                            sparkle.MoveToAbs(bul.absx, bul.absy)
                            sparkle.SetParent(Arena.sprite)
                            sparkle.MoveAbove(Player.sprite)
                            sparkle.rotation = math.random(0, 360)
                            sparkle.alpha = 0.5
                            sparkle.SetVar("turnspeed", math.random(-10, 10))
                            sparkle.SetVar("direction", math.random(0, 360))
                            shield.sparkles[sparkle] = true
                        end
                    end
                end
                
                ::next::
            end
            
            -- dying
            elseif proj.animcomplete then
                proj.Remove()
                shield.projectiles[proj] = nil
            end
        
        -- bouncy boy
        else
            -- if active
            if not proj["dying"] then
                proj.absy = proj.absy + (((proj["starty"] - shield.distance) - proj.absy) * shield.speed2)
                
                -- other remove condition
                if  Player.absx > proj.absx - proj.width/1.5 and Player.absx < proj.absx + proj.width/1.5
                and Player.absy - Player.sprite.height/2 > proj["starty"] - shield.distance - proj.height/2 and Player.absy - Player.sprite.height/2 <= proj.absy then
                    proj["dying"] = true
                    proj.SetAnimation({"bounce1", "bounce2", "bounce3"}, 1/16, "shield")
                    proj.loopmode = "ONESHOT"
                    shield.bouncyexists = false
                    
                    Player.MoveTo(proj.absx - Arena.x, proj.absy - (Arena.y + Arena.height/2) + proj.height)
                    shield.Bounce()
                end
                
                -- remove condition
                if (proj.absy - (proj["starty"] - shield.distance)) < 0.1 then
                    proj["dying"] = true
                    proj.SetAnimation({"bounce1", "bounce2", "bounce3"}, 1/16, "shield")
                    proj.loopmode = "ONESHOT"
                    shield.bouncyexists = false
                end
            
            -- dying
            elseif proj.animcomplete then
                proj.Remove()
                shield.projectiles[proj] = nil
            end
        end
    end
    
    
    
    if shield.ringtimer > 0 then
        shield.ringtimer = shield.ringtimer - 1
        
        if shield.ringtimer == 12 or shield.ringtimer == 0 then
            -- calculate angle of player relative to where they started from
            local ang = math.atan2(Player.absy - shield.ringstart.y, Player.absx - shield.ringstart.x)
            
            local ringF = CreateSprite("shield/boost", "Topper")
            ringF.SetParent(Arena.sprite)
            ringF.MoveToAbs(Player.absx, Player.absy)
            ringF.MoveAbove(Player.sprite)
            ringF.rotation = math.deg(ang) - 90
            ringF.ypivot = 1
            
            local ringB = CreateSprite("shield/boost", "Topper")
            ringB.SetParent(Arena.sprite)
            ringB.MoveToAbs(Player.absx, Player.absy)
            ringB.MoveBelow(Player.sprite)
            ringB.rotation = ringF.rotation + 180
            ringB.ypivot = 1
            
            shield.rings[ringF] = true
            shield.rings[ringB] = true
        end
    end
    
    -- handle rings
    for ring in next, shield.rings, ring do
        ring.alpha = ring.alpha - (1/60)
        ring.xscale = ring.xscale + (1/60)
        ring.yscale = ring.yscale + (1/120)
        
        if ring.alpha == 0 then
            ring.Remove()
            shield.rings[ring] = nil
        end
    end
end

-- spawn shields
function shield.Protecc()
    Audio.PlaySound("shield/protecc")
    
    shield.cooldown = shield.maxcooldown
    Player.sprite["outline"].alpha = 0
    
    Misc.ShakeScreen(3, 3, true)
    
    
    
    if bolt and bolt.isactive then
        bolt.Remove()
    end
    bolt = CreateSprite("Waves/bolt1", "Topper")
    bolt.MoveToAbs(Player.absx, Player.absy)
    bolt.SetParent(Arena.sprite)
    bolt.MoveBelow(Player.sprite)
    bolt.SetAnimation({"bolt1", "bolt2", "bolt3"}, 1/16, "Waves")
    bolt.loopmode = "ONESHOTEMPTY"
    
    -- create  left shield
    local sh = CreateSprite("shield/protecc" .. (math.random() < 0.01 and "4" or "1"), "Topper")
    sh.rotation = 90
    sh.ypivot = 0
    sh.SetParent(Player.sprite)
    sh.MoveTo(0, 0)
    sh.x = -Player.sprite.width/2
    sh.layer = "Topper"
    
    sh["startx"] = sh.x
    sh["starty"] = sh.y
    sh["xdir"]   = -1
    sh["ydir"]   =  0
    shield.projectiles[sh] = true
    
    -- create right shield
    local sh = CreateSprite("shield/protecc" .. (math.random() < 0.01 and "4" or "1"), "Topper")
    sh.rotation = 90
    sh.xscale = -1
    sh.ypivot = 0
    sh.SetParent(Player.sprite)
    sh.MoveTo(0, 0)
    sh.x =  Player.sprite.width/2
    sh.layer = "Topper"
    
    sh["startx"] = sh.x
    sh["starty"] = sh.y
    sh["xdir"]   =  1
    sh["ydir"]   =  0
    shield.projectiles[sh] = true
    
    -- create top shield
    local sh = CreateSprite("shield/protecc" .. (math.random() < 0.01 and "4" or "1"), "Topper")
    sh.ypivot = 0
    sh.SetParent(Player.sprite)
    sh.MoveTo(0, 0)
    sh.y =  Player.sprite.height/2
    sh.layer = "Topper"
    
    sh["startx"] = sh.x
    sh["starty"] = sh.y
    sh["xdir"]   =  0
    sh["ydir"]   =  1
    shield.projectiles[sh] = true
    
    -- create bottom shield
    if not shield.jump then
        -- normal
        
        local sh = CreateSprite("shield/protecc" .. (math.random() < 0.01 and "4" or "1"), "Topper")
        sh.ypivot = 0
        sh.yscale = -1
        sh.SetParent(Player.sprite)
        sh.MoveTo(0, 0)
        sh.y = -Player.sprite.height/2
        sh.layer = "Topper"
        
        sh["startx"] = sh.x
        sh["starty"] = sh.y
        sh["xdir"]   =  0
        sh["ydir"]   = -1
        shield.projectiles[sh] = true
    else
        -- bouncy
        
        -- remove old bouncy projectile if it exists
        if shield.bouncyexists then
            for proj in next, shield.projectiles, proj do
                if proj.spritename:sub(-7, -2) == "bounce" then
                    proj["dying"] = true
                    proj.SetAnimation({"bounce1", "bounce2", "bounce3"}, 1/16, "shield")
                    proj.loopmode = "ONESHOT"
                end
            end
            
            shield.bouncyexists = false
        end
        
        local sh = CreateSprite("shield/bounce1", "Topper")
        sh.ypivot = 0
        sh.SetParent(Player.sprite)
        sh.MoveTo(0, 0)
        
        -- try to keep shield in bounds
        sh.y = -Player.sprite.height
        if sh.absy - shield.distance - Arena.y < 0 then
            sh.absy = shield.distance + Arena.y
        end
        
        sh.SetParent(Arena.sprite)
        sh.MoveBelow(Player.sprite)
        
        sh["starty"] = sh.absy
        shield.projectiles[sh] = true
        
        shield.bouncyexists = true
    end
    
    shield.shield = CreateSprite("shield/shield", "Topper")
    shield.shield.MoveToAbs(Player.absx, Player.absy)
    shield.shield.alpha = 0.5
end



-- for whenever the player bounces
function shield.Bounce()
    Audio.PlaySound("shield/boost")
    blue.SetJump(shield.jumpamount)
    
    if not safe then
        shield.ringtimer = 24
        shield.ringstart = { x = Player.absx, y = Player.absy }
    end
end

-- ending wave function
-- necessary as everything in this library is a sprite object
function shield.EndWave()
    NewAudio.DestroyChannel("block")
    
    Player.sprite["outline"].alpha = 1
    
    for sparkle in next, shield.sparkles, sparkle do
        if sparkle.isactive then
            sparkle.Remove()
        end
    end
    
    for proj in next, shield.projectiles, proj do
        if proj.isactive then
            proj.Remove()
        end
    end
    
    if shield.shield and shield.shield.isactive then
        shield.shield.Remove()
    end
    
    for ring in next, shield.rings, ring do
        ring.Remove()
    end
end



return shield
