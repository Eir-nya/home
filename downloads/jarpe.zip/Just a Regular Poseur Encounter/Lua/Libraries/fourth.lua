-- BIG SECRET FILE
-- If you're not supposed to be here, get out!!!!!!!










-- Killer Queen's first function: Preloads resources for the sequence and shows itself
_G["Killer Queen"] = function()
    -- preload all graphics
    local allGraphics = {
        "killer queen", "bites", "the dust",
        "mask1", "mask2",
        "aura",
        "lines1", "lines2", "lines3", "lines4",
        "overlay1", "overlay2",
        "encounter skeleton", "examples", "examples 2", "rtlgeno",
        "menacingsymbol", "menacingtext",
    }
    preloader = CreateSprite("empty")
    for i = 1, #allGraphics do
        preloader.Set("fourth/" .. allGraphics[i])
    end
    preloader.Remove()
    preloader = nil
    
    -- preload sound
    Audio.Stop()
    NewAudio.CreateChannel("death glare")
    NewAudio.PlaySound("death glare", "fourth/click", false, 0)
    NewAudio.PlaySound("death glare", "fourth/death glare", false, 0)
    NewAudio.CreateChannel("void")
    NewAudio.PlaySound("void", "Waves/void", false, 0)
    
    -- killer queen
    queen = CreateSprite("fourth/killer queen", "Topper")
    queen.SetPivot(0, 0)
    queen.MoveTo(32.4, 53)
    
    unescape = true
    
    -- stand aura mask
    if CYFversion > "0.6.3" then
        mask = CreateSprite("fourth/mask1")
        mask.SetParent(queen)
        mask.SetPivot(0, 1)
        mask.SetAnchor(0, 1)
        mask.MoveTo(0, 0)
        mask.Mask("stencil")
        
        -- stand aura
        aura = CreateSprite("fourth/aura")
        aura.alpha = 0
        aura.SetParent(mask)
        aura.SetPivot(0, 1)
        aura.SetAnchor(0, 1)
        aura.MoveTo(0, 0)
    end
    
    Update = nil
end

-- Killer Queen's second function: crawls out
_G["Daisan No Bakudan"] = function()
    queen.Set("fourth/bites")
    if mask then
        mask.alpha = 1
        aura.alpha = 1
    end
    Audio.PlaySound("fourth/click", 0.5)
    
    -- Update aura
    if aura then
        function Update()
            aura.x = (math.sin(math.rad(Time.time*60)) * 48) - 48
            aura.y = (aura.y + 1) % 480
        end
    end
end

-- Killer Queen's third function: everything else...!
_G["Bites The Dust!"] = function()
    -- Updates the zoom amount on everything that has to be scaled from the battle scene
    local updateZoom = function()
        queen.Scale(screenshot.xscale, screenshot.xscale)
        if mask then
            mask.Scale(screenshot.xscale, screenshot.xscale)
            aura.Scale(screenshot.xscale, screenshot.xscale)
        end
        lines.Scale(screenshot.xscale, screenshot.xscale)
        
        bg.Scale(screenshot.xscale, screenshot.yscale)
        enemies[1]["monstersprite"].Scale(screenshot.xscale, screenshot.yscale)
        
        fakearena.arena.Scale(screenshot.xscale * arenasize[1], screenshot.yscale * arenasize[2])
        fakearena.top.xscale = fakearena.arena.xscale
        fakearena.bottom.xscale = fakearena.arena.xscale
        fakearena.left.yscale = fakearena.arena.yscale
        fakearena.right.yscale = fakearena.arena.yscale
        
        fight.Scale(screenshot.xscale, screenshot.yscale)
        act.Scale(screenshot.xscale, screenshot.yscale)
        item.Scale(screenshot.xscale, screenshot.yscale)
        mercy.Scale(screenshot.xscale, screenshot.yscale)
        NameLV.Scale(screenshot.xscale, screenshot.yscale)
        NameLVText.Scale(screenshot.xscale, screenshot.yscale)
        HPLabel.Scale(screenshot.xscale, screenshot.yscale)
        HPBG.Scale(screenshot.xscale * Player.maxhp * 1.2, screenshot.yscale * 20)
        HPFG.Scale(screenshot.xscale * Player.hp * 1.2, screenshot.yscale * 20)
        HPText.Scale(screenshot.xscale, screenshot.yscale)
        HPTextText.Scale(screenshot.xscale, screenshot.yscale)
    end
    
    -- Update function (part 1: killer queen reveal)
    timer = 0
    function Update()
        timer = timer + 1
        
        -- Begin zoom effect
        if timer == 1 then
            -- basically what we're doing here is moving everything active in the scene right now to make it look like the entire screen is being zoomed in
            screenshot = CreateSprite("black", "Topper")
            
            local center = function(obj)
                obj.SetParent(screenshot)
                local absx, absy = obj.absx, obj.absy
                obj.SetAnchor(obj.absx / 640, obj.absy / 480)
                obj.MoveToAbs(absx, absy)
            end
            
            CreateSprite("black").SetParent(screenshot)
            center(bg) -- battle background (that cool grid thing)
            center(enemies[1]["monstersprite"]) -- enemy sprite
            center(fakearena.arena) -- fake arena (and all its children)
            
            -- buttons
            fight = CreateSprite("UI/Buttons/fightbt_0")
            fight.SetPivot(0, 0)
            fight.MoveToAbs(32, 6)
            center(fight)
            
            act = CreateSprite("UI/Buttons/actbt_0")
            act.ypivot = 0
            act.MoveToAbs(240, 6)
            center(act)
            
            item = CreateSprite("UI/Buttons/itembt_0")
            item.ypivot = 0
            item.MoveToAbs(400, 6)
            center(item)
            
            mercy = CreateSprite("UI/Buttons/mercybt_0")
            mercy.SetPivot(1, 0)
            mercy.MoveToAbs(610, 6)
            center(mercy)
            
            -- player name and lv
            NameLV = CreateSprite("empty")
            NameLV.SetPivot(0, 0)
            NameLV.MoveToAbs(31, 62)
            
            NameLVText = CreateText("[instant][font:uibattlesmall]" .. string.upper(Player.name) .. "  LV " .. Player.lv, {31, 62}, 640)
            NameLVText.HideBubble()
            NameLVText.progressmode = "none"
            NameLVText.SetParent(NameLV)
            NameLVText.MoveTo(0, 0)
            center(NameLV)
            
            -- Create hp stuff
            HPLabel = CreateSprite("UI/spr_hpname_0")
            HPLabel.SetPivot(0, 0)
            HPLabel.MoveToAbs(244, 65)
            center(HPLabel)
            
            HPBG = CreateSprite("px")
            HPBG.SetPivot(0, 0)
            HPBG.MoveToAbs(275.5, 59.5)
            HPBG.Scale(Player.maxhp * 1.2, 20)
            HPBG.color = {1, 0, 0}
            center(HPBG)
            
            HPFG = CreateSprite("px")
            HPFG.SetParent(HPBG)
            HPFG.SetPivot(0, 0)
            HPFG.SetAnchor(0, 0)
            HPFG.MoveTo(0, 0)
            HPFG.Scale(Player.hp * 1.2, 20)
            HPFG.color = {1, 1, 0}
            -- center(HPFG)
            
            HPText = CreateSprite("empty")
            HPText.SetPivot(0, 0)
            HPText.MoveToAbs(HPBG.absx + HPBG.xscale + 16, 62)
            
            HPTextText = CreateText("[instant][font:uibattlesmall]" .. Player.hp .. " / " .. Player.maxhp, {0, 0}, 640)
            HPTextText.HideBubble()
            HPTextText.progressmode = "none"
            --HPTextText.MoveTo(HPBG.absx + HPBG.xscale + 16, 3)
            HPTextText.SetParent(HPText)
            HPTextText.MoveTo(0, 0)
            center(HPText)
            
            
            
            -- killer queen and stand aura
            queen.Set("fourth/the dust")
            queen.SetParent(screenshot)
            queen.MoveToAbs(40, 60)
            
            if mask then
                mask.Set("fourth/mask2")
                mask.MoveTo(-4, 4)
            end
            
            -- screen shake
            Misc.ShakeScreen(12)
            
            -- sound effect
            Audio.PlaySound("hitsound")
            NewAudio.PlaySound("death glare", "fourth/death glare", false, 1)
            
            -- "screenshot" manipulation
            screenshot.SetPivot(0.2, 0.2)
            screenshot.MoveToAbs(640 * 0.2, 480 * 0.2)
            screenshot.Scale(2, 2)
            
            -- prepare scaling
            queen.SetAnchor(0.2, 0.2)
            queen.SetPivot(0.5, 0.2)
            queen.MoveTo(0, 0)
            
            -- speed lines
            lines = CreateSprite("fourth/lines1")
            lines.SetAnimation({"lines1", "lines2", "lines3", "lines4"}, 1/15, "fourth")
            lines.SetParent(screenshot)
            lines.SetAnchor(0.5, 0.5)
            lines.MoveTo(0, 0)
            
            updateZoom()
        -- Zoom effect
        elseif timer > 1 and timer < 60 then
            screenshot.xscale = lerp(screenshot.xscale, 1, 0.08)
            screenshot.yscale = screenshot.xscale
            
            updateZoom()
        -- Start enemy text
        elseif timer == 80 then
            bubblesprite = CreateSprite("UI/SpeechBubbles/rightwide", "Topper")
            bubblesprite.xpivot = 0
            bubblesprite.MoveTo(374, 350)
            
            bubbletext = CreateText("[noskip]Press [color:ff0000]ESC[color:000000]![w:10] Hurry![w:10] [lettereffect:shake,0.1]Before it's too late!...", {410, 380}, 180, "Topper")
            bubbletext.HideBubble()
            bubbletext.progressmode = "none"
            bubbletext.SetParent(bubblesprite)
            
            bubblesprite.SetParent(screenshot)
            bubblesprite.MoveBelow(lines)
        -- Await player's button press, and prepare to kill
        elseif timer > 80 and not NewAudio.isStopped("death glare") then
            
            -- While waiting, start to shake the screen according to how close the audio is to finishing
            local shakeamount = math.max((NewAudio.GetPlayTime("death glare") - 2), 0)
            Misc.cameraX = shakeamount * math.random()
            Misc.cameraY = shakeamount * math.random()
            lines.MoveToAbs(320 + Misc.cameraX, 240 + Misc.cameraY)
            queen.MoveTo(Misc.cameraX, Misc.cameraY)
            
            -- Show mod selection screen
            if Input.GetKey("Escape") == 1 then
                Update = Update2
                timer = 0
                NewAudio.StopAll()
                queen.Move(-Misc.cameraX, -Misc.cameraY)
                Misc.ResetCamera()
                bubblesprite.Remove()
                bubbletext.Remove()
                
                -- Make a fake mod list
                package.loaded["Libraries/fakeModSelect"] = nil
                info = require("Libraries/fakeModSelect")(debuggetinfo)
                info.cover.Set("fourth/thismod")
                
                mods = {"encounter skeleton", "examples", "examples 2", "rtlgeno"}
                table.insert(mods, info.realModName)
                
                -- Sort alphabetically
                mods = table.sort(mods, function(a, b) return a < b end)
                
                -- Find the current mod's position in the list
                modposition = 1
                for i = 1, #mods do
                    if mods[i] == info.realModName then
                        modposition = i
                        break
                    end
                end
                
                -- Create graphics
                modsparent = CreateSprite("empty", "Topper")
                for i = 1, #mods do
                    -- Special stuff for if it's the current mod
                    if mods[i] == info.realModName then
                        mods[i] = info.cover
                    else
                        mods[i] = CreateSprite("fourth/" .. mods[i])
                    end
                    mods[i].SetParent(modsparent)
                    mods[i].Scale(640 / mods[i].width, 480 / mods[i].height)
                    mods[i].MoveTo(640 * (i - 1), 0)
                end
                modsparent.absx = 320 - (640 * (modposition - 1))
                
                overlay1 = CreateSprite("fourth/overlay1", "Topper")
                overlay2 = CreateSprite("fourth/overlay2", "Topper")
                
                -- killer queen is not gone yet
                queen.layer = "Topper"
                lines.layer = "Topper"
                lines.alpha = 0
                if mask then
                    mask.Remove()
                end
                screenshot.Remove()
                
                scrolldirection = true -- is right?
                scrolltimer = 0
                
                -- Function - moves the first/last image in the sequence to the opposite side to give the illusion of it wrapping around infinitely
                function WrapImages()
                    -- move the leftmost image to the far right side
                    if scrolldirection then
                        -- find the leftmost image
                        local farthestLeft = math.huge
                        local mod = 1
                        for i = 1, #mods do
                            if mods[i].absx < farthestLeft then
                                farthestLeft = mods[i].absx
                                mod = i
                            end
                        end
                        
                        -- move it to the far right side
                        -- 5 mods * 640 px per image = 3200 px to move
                        mods[mod].absx = mods[mod].absx + 3200
                    -- move the rightmost image to the far left side
                    else
                        -- find the rightmost image
                        local farthestRight = -math.huge
                        local mod = 1
                        for i = 1, #mods do
                            if mods[i].absx > farthestRight then
                                farthestRight = mods[i].absx
                                mod = i
                            end
                        end
                        
                        -- move it to the far left side
                        -- 5 mods * 640 px per image = 3200 px to move
                        mods[mod].absx = mods[mod].absx - 3200
                    end
                end
                
                -- Load void audio
                NewAudio.PlaySound("src", "Waves/void", true, 0)
                
                -- Create menacing symbols
                menacing = {}
                for i = 1, 5 do
                    local symbol = CreateSprite("fourth/menacingsymbol", "Topper")
                    symbol.Scale(2, 2)
                    symbol.absx = (640/6) * i
                    symbol.absy = 380 + (math.random() * 40)
                    symbol.alpha = 0
                    symbol["origx"] = symbol.absx
                    symbol["origy"] = symbol.absy
                    menacing[i] = symbol
                end
                
                -- Caption
                caption = CreateSprite("fourth/menacingtext", "Topper")
                caption.Scale(2, 2)
                caption.absy = 340
                caption.alpha = 0
                
                -- Create enormous explosion (for later)
                nuke = CreateSprite("fourth/nuke/spr_floweynuke_explosion_0", "Topper")
                nuke.Scale(640/nuke.width, 480/nuke.height)
                local frames = {}
                for i = 0, 42 do
                    table.insert(frames, "spr_floweynuke_explosion_" .. i)
                end
                nuke.SetAnimation(frames, 1/40, "fourth/nuke")
                nuke.loopmode = "ONESHOTEMPTY"
                nuke.animationpaused = true
                nuke.alpha = 0
                nuke.y = nuke.y - (20 * nuke.yscale)
                
                -- Create text object to talk to the player
                local text = "[noskip][font:uidialog][voice:v_floweymad][color:ff0000][speed:1.1]Killer Queen is already\n inside your computer!"
                
                bigtext = CreateText(text, {320, 50}, 640, "Topper")
                bigtext.x = 320 - (bigtext.GetTextWidth()/2)
                bigtext.HideBubble()
                bigtext.progressmode = "none"
                
                bigtext.SetPause(true)
                
                return
            end
        -- Player took too long. Kill them.
        elseif timer > 80 and NewAudio.isStopped("death glare") then
            Update = Update3
            timer = 0
            NewAudio.StopAll()
            Misc.ResetCamera()
            bubblesprite.Remove()
            bubbletext.Remove()
            
            queen.Remove()
            screenshot.Remove()
            lines.Remove()
            
            CreateSprite("black", "Topper").Scale(1.5, 1.5)
            
            -- Create "bits" and hearts within
            bits = {}
            
            if CYFversion > "0.6.3" then
                local bit1 = CreateSprite("fourth/bits/bit_1", "Topper")
                bit1.SetPivot(0, 1)
                bit1.MoveTo(-64, 64)
                
                local bit2 = CreateSprite("fourth/bits/bit_2", "Topper")
                bit2.SetPivot(0, 1)
                bit2.MoveTo(-56, 64)
                
                local bit3 = CreateSprite("fourth/bits/bit_3", "Topper")
                bit3.SetPivot(1, 1)
                bit3.MoveTo(64, 64)
                
                local bit4 = CreateSprite("fourth/bits/bit_4", "Topper")
                bit4.SetPivot(1, 0)
                bit4.MoveTo(64, -63)
                
                local bit5 = CreateSprite("fourth/bits/bit_5", "Topper")
                bit5.SetPivot(1, 0)
                bit5.MoveTo(58, -64)
                
                local bit6 = CreateSprite("fourth/bits/bit_6", "Topper")
                bit6.SetPivot(1, 0)
                bit6.MoveTo(1, -64)
                
                bits[1] = bit1
                bits[2] = bit2
                bits[3] = bit3
                bits[4] = bit4
                bits[5] = bit5
                bits[6] = bit6
                
                -- hearts
                for i = 1, 6 do
                    local heart = CreateSprite("ut-heart")
                    heart.SetParent(bits[i])
                    heart.color = {1, 0, 0}
                    heart.Scale(8, 8)
                    
                    bits[i].yscale = (128/96)
                    bits[i].Mask("stencil")
                    bits[i].alpha = 0
                    
                    bits[i].Move(320, 240) -- sowwy for placing it wrong >w>
                    heart.MoveToAbs(320, 240)
                end
            -- 0.6.3 version
            else
                cracks = CreateSprite("fourth/bits/0.6.3 cracks", "Topper")
                cracks.Scale(160/cracks.width, 128/cracks.height)
                cracks.color = {0, 0, 0, 0}
            end
            
            bigheart = CreateSprite("ut-heart", "Topper")
            bigheart.color = {1, 0, 0}
            bigheart.Scale(8, 8)
            if CYFversion == "0.6.3" then
                cracks.MoveAbove(bigheart)
            end
            
            -- Create fiery explosion
            fire = CreateSprite("fourth/flame/spr_floweyx_flame_move_0", "Topper")
            fire.Scale(3, 3)
            
            local frames = {}
            for i = 0, 38 do
                table.insert(frames, "spr_floweyx_flame_move_" .. i)
            end
            fire.SetAnimation(frames, 1/30, "fourth/flame")
            fire.loopmode = "ONESHOTEMPTY"
            fire.animationpaused = true
            fire.alpha = 0
            
            -- Create game over text object
            local text = {"[noskip][lettereffect:rotate,0.2]Oi,[lettereffect:none][w:10] " .. Player.name .. "!", "[noskip]I used my stand to erase the game over text!", "[noskip]Ain't that [lettereffect:shake]WILD?!"}
            
            -- random voices. just for fun.
            for i = 1, #text do
                local str = text[i]
                
                local j = 1
                while j < #str do
                    -- skip commands
                    if str:sub(j, j) == "[" then
                        j = str:find("%]", j)
                    -- otherwise, add a voice command
                    else
                        local command = "[voice:v_" .. (math.random() < 0.5 and "sans" or "papyrus") .. "]"
                        str = str:sub(0, j - 1) .. command .. str:sub(j)
                        j = j + #command
                    end
                    j = j + 1
                end
                
                text[i] = str
            end
            
            deathtext = CreateText(text, {159, 112}, 320, "Topper")
            deathtext.SetFont("uidialog")
            deathtext.color = {1, 1, 1}
            deathtext.HideBubble()
            deathtext.progressmode = "auto"
            deathtext.SetWaitTime(80)
            
            deathtext.SetPause(true)
            
            return
        end
        
        -- Update aura
        if aura then
            aura.x = (math.sin(math.rad(Time.time*60)) * 48) - 48
            aura.y = (aura.y + 1) % 480
        end
    end
    
    -- Update function (part 2: mod selection screen)
    function Update2()
        if timer < 520 or bigtext.lineComplete then
            timer = timer + 1
        end
        
        -- Handle user trying to press buttons or keys
        if timer < 500 and scrolltimer == 0 then
            -- mouse
            if Input.GetKey("Mouse0") == 1 and Input.IsMouseInWindow then
                keypressed = bigtext.lineComplete
                
                -- detect if mouse is over Left or Right arrows
                
                if Input.MousePosY >= 231 and Input.MousePosY <= 248 then
                    -- left arrow
                    if Input.MousePosX >= 14 and Input.MousePosX <= 34 then
                        scrolltimer = 1
                        scrolldirection = false
                        modposition = (((modposition - 1) - 1) % 5) + 1 -- LEFT
                        WrapImages()
                    -- right arrow
                    elseif Input.MousePosX >= 607 and Input.MousePosX <= 627 then
                        scrolltimer = 1
                        scrolldirection = true
                        modposition = (modposition % 5) + 1 -- RIGHT
                        WrapImages()
                    end
                end
            -- left
            elseif Input.GetKey("LeftArrow") == 1 then
                keypressed = bigtext.lineComplete
                scrolltimer = 1
                scrolldirection = false
                modposition = (((modposition - 1) - 1) % 5) + 1 -- LEFT
                WrapImages()
            -- right
            elseif Input.GetKey("RightArrow") == 1 then
                keypressed = bigtext.lineComplete
                scrolltimer = 1
                scrolldirection = true
                modposition = (modposition % 5) + 1 -- RIGHT
                WrapImages()
            end
        end
        
        -- Update scroll animation
        if scrolltimer > 0 then
            modsparent.Move(math.floor((20 - scrolltimer) * 3.4) * (scrolldirection and -1 or 1), 0)
            
            scrolltimer = scrolltimer + 1
            
            if scrolltimer == 20 then
                modsparent.Move((scrolldirection and -1 or 1) * 2, 0)
                scrolltimer = 0
            end
        end
        
        -- Fade out options and exit buttons
        if timer >= 90 and timer < 100 then
            overlay2.alpha = overlay2.alpha - 0.05
        end
        
        -- Fade in rumbling audio
        if timer < 300 then
            Audio.Volume(math.min((timer - 140) / 400, 0.75))
        end
        
        -- Menacing symbols
        if timer > 300 and timer < 640 then
            local target = menacing[math.random(1, 5)]
            target.alpha = target.alpha + 0.02
            
            for i = 1, 5 do
                menacing[i].MoveTo(menacing[i]["origx"] + (math.random() * 10), menacing[i]["origy"] + (math.random() * 10))
            end
        end
        if timer == 350 then
            caption.alpha = 1
        end
        
        -- Activate text
        if timer == 160 then
            bigtext.SetPause(false)
        -- Prepare to zoom in one last time and finish the battle
        elseif timer == 520 then
            local x = 0.03
            local y = 0.38
            
            mods[modposition].layer = "Topper"
            mods[modposition].MoveToAbs(640 * x, 480 * y)
            mods[modposition].SetPivot(x, y)
            
            -- if the selected mod is THIS mod
            if mods[modposition] == info.cover then
                local absx, absy = info.bigparent.absx, info.bigparent.absy
                info.bigparent.SetAnchor(absx/640, absy/480)
                info.bigparent.MoveToAbs(absx, absy)
                
                absx, absy = info.smolparent.absx, info.smolparent.absy
                info.smolparent.SetAnchor(absx/640, absy/480)
                info.smolparent.MoveToAbs(absx, absy)
            end
            
            queen.SetParent(mods[modposition])
            -- queen.SetAnchor(x + 0.11, y - 0.6)
            queen.SetAnchor(0.2, 0.2)
            overlay1.SetParent(mods[modposition])
            overlay1.SetPivot(x, y)
            overlay1.SetAnchor(x, y)
            overlay2.SetParent(mods[modposition])
            overlay2.SetPivot(x, y)
            overlay2.SetAnchor(x, y)
            
            lines.layer = "Topper"
            lines.SendToTop()
            
            for i = 1, #menacing do
                menacing[i].SendToTop()
            end
            caption.SendToTop()
            
            --[[
            -- temporary variable for calculations
            amount = 0
        -- "small start" zoom in
        elseif timer > 520 and timer < 530 then
            local bg = mods[modposition]
            
            amount = (amount + 0.001) * 1.05
            bg.xscale = bg.xscale + amount
            bg.yscale = bg.xscale
            
            queen.Scale(bg.xscale, bg.xscale)
            overlay1.Scale(bg.xscale, bg.xscale)
            overlay2.Scale(bg.xscale, bg.xscale)
            
            lines.alpha = lines.alpha + (1/10)
            ]]--
            -- temporary variable for calculations
            amount1 = 0
            amount2 = 1
        -- "small start" zoom in
        elseif timer > 520 and timer < 530 then
            amount1 = (amount1 + 0.001) * 1.05
            amount2 = amount2 + amount1
            
            local bg = mods[modposition]
            bg.xscale = (640/bg.width) * amount2
            bg.yscale = (480/bg.height) * amount2
            
            -- if the selected mod is THIS mod
            if mods[modposition] == info.cover then
                info.bigparent.Scale(amount2, amount2)
                info.modname1.Scale(amount2, amount2)
                info.modname2.Scale(amount2, amount2)
                
                info.smolparent.Scale(amount2, amount2)
                info.encounter1.Scale(amount2 / 2, amount2 / 2)
                info.encounter2.Scale(amount2 / 2, amount2 / 2)
            end
            
            queen.Scale(amount2, amount2)
            overlay1.Scale(amount2, amount2)
            overlay2.Scale(amount2, amount2)
            
            lines.alpha = lines.alpha + (1/10)
        elseif timer == 530 then
            Audio.PlaySound("transform1", 1)
        -- actual zoom in
        elseif timer > 530 and timer <= 570 then
            amount2 = lerp(amount2, 3.5, 0.1)
            
            local bg = mods[modposition]
            bg.xscale = (640/bg.width) * amount2
            bg.yscale = (480/bg.height) * amount2
            
            -- if the selected mod is THIS mod
            if mods[modposition] == info.cover then
                info.bigparent.Scale(amount2, amount2)
                info.modname1.Scale(amount2, amount2)
                info.modname2.Scale(amount2, amount2)
                
                info.smolparent.Scale(amount2, amount2)
                info.encounter1.Scale(amount2 / 2, amount2 / 2)
                info.encounter2.Scale(amount2 / 2, amount2 / 2)
            end
            
            queen.Scale(amount2, amount2)
            overlay1.Scale(amount2, amount2)
            overlay2.Scale(amount2, amount2)
        -- Final text
        elseif timer == 626 and keypressed then
            bigtext.layer = "BelowPlayer"
            bigtext.layer = "Topper"
            bigtext.SetText("[noskip][font:uidialog][voice:v_floweymad][color:ff0000][speed:1.1]And Killer Queen has already\n[letters:3]   touched that button![w:30] ")
            bigtext.x = 320 - (bigtext.GetTextWidth()/2)
            
            timer = timer + 1 -- prevent softlocking on this frame
        elseif timer == 628 then
            bigtext.layer = "BelowPlayer"
            bigtext.layer = "Topper"
            bigtext.Scale(1, 1)
            bigtext.SetText("[noskip][font:uidialog][voice:v_floweymad][color:ff0000][speed:1.1][effect:shake]BITE THE DUST.[w:10] ")
            bigtext.Scale(2, 2)
            bigtext.x = 320 - bigtext.GetTextWidth()
            
            timer = timer + 1 -- prevent softlocking on this frame
        -- click!
        elseif timer == 630 then
            NewAudio.StopAll()
            Audio.PlaySound("fourth/click", 1)
            lines.animationpaused = true
            bigtext.Scale(1, 1)
            bigtext.SetText("[noskip][font:uidialog][color:ff0000][instant][effect:none]BITE THE DUST.")
            bigtext.Scale(2, 2)
        -- crack the screen
        elseif timer == 720 then
            Misc.ShakeScreen(12, 5)
            Audio.PlaySound("Waves/fire", 1)
            
            -- black bg
            if CYFversion > "0.6.3" then
                CreateSprite("black", "Topper").Scale(1.5, 1.5)
            end
            
            -- Create "bits" and sprites within
            bits = {}
            
            if CYFversion > "0.6.3" then
                local bit1 = CreateSprite("fourth/bits/bit_1", "Topper")
                bit1.SetPivot(0, 1)
                bit1.MoveToAbs(0, 480)
                
                local bit2 = CreateSprite("fourth/bits/bit_2", "Topper")
                bit2.SetPivot(0, 1)
                bit2.MoveTo(41, 480)
                
                local bit3 = CreateSprite("fourth/bits/bit_3", "Topper")
                bit3.SetPivot(1, 1)
                bit3.MoveTo(640, 480)
                
                local bit4 = CreateSprite("fourth/bits/bit_4", "Topper")
                bit4.SetPivot(1, 0)
                bit4.MoveTo(640, 4)
                
                local bit5 = CreateSprite("fourth/bits/bit_5", "Topper")
                bit5.SetPivot(1, 0)
                bit5.MoveTo(611, 0)
                
                local bit6 = CreateSprite("fourth/bits/bit_6", "Topper")
                bit6.SetPivot(0, 0)
                bit6.MoveTo(41, 0)
                
                bits[1] = bit1
                bits[2] = bit2
                bits[3] = bit3
                bits[4] = bit4
                bits[5] = bit5
                bits[6] = bit6
                
                -- children
                for i = 1, 6 do--6 do
                    bits[i].Scale(640/128, 480/96)
                    bits[i].Mask("stencil")
                    
                    -- the sprites we will need are:
                    -- mods[modposition]
                    -- killer queen
                    -- lines
                    -- menacing symbols
                    -- menacing caption
                    -- overlay1
                    local bg = CreateSprite(mods[modposition].spritename, "Topper")
                    bg.SetPivot(mods[modposition].xpivot, mods[modposition].ypivot)
                    bg.Scale(mods[modposition].xscale, mods[modposition].yscale)
                    bg.SetParent(bits[i])
                    bg.MoveToAbs(mods[modposition].absx, mods[modposition].absy)
                    
                    local overlayagain = CreateSprite("fourth/overlay1", "Topper")
                    overlayagain.SetPivot(overlay1.xpivot, overlay1.ypivot)
                    overlayagain.Scale(overlay1.xscale, overlay1.yscale)
                    overlayagain.SetParent(bits[i])
                    overlayagain.MoveToAbs(overlay1.absx, overlay1.absy)
                    
                    local killer = CreateSprite("fourth/the dust", "Topper")
                    killer.SetPivot(queen.xpivot, queen.ypivot)
                    killer.Scale(queen.xscale, queen.yscale)
                    killer.SetParent(bits[i])
                    killer.MoveToAbs(queen.absx, queen.absy)
                    
                    for j = 1, 5 do
                        local symbol = CreateSprite("fourth/menacingsymbol", "Topper")
                        symbol.Scale(menacing[j].xscale, menacing[j].yscale)
                        symbol.SetParent(bits[i])
                        symbol.MoveToAbs(menacing[j].absx, menacing[j].absy)
                    end
                    
                    local caption2 = CreateSprite("fourth/menacingtext", "Topper")
                    caption2.Scale(caption.xscale, caption.yscale)
                    caption2.SetParent(bits[i])
                    caption2.MoveToAbs(caption.absx, caption.absy)
                    
                    local moreLines = CreateSprite(lines.spritename, "Topper")
                    moreLines.SetParent(bits[i])
                    moreLines.MoveToAbs(320, 240)
                end
            -- 0.6.3 version
            else
                cracks = CreateSprite("fourth/bits/0.6.3 cracks", "Topper")
                cracks.Scale(640/cracks.width, 480/cracks.height)
            end
        -- boom
        elseif timer == 770 then
            Misc.ShakeScreen(48, 24 * 2)
            
            nuke.SendToTop()
            nuke.alpha = 1
            nuke.animationpaused = false
            Audio.PlaySound("Waves/scytheburst", 1)
            Audio.PlaySound("bigkill", 1)
            
            if CYFversion == "0.6.3" then
                cover = CreateSprite("px", "Topper")
                cover.Scale(640 * 1.5, 480 * 1.5)
                cover.MoveAbove(cracks)
                cover.alpha = 0.01
            end
        -- this is where the pieces fall apart...I mean BREAK DOWN BREAK DOWN
        elseif timer > 770 and (timer < 900 or (CYFversion == "0.6.3" and cover.color[1] > 0)) then
            if CYFversion > "0.6.3" then
                for i = 1, 6 do
                    local ang = math.atan2(bits[i].absx - 320, bits[i].absy - 240)
                    
                    bits[i].Move(math.sin(ang) * 4, math.cos(ang) * 4)
                    bits[i].rotation = bits[i].rotation + (((320 - bits[i].absx) / 500) * (bits[i].absx <= 320 and -1 or 1))
                end
            -- 0.6.3: just cover the screen in white then fade to black
            else
                if not nuke.animcomplete then
                    cover.alpha = (nuke.currenttime / nuke.totaltime) * 1.5
                elseif not cover["decreasing"] then
                    cover["decreasing"] = true
                    cover.alpha = 1
                -- fade to black
                elseif cover.color[1] > 0 then
                    local progress = cover.color[1] - (1/80)
                    cover.color = {progress, progress, progress}
                end
            end
        -- Award the fourth ending, at last!
        elseif timer >= 1000 then
            (require("Libraries/endings"))(4)
        end
    end
    
    -- Update function (part 3: player took too long)
    function Update3()
        if deathtext.isPaused() or not deathtext.isactive then
            timer = timer + 1
        end
        
        -- click!
        if timer == 60 then
            Audio.PlaySound("fourth/click", 1)
        -- split
        elseif timer == 100 then
            Audio.PlaySound("Waves/fire", 1)
            Misc.ShakeScreen(12, 5)
            
            -- hide big heart, show cracked heart
            if CYFversion > "0.6.3" then
                bigheart.Remove()
                for i = 1, 6 do
                    bits[i].alpha = 1
                end
            -- 0.6.3 version
            else
                bigheart.Set("ut-heart-broken")
                cracks.alpha = 1
            end
        -- BREAK DOWN BREAK DOWN
        elseif timer == 190 then
            Audio.PlaySound("Waves/scytheburst", 1)
            fire.animationpaused = false
            fire.alpha = 1
            
            Misc.ShakeScreen(40, 12)
        elseif timer < 290 and (fire.currentframe > 6 or fire.animcomplete) then
            if CYFversion > "0.6.3" and bits[1].isactive and bits[1].alpha > 0 then
                for i = 1, 6 do
                    bits[i].alpha = 0
                end
            elseif bigheart.isactive and bigheart.alpha > 0 then
                bigheart.alpha = 0
                cracks.Remove()
            end
        -- declare the player officially dead
        elseif timer == 290 then
            if CYFversion > "0.6.3" then
                for i = 1, 6 do
                    bits[i].Remove()
                end
            end
            
            -- create game over text
            gameover = CreateSprite("UI/spr_gameoverbg_0", "Topper")
            gameover.MoveTo(322, 356)
			gameover.alpha = 0
            
            Audio.PlaySound("fourth/welp, you died", 1)
        -- fade in game over text
        elseif timer > 290 and timer <= 370 then
            gameover.alpha = gameover.alpha + 0.0125
        -- play text
        elseif timer == 429 then
            deathtext.SetPause(false)
        elseif timer >= 430 and timer < 610 then
            gameover.alpha = gameover.alpha - (1/120)
            
            Audio.Volume(0.75 - ((timer-430)/180))
        -- boot player out of mod
        elseif timer == 610 then
            State("DONE")
        end
    end
    
    function lerp(a, b, t)
        return a + ((b - a) * t)
    end
end
