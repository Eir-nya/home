return function(ending)
    SetAlMightyGlobal("wd end " .. ending, true)
    
    unescape = true
    if windows then
        Misc.WindowName = "You did it!"
    end
    
    local cover1 = CreateSprite("gradient", "Topper")
    cover1.ypivot = 0
    cover1.MoveToAbs(320, 0)
    cover1.alpha = 0
    
    local cover2 = CreateSprite("gradient", "Topper")
    cover2.ypivot = 0
    cover2.yscale = -1
    cover2.MoveToAbs(320, 480)
    cover2.alpha = 0
    
    local e1 = CreateSprite("ending/ending_" .. (GetAlMightyGlobal("wd end 1") and "1" or "locked"), "Topper")
    e1.MoveToAbs(320 - 160, 240 + 120)
    e1.color = {0.5, 0.5, 0.5}
    
    local e2 = CreateSprite("ending/ending_" .. (GetAlMightyGlobal("wd end 2") and "2" or "locked"), "Topper")
    e2.MoveToAbs(320 + 160, 240 + 120)
    e2.color = {0.5, 0.5, 0.5}
    
    local e3 = CreateSprite("ending/ending_" .. (GetAlMightyGlobal("wd end 3") and "3" or "locked"), "Topper")
    e3.MoveToAbs(320 - 160, 240 - 120)
    e3.color = {0.5, 0.5, 0.5}
    
    local e4
    
    if GetAlMightyGlobal("wd end 4") then
        e4 = CreateSprite("ending/ending_4", "Topper")
        e4.MoveToAbs(320 + 160, 240 - 120)
        e4.color = {0.5, 0.5, 0.5}
    end
    
    
    
    local sparkles = {}
    
    local timer = 0
    local initial_obj = ({e1, e2, e3, e4})[ending]
    initial_obj.Set("ending/ending_locked")
    function Update()
        cover1.alpha = cover1.alpha < 0.5 and cover1.alpha + (1/120) or 0.5
        cover2.alpha = cover1.alpha
        
        timer = timer + 1
        
        -- initial animation
        if timer > 0 and timer < 45 then
            initial_obj.xscale = initial_obj.xscale + ((1.5 - initial_obj.xscale) * 0.1)
            initial_obj.yscale = initial_obj.xscale
        elseif timer == 45 then
            Audio.PlaySound("ending_unlock")
            
            for i = 1, math.random(3, 6) do
                local sparkle = CreateSprite("ending/sparkle", "Topper")
                sparkle.MoveToAbs(initial_obj.absx + math.random(-initial_obj.xscale *  initial_obj.width/3, initial_obj.xscale *  initial_obj.width/3),
                                  initial_obj.absy + math.random(-initial_obj.yscale * initial_obj.height/3, initial_obj.yscale * initial_obj.height/3))
                sparkle.rotation = math.random(0, 360)
                sparkle["xdir"] = (1 + math.random()) * (math.random() < 0.5 and -1 or 1)
                sparkle["vel"] = 0.5 + (math.random()/1.5)
                sparkle["dir"] = math.random() < 0.5 and -1 or 1
                sparkles[sparkle] = true
            end
            
            -- reveal
            initial_obj.Set("ending/ending_" .. ending)
            initial_obj.color = {1, 1, 1}
        --[[
        elseif timer >= 90 then
            initial_obj.xscale = initial_obj.xscale + ((1 - initial_obj.xscale) * 0.1)
            initial_obj.yscale = initial_obj.xscale
            ]]--
        
        -- create congratulation text
        elseif timer == 120 then
            local text = CreateText("", {320, 270}, 400, "Topper")
            text.SetText(({
                           "[font:uidialog2][instant]You got ending [color:D9CA67]1[color:ffffff]:\n [color:ffff00]Pacifist Ending",
                           "[font:uidialog2][instant]You got ending [color:FC5252]2[color:ffffff]:\n [color:ff0000]Genocide Ending",
                           "[font:uidialog2][instant]You got ending [color:87DF40]3[color:ffffff]:\n [color:4040ff]Betrayal Ending",
                           "[font:uidialog2][instant]You got "
                            -- .. "[color:E00000]s[color:0055AA]e[color:727272]c[color:ffffff]r[color:ffff00]e[color:00ffff]t "
                            -- .. "[color:55FF72]e[color:ff00ff]n[color:E00000]d[color:0055AA]i[color:727272]n[color:ffffff]g "
                            .. "[color:ff0000]s[color:ff8040]e[color:ffff00]c[color:40ff40]r[color:4040ff]e[color:8040ff]t "
                            .. "[color:c040ff]e[color:ff0000]n[color:ff8040]d[color:ffff00]i[color:40ff40]n[color:4040ff]g "
                            -- .. "[color:ff8040]4[color:ffffff]:\n [color:5C0000]Tainted Pacifist Ending"
                            .. "[color:ff8040]4[color:ffffff]:\n     [color:F49EC1]Bit The Dust"
                            .. ((GetAlMightyGlobal("wd end 2") and GetAlMightyGlobal("wd end 3"))
                                and "\n       [font:arial][color:ffffff][alpha:20]hey is this loss" or "")})[ending])
            text.HideBubble()
            text.progressmode = "none"
            text.MoveToAbs(320 - text.GetTextWidth()/2, (ending < 3 and 270 or 300) - text.GetTextHeight()/2)
            
            --  hardcoding :)
            if ending == 4 and GetAlMightyGlobal("wd end 2") and GetAlMightyGlobal("wd end 3") then
                text.x = 125
            end
            
            -- account for camera stuff
            text.x = text.x + Misc.cameraX
            text.y = text.y + Misc.cameraY
            
            
            
        -- allow leaving
        elseif timer > 120 and (Input.GetKey("Escape") == 1 or Input.Confirm == 1 or Input.Cancel == 1) then
            if CYFversion == "0.6.3" then
                local thing = CreateSprite("intro", "Toppest")
                thing.MoveToAbs(320, 240)
                thing.Scale(0.5, 0.5)
            end
            State("DONE")
        end
        
        
        
        -- animate sparkles
        for sparkle in next, sparkles, sparkle do
            sparkle.rotation = sparkle.rotation + (sparkle["dir"] * 2)
            sparkle.x = sparkle.x + sparkle["xdir"]
            sparkle.y = sparkle.y + sparkle["vel"]
            sparkle["vel"] = sparkle["vel"] - 0.1
            
            if sparkle.absy < -16 then
                sparkle.Remove()
                sparkles[sparkle] = nil
            end
        end
        
        
        
        -- wiggle all
        e1.rotation = math.sin(math.rad((timer +  0) * 3)) * 4
        e2.rotation = math.sin(math.rad((timer +  7) * 3)) * 4
        e3.rotation = math.sin(math.rad((timer + 14) * 3)) * 4
        if e4 ~= nil then
            e4.rotation = math.sin(math.rad((timer + 21) * 3)) * 4
        end
    end
    
    
    
    -- account for camera stuff
    cover1.Move(Misc.cameraX, Misc.cameraY)
    cover2.Move(Misc.cameraX, Misc.cameraY)
    e1.Move(Misc.cameraX, Misc.cameraY)
    e2.Move(Misc.cameraX, Misc.cameraY)
    e3.Move(Misc.cameraX, Misc.cameraY)
    if e4 ~= nil then
        e4.Move(Misc.cameraX, Misc.cameraY)
    end
end
