debugger = false
local debuggerSpr1 = nil
local debuggerSpr2 = nil


return function()
    if Input.GetKey("F9") == 1 then
        debugger = not debugger
        
        if debugger then
            debuggerSpr1 = CreateSprite("px", "Toppest")
            debuggerSpr1.MoveToAbs(Misc.cameraX + 460, Misc.cameraY + 410)
            debuggerSpr1.Scale(320, 140)
            debuggerSpr1.color = {0, 0, 0, 0.71}
            
            debuggerSpr2 = CreateSprite("debugger", "Toppest")
            debuggerSpr2.SetParent(debuggerSpr1)
            debuggerSpr2.MoveTo(0, 0)
        else
            debuggerSpr1.Remove()
            debuggerSpr1 = nil
            debuggerSpr2.Remove()
            debuggerSpr2 = nil
        end
    end
end
