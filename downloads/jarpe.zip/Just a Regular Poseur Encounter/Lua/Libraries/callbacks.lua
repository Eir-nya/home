local callbacks = {} -- library

callbacks.callbackFunctions = {} -- list of functions to call

callbacks.Update = function()
    for func in pairs(callbacks.callbackFunctions) do
        if func() then -- if `return true` is called in a function, remove it
            callbacks.callbackFunctions[func] = nil
        end
    end
end

callbacks.AddCallback = function(updateFunc)
    callbacks.callbackFunctions[updateFunc] = true
end

return callbacks
