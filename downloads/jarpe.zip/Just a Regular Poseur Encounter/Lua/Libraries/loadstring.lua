function loadstring(...)
    local args = ({...})
    
    local str = ""
    
    for _, arg in pairs(args) do
        str = str .. arg .. (next(args, _) and ", " or "")
    end
    
    -- error("<color='red'>\"</color>" .. str .. "<color='red'>\"</color>")
    
    return load(str)()
end
