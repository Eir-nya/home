local self = {}

self.channel1 = "musicIntroLoop1"
self.channel2 = "musicIntroLoop2"

self.active = false

self.loopTrack = nil
self.loopTime  =   0

self.isPlayingLoop = false

-- start playing a song and auto set stuff
function self.StartSong(introTrack, loopTrack, loopTime, volume)
    if loopTrack == self.loopTrack then
        return
    end
    
    local volume = volume and volume or 0.75
    
    NewAudio.PlayMusic(self.channel1, introTrack, false, volume)
    NewAudio.PlayMusic(self.channel2,  loopTrack,  true, volume)
    NewAudio.SetPitch(self.channel2, 0)
    
    self.loopTrack = loopTrack
    self.loopTime = loopTime
    self.isPlayingLoop = false
    
    self.active = true
end

function self.StartSongRegular(track, volume)
    if track == NewAudio.GetAudioName("src"):sub(7) then
        return
    end
    
    Audio.LoadFile(track)
    Audio.Volume(volume)
end

function self.Pause()
    -- pause custom audio
    if self.active then
        NewAudio.Pause(self.isPlayingLoop and self.channel2 or self.channel1)
    
    -- pause regular audio
    else
        Audio.Pause()
    end
end

function self.Unpause()
    -- unpause custom audio
    if self.active then
        NewAudio.Unpause(self.isPlayingLoop and self.channel2 or self.channel1)
    
    -- unpause regular audio
    else
        Audio.Unpause()
    end
end

function self.Volume(vol)
    -- set volume of custom audio
    if self.active then
        NewAudio.SetVolume(self.isPlayingLoop and self.channel2 or self.channel1, vol)
    
    -- set volume of regular audio
    else
        Audio.Volume(vol)
    end
end

function self.Update()
    if not self.active then
        return
    end
    
    -- wait for loop to begin
    if not self.isPlayingLoop and NewAudio.Exists(self.channel1) then
        if NewAudio.GetPlayTime(self.channel1) >= self.loopTime then
            local diff = NewAudio.GetPlayTime(self.channel1) - self.loopTime
            
            NewAudio.SetPitch(self.channel2, NewAudio.GetPitch(self.channel1))
            NewAudio.SetVolume(self.channel2, NewAudio.GetVolume(self.channel1))
            NewAudio.Stop(self.channel1)
            
            NewAudio.SetPlayTime(self.channel2, diff)
            
            self.isPlayingLoop = true
        end
    end
end

function self.Stop()
    NewAudio.Stop(self.channel1)
    NewAudio.Stop(self.channel2)
    
    self.active = false
    self.loopTrack = nil
end

function self.GetPlaying()
    return self.active and self.loopTrack or nil
end



NewAudio.CreateChannel(self.channel1)
NewAudio.CreateChannel(self.channel2)



return self
