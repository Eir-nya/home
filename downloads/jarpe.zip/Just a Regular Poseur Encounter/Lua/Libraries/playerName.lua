local name = Misc.MachineName

local invalids = {
    [name:lower() == "administrator"] = true,
    [name:lower() == "user"] = true,
    [name:lower() == "guest"] = true,
    [name:lower():find("%d") ~= nil] = true,
    [name:lower():find("%p") ~= nil] = true,
    [name:lower():find("%a") == nil] = true,
}

for invalid in pairs(invalids) do
    if invalid then
        return "YOU"
    end
end

return name:upper()
