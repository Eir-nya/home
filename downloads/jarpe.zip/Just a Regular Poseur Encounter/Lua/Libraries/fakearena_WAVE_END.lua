-- only wrap the Update function under a certain condition
return function(wrapUpdate)
    -- make Encounter["wavetimer"] infinite to account for lower framerates,
    -- and add a manual frame timer that stops where Encounter["wavetimer"] would have
    local endwave = Encounter["realwavetimer"] < math.huge and (Encounter["realwavetimer"] * 60) or -1
    local timer = 0
    
    if wrapUpdate then
        -- wrap the update function to override player controls
        
        local _upd = Update
        function Update()
            -- red soul movement, basically
            if not Player.controlOverride then
                local velx = 0
                local vely = 0
                
                -- LEFT/RIGHT handlers
                if     Input.Right > 0 and Input.Left  < 1 then
                    velx =  Player.speed
                elseif Input.Left  > 0 and Input.Right < 1 then
                    velx = -Player.speed
                end
                
                -- UP/DOWN handlers
                if     Input.Up   > 0 and Input.Down < 1 then
                    vely =  Player.speed
                elseif Input.Down > 0 and Input.Up   < 1 then
                    vely = -Player.speed
                end
                
                -- hold down X to move at half speed
                if Input.Cancel > 0 then
                    velx = velx / 2
                    vely = vely / 2
                end
                
                
                
                -- move the player
                if velx ~= 0 or vely ~= 0 then
                    Player.Move(velx, vely, false)
                end
            end
            
            
            
            _upd()
            
            
            
            timer = timer + 1
            if endwave ~= -1 and timer >= endwave then
                Player.sprite.alpha = 1
                EndWave()
            elseif Player.isHurting then
                Player.invulTimer = Player.invulTimer - 1
                
                if Player.invulTimer <= 0 then
                    Player.sprite.alpha = Player.sprite.alpha * 2
                    Player.invulTimer = 0
                end
            end
        end
    end



    --==========--



    --[[
    if EndingWave then
        local _ew = EndingWave
        function EndingWave()
            Arena.Show()
            _ew()
        end
    else
        function EndingWave()
            Arena.Show()
        end
    end
    ]]--
end
