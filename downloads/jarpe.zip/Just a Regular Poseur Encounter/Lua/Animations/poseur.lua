--================--
-- ANIMATION VARS --
--================--

anim = {}

-- normal
anim.timer = 0          -- animation timer
anim.animate = false    -- animates the enemy
anim.animation = 0      -- chooses an animation to play for the enemy

anim.jojo = true        -- if true, spawns and animates particles based on the posecount variable
anim.posecount = 0      -- (see above line)
anim.particles = {}     -- particles (see previous line)



-- exhausted animation
anim.legs      = nil    -- these are all
anim.torsoback = nil    -- sprite objects
anim.torso     = nil    -- that are used
anim.rarm      = nil    -- for this
anim.larm      = nil    -- animation
anim.head      = nil    -- .



-- space
anim.space = false      -- whether or not we are in space
anim.strail = {}        -- poseur's trail during space
anim.stars = {}         -- star particles during space

-- jevil
anim.jevil = false      -- whether or not we are in jevil
anim.jsprites = {}      -- poseur clone sprites to use for jevil animation
anim.jspritepool = {}   -- a pool of poseur clone sprites to pull from instead of spawning a new one every 15 frames
anim.jparent = nil      -- the parent for all carousel parents and also the spinner. used for ~~screen shake~~ organization purposes
anim.jparents = {}      -- parents for the carousel bg
anim.jcarousels = {}    -- carousel sprites used for the carousel bg

-- glitch
anim.glitch = false     -- whether or not we are in glitch
anim.gcooldown = 0      -- cooldown for ceiling rubble animation
anim.grubble = {}       -- rubble sprites to animate
anim.gletters = {"A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "J", "j", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "Q", "q", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "W", "w", "X", "x", "Y", "y", "Z", "z", "`", "~", "1", "!", "2", "@", "3", "#", "4", "$", "5", "%", "6", "^", "7", "&", "8", "*", "9", "(", "0", ")", "-", "_", "=", "+"}
                        -- a list of letters to use when choosing a randomized window name
anim.gstatic = nil
anim.gartifacts = {}    -- artifact sprites to remove
anim.gcamoffset = {x = 0, y = 0}    -- offset for the game camera that prevents the window from being moved really far away

--=================--
-- UPDATE FUNCTION --
--=================--

function anim.Update()
    --================================================--
    -- THINGS THAT UPDATE WHEN THE ENEMY IS ANIMATING --
    --================================================--
    
    anim.timer = anim.timer + 1
    
    if anim.animate then
        -- bounce
        if anim.animation == 0 then
            local speed = 20
            if hp > 0 then
                speed = speed + (20 * (1 - (hp / maxhp)))
            end
            
            -- HEARTBEAT animation
            -- monstersprite.yscale = 1 - (math.abs(((anim.timer + 40) % 80) - 40) / 640)
            monstersprite.yscale = 1 + (math.sin(anim.timer / speed) * 0.05)
        
        -- exhausted animation
        elseif anim.animation == 1 then
            anim.legs.yscale = (0.5 - (math.sin((Time.time + 4) * 3) * 0.03125)) + 0.4625
            anim.torsoback.y = (math.sin(Time.time * 3) * 1) - 1
            anim.larm.y = (math.sin((Time.time + 0.5) * 3) * 1) + 68 - 0
            anim.rarm.y = (math.sin((Time.time + 0.5) * 3) * 1) + 66 - 0
        
        -- float
        elseif anim.animation == 2 then
            
            -- normal anim
            if not anim.spacedout then
                monstersprite.absx = 320 + (math.sin(math.rad(anim.timer / 1.5)) * 200)
                monstersprite.absy = 225 + (math.cos(math.rad(anim.timer / 1.5)) *  10)
                
                -- animate shadow thingies
                for i = 1, 10 do
                    local trail = anim.strail[i]
                    local tim = math.rad((anim.timer / 1.5) - (i * 4))
                    
                    trail.absx = 320 + (math.sin(tim) * 200)
                    trail.absy = 225 + (math.cos(tim) *  10)
                    trail.color = {math.sin(tim), math.cos(tim + 2), -math.sin(tim + 4)}
                end
            
            -- gradually return to normal animation thing
            else
                monstersprite.absx = lerp(monstersprite.absx, 320, 0.1)
                monstersprite.absy = lerp(monstersprite.absy, 231, 0.1)
                
                for i = 1, 10 do
                    anim.strail[i].alpha = anim.strail[i].alpha - (1/30)
                end
            end
        
        -- jevil
        elseif anim.animation == 3 then
            
            -- normal anim
            if not anim.jevildone then
                -- create new sprite
                if anim.timer % 15 == 0 then
                    -- use a pooling system to avoid unnecessary memory usage from creating and removing many sprites
                    local jsprite
                    if #anim.jspritepool == 0 then
                        jsprite = CreateSprite( ({"poseur", "posette", "poseur_stand", "poseur_hand"})[(anim.timer % 4) + 1], "Topper")
                    else
                        jsprite = table.remove(anim.jspritepool, #anim.jspritepool)
                        jsprite.Set(({"poseur", "posette", "poseur_stand", "poseur_hand"})[(anim.timer % 4) + 1])
                    end
                    jsprite.MoveAbove(anim.jparent)
                    if math.random() < 0.05 and anim.timer % 45 == 0 then
                        jsprite.Set("tposeur")
                    end
                    jsprite.MoveToAbs(monstersprite.absx + (math.random(-30, 30) * 2), monstersprite.absy + (math.random(0, 10) * 2))
                    jsprite.ypivot = 0
                    jsprite.xscale = math.random(0, 1) == 0 and -1 or 1
                    jsprite.alpha = 0
                    jsprite["xvel"] = math.random(1, 2)
                    jsprite["yvel"] = math.random(1, 2) / 2
                    jsprite["id"] = (math.random() * 45) * 8
                    jsprite["time"] = 0
                    
                    anim.jsprites[jsprite] = true
                end
            
            -- fade back in poseur
            else
                monstersprite.alpha = monstersprite.alpha + 0.0125
            end
            
            -- update all sprites
            for jsprite in next, anim.jsprites, jsprite do
                jsprite["time"] = jsprite["time"] + 1
                
                jsprite.Move(jsprite["xvel"] * math.sin(math.rad(anim.timer + jsprite["id"])), jsprite["yvel"] * math.cos(math.rad(anim.timer + jsprite["id"])))
                
                if jsprite["time"] < 15 then
                    jsprite.alpha = jsprite["time"] / 25
                elseif jsprite["time"] > 25 then
                    jsprite.alpha = 0.56 - ((jsprite["time"] - 25) / 25)
                end
                
                -- remove
                if jsprite["time"] == 40 then
                    if not anim.jevildone then
                        jsprite.alpha = 0
                        table.insert(anim.jspritepool, jsprite)
                    else
                        jsprite.Remove()
                    end
                    
                    anim.jsprites[jsprite] = nil
                end
            end
        end
    end
    
    -- jojo particles
    if anim.jojo and anim.posecount > 0 then
        if anim.timer % (60 * (4 - anim.posecount)) == 0 then
            local particle = CreateSprite("menacing", monstersprite.layer)
            particle.MoveBelow(monstersprite)
            particle.alpha = 0
            particle.MoveToAbs(monstersprite.absx + math.random(-150, 150), monstersprite.absy + math.random(-10, 30))
            
            particle["spawnPosX"] = particle.absx
            particle["spawnPosY"] = particle.absy
            particle["timer"] = 0
            
            anim.particles[particle] = true
        end
    end
    
    --=========================================================--
    -- THINGS THAT UPDATE EVEN WHEN THE ENEMY IS NOT ANIMATING --
    --=========================================================--
    
    -- jojo particles
    for particle in pairs(anim.particles) do
        particle["timer"] = particle["timer"] + 1
        particle.alpha = math.sin(math.rad(particle["timer"])) * (anim.posecount / 3)
        
        particle.MoveToAbs(particle["spawnPosX"] + (math.sin(particle["timer"] / 20)) * (10 * anim.posecount), particle.absy + (4 - anim.posecount))
        
        if particle.absy > 510 then
            particle.Remove()
            anim.particles[particle] = nil
        end
    end
    
    
    
    --=======--
    -- space --
    --=======--
    
    if anim.space then
        -- spawn new stars every so often
        if not safe then
            if anim.timer % 15 == 0 then
                anim.CreateStar(1, Misc.cameraY + (math.random(  5, 235) * 2))
            end
            if anim.timer % 45 == 0 then
                anim.CreateStar(0, Misc.cameraY + (math.random(  7, 232) * 2))
            end
        -- performance mode equivalent
        else
            if anim.timer % 30 == 0 then
                anim.CreateStar(1, Misc.cameraY + (math.random(  5, 235) * 2))
            end
            if anim.timer % 90 == 0 then
                anim.CreateStar(0, Misc.cameraY + (math.random(  7, 232) * 2))
            end
        end
        
        -- animate stars
        for star in pairs(anim.stars) do
            star.x = star.x - (star["speed"] * 2)
            
            if star.absx < -star.width then
                star.Remove()
                anim.stars[star] = nil
            end
        end
        
        -- move camera around
        Misc.cameraX = math.sin(math.rad(anim.timer)) * 2
        Misc.cameraY = math.cos(math.rad(anim.timer) * 0.75) * 7.5
        
        -- mess with the arena!
        Encounter["fakearena"].arena.rotation = math.sin(math.rad(anim.timer / 4)) * 3
        if GetCurrentState() ~= "DEFENDING" then
            Encounter["fakearena"].offset[2] = math.sin(math.rad(anim.timer / 4)) * 6
        else
            Encounter["fakearena"].offset[2] = 0
        end
        
        Encounter["fakearena"].target.rotation = Encounter["fakearena"].arena.rotation
        Encounter["fakearena"].top.rotation = Encounter["fakearena"].arena.rotation
        Encounter["fakearena"].bottom.rotation = Encounter["fakearena"].arena.rotation
        Encounter["fakearena"].left.rotation = Encounter["fakearena"].arena.rotation
        Encounter["fakearena"].right.rotation = Encounter["fakearena"].arena.rotation
    end
    
    
    
    --=======--
    -- jevil --
    --=======--
    
    if anim.jevil then
        if CYFversion == "0.6.3" then
            Encounter["bg"].x = (Encounter["bg"].x - 12) % (Encounter["bg"].width * Encounter["bg"].xscale / 2)
        else
            Encounter["bg"].x = (Encounter["bg"].x + (0.5 * Time.mult)) % 640
            anim.jcarousels[1].x = -Encounter["bg"].x
            for i = 2, #anim.jcarousels do
                anim.jcarousels[i].x = (anim.jcarousels[1].x - (5 * (i - 1))) * anim.jcarousels[i].xscale
            end
        end
        
        -- anim.jparent.MoveTo(Misc.cameraX + 320, Misc.cameraY + 240)
    end
    
    
    
    --========--
    -- glitch --
    --========--
    
    if anim.glitch then
        if not anim.corrupted then
            -- shake screen and make rubble
            if anim.gcooldown == 0 then -- and math.random() < 0.05 then
                Misc.ShakeScreen(6, 3, false)
                
                for i = 1, math.random(3, 6) do
                    local rubble = CreateSprite("glitch/rubble" .. math.random(0, 2), "Topper", 2)
                    rubble.MoveTo(320 + ((math.random(160, 320)) * (math.random() < 0.5 and -1 or 1)), 500 + (math.random(0, 20) * 2))
                    rubble.rotation = math.random(0, 360)
                    rubble["speed"] = math.random(1, 6) / 3
                    rubble.alpha = math.random(1, 3) / 4
                    anim.grubble[rubble] = true
                end
                
                anim.gcooldown = math.random(45, 285)
                
                -- change window title
                if windows then
                    Misc.WindowName = ""
                    
                    for i = 1, math.random(20, 30) do
                        Misc.WindowName = Misc.WindowName .. (anim.gletters)[math.random(78)]
                    end
                end
                
                -- change name
                name = ""
                for i = 1, 6 do
                    name = name .. anim.gletters[math.random(78)]
                end
                Player.name = name:reverse()
                
                -- chance to play SFX
                if math.random(1, 4) == 1 then
                    Audio.PlaySound(({"Waves/grab", "BeginBattle2", "heartbeatbreaker"})[math.random(3)], 1)
                end
                
                -- change bg color
                Encounter["bg"].color = {
                    (math.sin((Time.time * 2) +  0) / 2) + 0.5,
                    (math.sin((Time.time * 2) +  8) / 2) + 0.5,
                    (math.sin((Time.time * 2) + 16) / 2) + 0.5
                }
                
                -- change bg?
                if math.random() < 0.5 then
                    Encounter["bg"].SetAnimation({"glitch/sheet", "glitch/sheet", "bg"}, 1/16)
                    Encounter["bg"].Set("bg")
                end
                
                anim.gstatic.alpha = (math.sin(Time.time) / 40) + 0.025
            
            -- cooldown
            elseif anim.gcooldown > 0 then
                anim.gcooldown = anim.gcooldown - 1
            end
            
            
            
            -- lil detail
            if not Misc.FullScreen and not safe and windows then
                Misc.MoveWindowTo(((Misc.ScreenWidth / 2) - (Misc.WindowWidth / 2)) + Misc.cameraX + anim.gcamoffset.x, ((Misc.ScreenHeight / 2) - (Misc.WindowHeight / 2)) + Misc.cameraY + anim.gcamoffset.y)
            end
            
            
            
            -- create "artifacts"
            if not safe and math.random() < 0.02 then
                local artifact = CreateSprite("glitch/sheet_" .. math.random(1, 16), "Topper")
                artifact.SetAnimation({artifact.spritename, math.random() < 0.5 and "empty" or ("glitch/sheet_" .. math.random(1, 16))}, 1/8)
                artifact.loopmode = "ONESHOT"
                artifact.SetParent(({monstersprite, anim.legs, anim.torsoback, anim.rarm, anim.larm, anim.head, Encounter["fakearena"].bottom, Encounter["fakearena"].left, Encounter["fakearena"].right, Encounter["fakearena"].top})[math.random(10)])
                artifact.MoveTo(0, 0)
                artifact.xpivot = math.random(0, 2) / 2
                
                anim.gartifacts[artifact] = true
            end
        
        -- falling action cutscene
        else
            anim.gstatic.alpha = anim.gstatic.alpha - (1/60)
        end
        
        
        
        --==============================================================--
        -- general glitch animation stuff that persists after it's over --
        --==============================================================--
        
        -- animate rubble
        for rubble in next, anim.grubble, rubble do
            rubble.y = rubble.y - (2 + rubble["speed"])
            
            if rubble.y < -10 then
                rubble.Remove()
                anim.grubble[rubble] = nil
            end
        end
        
        -- animate artifacts
        for artifact in next, anim.gartifacts, artifact do
            if artifact.animcomplete then
                artifact.Remove()
                anim.gartifacts[artifact] = nil
            end
        end
    end
end

--=================--
-- ENTER ANIMATION --
--=================--

function anim.ChangeAnim(id)
    local oldid = anim.animation
    
    -- EXITING EXHAUSTED ANIMATION
    if oldid == 1 then
        anim.legs.Remove()
        anim.torsoback.Remove()
        anim.torso.Remove()
        anim.rarm.Remove()
        anim.larm.Remove()
        anim.head.Remove()
    
    -- EXITING SPACE
    elseif oldid == 2 then
        -- don't restore bg, actually
        
        for star in next, anim.stars, star do
            star.Remove()
        end
        anim.stars = {}
        
        monstersprite.MoveToAbs(320, 231)
        for i = 1, 10 do
            anim.strail[i].Remove()
        end
        anim.strail = {}
        
        -- reset arena
        Encounter["fakearena"].arena.rotation = 0
        Encounter["fakearena"].offset[2] = 0
        
        Encounter["fakearena"].target.rotation = 0
        Encounter["fakearena"].top.rotation = 0
        Encounter["fakearena"].bottom.rotation = 0
        Encounter["fakearena"].left.rotation = 0
        Encounter["fakearena"].right.rotation = 0
        
        Encounter["fakearena"].arena.MoveTo(unpack(Encounter["fakearena"]["pos"]))
        
        Misc.ResetCamera()
    
    -- EXITING JEVIL
    elseif oldid == 3 then
        Encounter["bg"].Set("bg")
        Encounter["bg"].Scale(1, 1)
        Encounter["bg"].color = {1, 1, 1, 1}
        Encounter["bg"].MoveToAbs(320, 240)
        
        for i = 1, #anim .jcarousels do ; anim .jcarousels[i].Remove() ; end
        for i = 1, #anim   .jparents do ; anim   .jparents[i].Remove() ; end
        for i = 1, #anim   .jsprites do ; anim   .jsprites[i].Remove() ; end
        for i = 1, #anim.jspritepool do ; anim.jspritepool[i].Remove() ; end
        
        Encounter["fakearena"].target.Set("UI/spr_target_0")
        
        Encounter["fakearena"].top   .Set("px")
        Encounter["fakearena"].top   .yscale = 5
        Encounter["fakearena"].left  .Set("px")
        Encounter["fakearena"].left  .xscale = 5
        Encounter["fakearena"].bottom.Set("px")
        Encounter["fakearena"].bottom.yscale = 5
        Encounter["fakearena"].right .Set("px")
        Encounter["fakearena"].right .xscale = 5
        
        Encounter["fakearena"].topleft    .Set("px")
        Encounter["fakearena"].topleft    .StopAnimation()
        Encounter["fakearena"].topleft    .MoveTo(0, 0)
        Encounter["fakearena"].topleft    .Scale(5, 5)
        Encounter["fakearena"].topright   .Set("px")
        Encounter["fakearena"].topright   .StopAnimation()
        Encounter["fakearena"].topright   .MoveTo(0, 0)
        Encounter["fakearena"].topright   .Scale(5, 5)
        Encounter["fakearena"].bottomleft .Set("px")
        Encounter["fakearena"].bottomleft .StopAnimation()
        Encounter["fakearena"].bottomleft .MoveTo(0, 0)
        Encounter["fakearena"].bottomleft .Scale(5, 5)
        Encounter["fakearena"].bottomright.Set("px")
        Encounter["fakearena"].bottomright.StopAnimation()
        Encounter["fakearena"].bottomright.MoveTo(0, 0)
        Encounter["fakearena"].bottomright.Scale(5, 5)
        
        Encounter["fakearena"].font = "uidialog"
        Encounter["fakearena"].damagefont = "uidamagetext"
        Encounter["fakearena"].voice = "uifont"
        Encounter["fakearena"].charspacing = 3
        Encounter["fakearena"].spacewidth = 16
        
        dialogbubble = "rightwide2"
    end
    
    -- ENTERING STANDARD ANIMATION
    if id == 0 then
        monstersprite.alpha = 1
        monstersprite.yscale = 1
    
    -- ENTERING EXHAUSTED ANIMATION
    elseif id == 1 then
        monstersprite.alpha = 0
        anim.animate = true
        
        anim.legs = CreateSprite("parts/legs", "Topper")
        anim.legs.SetParent(monstersprite)
        anim.legs.ypivot = 0
        anim.legs.MoveToAbs(312, 234.5)
        
        anim.torsoback = CreateSprite("empty", "Topper")
        anim.torsoback.SetParent(anim.legs)
        anim.torsoback.ypivot = 1
        anim.torsoback.SetAnchor(0.5, 1)
        anim.torsoback.MoveTo(0, 0)
        
        anim.torso = CreateSprite("parts/torso", "Topper")
        anim.torso.SetParent(anim.torsoback)
        anim.torso.ypivot = 0
        anim.torso.SetAnchor(0.5, 0)
        anim.torso.MoveTo(1, 0)
        
        anim.rarm = CreateSprite("parts/rarm", "Topper")
        anim.rarm.SetParent(anim.torsoback)
        anim.rarm.SetPivot(0, 1)
        anim.rarm.SetAnchor(1, 1)
        anim.rarm.MoveTo(30, 66)
        
        anim.larm = CreateSprite("parts/larm", "Topper")
        anim.larm.SetParent(anim.torsoback)
        anim.larm.SetPivot(1, 1)
        anim.larm.SetAnchor(0, 1)
        anim.larm.MoveTo(-23, 68)
        
        anim.head = CreateSprite("parts/head", "Topper")
        anim.head.SetParent(anim.torso)
        anim.head.ypivot = 0
        anim.head.SetAnchor(0.5, 1)
        anim.head.MoveTo(-2, -8)
    
    -- ENTERING SPACE
    elseif id == 2 then
        Encounter["bg"].alpha = 0
        
        anim.animate = true
        monstersprite.Set("poseur_float")
        monstersprite.yscale = 1
        
        for i = 1, 10 do
            local trail = CreateSprite("poseur_float", "Topper")
            trail.ypivot = 0
            trail.MoveToAbs(monstersprite.absx, monstersprite.absy)
            trail.MoveAbove(Encounter["bg"])
            trail.alpha = 0.5 - (i / 20)
            
            anim.strail[i] = trail
        end
        
        for i = 1, (not safe and 20 or 10) do
            anim.CreateStar(1, math.random(  5, 235) * 2).absx = math.random(40, 600)
        end
        
        for i = 1, (not safe and 10 or  5) do
            anim.CreateStar(0, math.random(  7, 232) * 2).absx = math.random(40, 600)
        end
    
    -- ENTERING JEVIL
    elseif id == 3 then
        anim.animate = true
        monstersprite.alpha = 0
        
        if CYFversion == "0.6.3" then
            Encounter["bg"].Set("carousel 0.6.3")
            Encounter["bg"].Scale(2, 2)
            Encounter["bg"].color32 = {26, 26, 77, 255}
        else
            Encounter["bg"].alpha = 0
            Encounter["bg"].x = 0
            -- store and use the x positions, widths and heights of all columns to display the carousel image in
            local stats = {
                { x =   0, w =  5, h = 300 },
                { x =   5, w = 10, h = 297 },
                { x =  15, w =  5, h = 296 },
                { x =  20, w = 15, h = 295 },
                { x =  35, w = 10, h = 294 },
                { x =  45, w = 20, h = 293 },
                { x =  65, w = 15, h = 292 },
                { x =  80, w = 25, h = 291 },
                { x = 105, w = 20, h = 290 },
                { x = 125, w = 30, h = 289 },
                { x = 155, w = 25, h = 288 },
                { x = 180, w = 35, h = 287 },
                { x = 215, w = 30, h = 286 },
                { x = 245, w = 40, h = 285 },
                { x = 280, w = 40, h = 284 },
                { x = 320, w = 40, h = 285 },
                { x = 360, w = 35, h = 286 },
                { x = 395, w = 35, h = 287 },
                { x = 430, w = 30, h = 288 },
                { x = 460, w = 30, h = 289 },
                { x = 490, w = 25, h = 290 },
                { x = 515, w = 25, h = 291 },
                { x = 540, w = 20, h = 292 },
                { x = 560, w = 20, h = 293 },
                { x = 580, w = 15, h = 294 },
                { x = 595, w = 15, h = 295 },
                { x = 610, w = 10, h = 296 },
                { x = 620, w = 10, h = 297 },
                { x = 630, w =  5, h = 298 },
                { x = 635, w =  5, h = 299 },
            }
            
            for i = 1, #stats do
                -- create parents
                local parent = CreateSprite("px")
                parent.SetParent(anim.jparent)
                parent.SendToBottom()
                parent.MoveToAbs(stats[i].x, 480)
                parent.Scale(stats[i].w, stats[i].h)
                parent.SetPivot(0, 1)
                parent.Mask("stencil")
                table.insert(anim.jparents, parent)
                
                -- create children
                local child = CreateSprite("carousel")
                child.SetPivot(0, 1)
                child.SetAnchor(0, 1)
                child.SetParent(parent)
                child.Scale(parent.xscale / 5, parent.yscale / child.height)
                child.MoveTo(i == 1 and 0 or ((anim.jcarousels[1].x - (5 * (i - 1))) * child.xscale), 0)
                child.color32 = {26, 26, 77}
                table.insert(anim.jcarousels, child)
            end
        end
        
        -- set up UI box, wowie
        Encounter["fakearena"].target.Set("UI/spr_target_1")
        
        Encounter["fakearena"].top   .Set("UI/DRBox/top")
        Encounter["fakearena"].top   .yscale = 1
        Encounter["fakearena"].left  .Set("UI/DRBox/left")
        Encounter["fakearena"].left  .xscale = 1
        Encounter["fakearena"].bottom.Set("UI/DRBox/bottom")
        Encounter["fakearena"].bottom.yscale = 1
        Encounter["fakearena"].right .Set("UI/DRBox/right")
        Encounter["fakearena"].right .xscale = 1
        
        Encounter["fakearena"].topleft    .Set("UI/DRBox/cornerUL_1")
        Encounter["fakearena"].topleft    .SetAnimation({"cornerUL_1", "cornerUL_2", "cornerUL_3", "cornerUL_4", "cornerUL_5", "cornerUL_4", "cornerUL_3", "cornerUL_2"}, 1/4, "UI/DRBox")
        Encounter["fakearena"].topleft    .MoveTo(12, -12)
        Encounter["fakearena"].topleft    .Scale(1, 1)
        Encounter["fakearena"].topright   .Set("UI/DRBox/cornerUR_1")
        Encounter["fakearena"].topright   .SetAnimation({"cornerUR_1", "cornerUR_2", "cornerUR_3", "cornerUR_4", "cornerUR_5", "cornerUR_4", "cornerUR_3", "cornerUR_2"}, 1/4, "UI/DRBox")
        Encounter["fakearena"].topright   .MoveTo(-12, -12)
        Encounter["fakearena"].topright   .Scale(1, 1)
        Encounter["fakearena"].bottomleft .Set("UI/DRBox/cornerDL_1")
        Encounter["fakearena"].bottomleft .SetAnimation({"cornerDL_1", "cornerDL_2", "cornerDL_3", "cornerDL_4", "cornerDL_5", "cornerDL_4", "cornerDL_3", "cornerDL_2"}, 1/4, "UI/DRBox")
        Encounter["fakearena"].bottomleft .MoveTo(12, 12)
        Encounter["fakearena"].bottomleft .Scale(1, 1)
        Encounter["fakearena"].bottomright.Set("UI/DRBox/cornerDR_1")
        Encounter["fakearena"].bottomright.SetAnimation({"cornerDR_1", "cornerDR_2", "cornerDR_3", "cornerDR_4", "cornerDR_5", "cornerDR_4", "cornerDR_3", "cornerDR_2"}, 1/4, "UI/DRBox")
        Encounter["fakearena"].bottomright.MoveTo(-12, 12)
        Encounter["fakearena"].bottomright.Scale(1, 1)
        
        Encounter["fakearena"].font = "uidialog2"
        Encounter["fakearena"].damagefont = "uidamagetext2"
        Encounter["fakearena"].voice = "monsterfont"
        Encounter["fakearena"].charspacing = 1
        Encounter["fakearena"].spacewidth = 18
        
        Encounter["fakearena"].text     .x = Encounter["fakearena"].text     .x + 1
        Encounter["fakearena"].text     .y = Encounter["fakearena"].text     .y - 1
        Encounter["fakearena"].textStars.x = Encounter["fakearena"].textStars.x + 1
        Encounter["fakearena"].textStars.y = Encounter["fakearena"].textStars.y - 1
        
        dialogbubble = "rightwide3"
    end
    
    anim.animation = id
end

--=============--
-- ENTER SPACE --
--=============--

function anim.EnterSpace()
    anim.space = true
    anim.ChangeAnim(2)
end

function anim.ExitSpace()
    anim.space = false
    anim.ChangeAnim(0)
    
    Encounter.Call("loadstring", "musicIntroLoop.Stop()")
end

-- type: 0 for big star, 1 for little star
--    y: y position to spawn at
function anim.CreateStar(type, y)
    local star = CreateSprite("star" .. type, "Topper")
    star.MoveAbove(Encounter["bg"])
    star.absx = 640 + star.width
    star.absy = y
    star["speed"] = type + 1
    
    anim.stars[star] = true
    
    return star
end

--=============--
-- ENTER JEVIL --
--=============--

function anim.EnterJevil()
    anim.jevil = true
    
    anim.jparent = CreateSprite("empty", "Topper")
    anim.jparent.MoveAbove(Encounter["bg"])
    
    -- spinner
    local spinner = CreateSprite("spinner/1", "Topper")
    spinner.SetParent(anim.jparent)
    
    local frames = {}
    for i = 1, 72 do
        if (safe and i%2 == 1) or not safe then
            table.insert(frames, i)
        end
    end
    spinner.SetAnimation(frames, safe and 1/30 or 1/60, "spinner")
    
    -- heart outline
    local outline = CreateSprite("dr-outline", Player.sprite.layer)
    outline.SetParent(Player.sprite)
    outline.MoveTo(0, 0)
    Player.sprite["outline"] = outline
    
    anim.ChangeAnim(3)
    
    function anim.ExitJevil()
        anim.jevil = false
        
        spinner.Remove()
        
        outline.Remove()
        Player.sprite["outline"] = nil
        
        anim.jparent.Remove()
        anim.jparent = nil
        
        anim.ChangeAnim(0)
        
        Audio.Stop()
    end
end

--==============--
-- ENTER GLITCH --
--==============--

function anim.EnterGlitch()
    anim.glitch = true
    
    anim.ChangeAnim(1)
    anim.head.Set("parts/head_clean")
    
    Encounter["bg"].color = {
        (math.sin((Time.time * 2) +  0) / 2) + 0.5,
        (math.sin((Time.time * 2) +  8) / 2) + 0.5,
        (math.sin((Time.time * 2) + 16) / 2) + 0.5
    }
    Encounter["bg"].loopmode = "ONESHOT"
    
    anim.gstatic = CreateSprite("glitch/noise0", "Topper", 2)
    anim.gstatic.SetAnimation({"noise0", "noise1", "noise2"}, 1/16, "glitch")
    anim.gstatic.MoveTo(320, 240)
    anim.gstatic.Scale(640/100, 480/100)
    anim.gstatic.alpha = 0.05
end



--===========================--
-- RESET GENOCIDE ANIMATIONS --
--===========================--

function anim.FadeOutAnimation()
    
    -- if in space
    if anim.space then
        anim.spacedout = true
    
    -- if in jevil
    elseif anim.jevil then
        SetSprite("poseur_stand")
        anim.jevildone = true
    
    -- if in glitch
    elseif anim.glitch then
        FadeBG({  3, 114,  18}, 3)
        Player.name = "Frisk"
        anim.corrupted = true
    end
end
