local self = {}
self.items = {"ButtsPie", "Bisicle", "MnstrCndy", "MnstrCndy", "MnstrCndy", "SnowPiece", "SnowPiece", "SnowPiece"}
-- self.items = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","Now","I","know","My","A","B","C\'s","next","time","won't","you","sing","with","me?"}
function self.HandleItem(pos)
	local itemname = self.items[pos]
	if string.upper(itemname) == "BUTTSPIE" or string.upper(itemname) == "PIE" then
		BattleDialog({"You ate the Butterscotch Pie.[w:10]\n"..self.HealAndReturnString(99,"eat")})
		self.RemoveItem(pos)
	elseif string.upper(itemname) == "BISICLE" then
		BattleDialog({"You ate the Bisicle.[w:10]\n"..self.HealAndReturnString(11,"eat")})
		self.SwapItems("BISICLE", "Unisicle")
	elseif string.upper(itemname) == "UNISICLE" or string.upper(itemname) == "POPSICLE" then
		BattleDialog({"You ate the Unisicle.[w:10]\n"..self.HealAndReturnString(11,"eat")})
		self.RemoveItem(pos)
	elseif string.upper(itemname) == "MNSTRCNDY" then
		BattleDialog({"You ate the Monster Candy.[w:10]\nVery un-licorice-like.[w:10]\n"..self.HealAndReturnString(10,"eat")})
		self.RemoveItem(pos)
	elseif string.upper(itemname) == "SNOWPIECE" then
		BattleDialog({"You ate the Snowman Piece.[w:10]\n"..self.HealAndReturnString(45,"eat")})
		self.RemoveItem(pos)
	end
end
function self.HealAndReturnString(num,sound)
	local string = nil
	if Player.hp + num >= self.GetMaxHP() then
		string = "Your HP was maxed out!"
	else
		string = "You recovered "..num.." HP!"
	end
	Player.hp = Player.hp + num
	if sound ~= nil then
		Audio.PlaySound(sound)
	else
		Audio.PlaySound("healsound")
	end
	return string
end
function self.GetMaxHP()
	if Player.lv < 20 then
		return 16 + (4 * Player.lv)
	elseif Player.lv == 20 then
		return 99
	end
end
function self.RemoveItem(pos)
	table.remove(self.items,pos)--self.items[pos] = nil
end
function self.SwapItems(item,item2)
	for i=1,#self.items do
		if string.upper(self.items[i]) == string.upper(item) then
			self.items[i] = item2
		end
	end
end
function self.RebuildTable()
	local table = {}
	for i=1,#self.items do
		if self.items[i] ~= nil then
			table[#table+1] = self.items[i]
		end
	end

	self.items = table
end
return self