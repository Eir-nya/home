sprite = "blank"
name = "[starcolor:ffffff]Spare"