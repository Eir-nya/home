function Voice(string) ; return "[voice:v_azzy][effect:none]"..string.."[w:6][func:stoptalking]" ; end
progress = 0
randomtexts = {
{"You're starstruck now."},
{"Smells like goat.","Asriel prepares a star attack.","Asriel chuckles confidently.",
"Asriel prepares a fire attack,[w:5]\rbut realizes his mistake and\rhastily fixes it.","Asriel whispers \"So cool!\"",
"Asriel pats his ear fur down\rto look more intimidating.","Asriel remembers a joke Chara\rtold and snorts.",
"Asriel tries to play it cool."}}
randomtexts[9] = {"What."}
randomtexts[10] = {"Asriel is sparing you."}
sequential_dialogue = {
{"[noskip][func:face,eyebrowslowered][next]", Voice("Did you honestly\nthink that my\nstrongest attack..."),
"[noskip][func:face,eyebrowslowered_grin][next]", Voice("Would be so\npredictable?"), Voice("This isn't some\nlously little\nbullet!"),
"[noskip][func:face,eyebrow][next]", Voice("This is the stuff\nof legends!!"),	"[noskip][func:face,happy][next]",
Voice("Ha ha ha ha!!"),"[noskip][func:face,normal][next]","[noskip][func:histrousle][next]"},
{"[noskip][func:face,side][next]", Voice("Is my warrior\noutfit ready to be\nseen?", "[noskip][func:face,normal][next]")},
{"[noskip][func:face,normal][next]", Voice("You know,[w:5] STAR\nBLAZING isn't my\nonly original\nattack.")},
{"[noskip][func:face,wink][next]",Voice("A good deity keeps\na few secrets up\nhis sleeve."),"[noskip][func:face,normal][next]"},
{"[noskip][func:face,grin][next]",Voice("I'll be a great\nCaptain of the\nRoyal Guard!","[noskip][func:face,normal][next]")},
{"[noskip][func:face,grin][next]",Voice("Dad will be so\nproud and Mom will\nbake a pie for me!","[noskip][func:face,normal][next]")},
{Voice("Chara will be glad\nbut...")},
{"[noskip][func:face,slightlysad][next]",Voice("Won't I have to\nleave them behind\nto go on patrol a\nlot?")},
{"[noskip][func:face,slightlysad_side][next]",Voice("And the family\nwill be torn apart\neven more.","[noskip][func:face,slightlysad][next]")},
{"[noskip][func:face,mad][next]",Voice("Ugh, [w:5]that's future\nme's problem!","[noskip][func:face,normal][next]")},
{Voice("Charging my\nspecial attack now!")},
{Voice("Hope your b-butt\nis ready!")},
{"[noskip][func:face,leftbrow][next]",Voice("What's that look\nfor?[w:8] It's a human\nsaying.","[noskip][func:face,normal][next]")},
{"[noskip][func:face,slightlymad_side][next]",Voice("Okay,[w:5] so I haven't\npracticed my\ninsults a lot.","[noskip][func:face,normal][next]")},
{"[noskip][func:face,bite][next]",Voice("Speeches are\nharder to remember.","[noskip][func:face,normal][next]")},
{"[noskip][func:face,slightlysad][next]",Voice("I don't want to be\nrude to you\neither...","[noskip][func:face,normal][next]")},
{Voice("Anyway! [w:8]Charging\nis all done!"),Voice("Here comes my\nspecial secret\nattack!")},
{"[noskip][func:face,shock][next]",Voice("O[waitall:3]...[waitall:1]kay then[waitall:3]...[waitall:1]",
"[noskip][func:face,confuse][next]",Voice("I guess um,[w:5] have a\nnormal special\nattack?"))}
}
attacks_list = {
"none",
"placeholder_fire",
"placeholder_fire",
"placeholder_fire",
"placeholder_fire",
"placeholder_fire",
"placeholder_fire",
"placeholder_fire",
"placeholder_fire",
"placeholder_fire",
"placeholder_fire",
"placeholder_fire",
"placeholder_fire",
"placeholder_fire",
"placeholder_fire",
"placeholder_fire",
"placeholder_fire",
"placeholder_fire"
}
comments = {randomtexts[2][1],randomtexts[2][5],randomtexts[2][6]}
commands = {"Check","Flirt","Insult"}
randomdialogue = nil
facesprite = "normal"
talking = false
sprite = "blank_small"
name = "Asriel"
hp = 550
atk = 3
def = 0
check = "Puts on a brave face,[w:5] but gets\remotional very easily."
dialogbubble = "rightwide"
canspare = false
cancheck = false
attacked = false
can_insult = true
can_flirt = true
function HandleAttack(attackstatus)
    if attackstatus == -1 then
    else
		SetSprite("hurt")
		Encounter["body"].alpha = 0
		Encounter["head"].alpha = 0
		if attacked == false then
			attacked = true
			currentdialogue = {Voice("So you will fight\nme?"), "[noskip][func:face,eyebrow][next]",
			Voice("Alright! [w:8]Finally, [w:5]a\nworthy opponent!"), Voice("Let's see how you\nhandle my fabled\nSTAR BLAZING."), Voice("Behold!"),
			"[noskip][func:face,normal][next]"}
			Encounter["enemies"][2].Call("SwapItemsByNames","Pieghetti","Pie")
			Encounter["enemies"][2].Call("SwapItemsByNames","ChocoChip","Cookie")
			Encounter["nextwaves"] = {"star_blazing"}
		end
    end
end
flirted = false
insulted = 0
function HandleCustomCommand(command)
	if command == "CHECK" then
		BattleDialog({string.upper(name).." - ATK 3 DEF 0\n"..check})
    elseif command == "FLIRT" then
		if can_flirt == true and flirted == false then
			table.insert(randomtexts,2,{"Asriel is considering his\rclothes for later."})
			table.insert(sequential_dialogue,2,{"[noskip][func:face,embarrassed][next]", Voice("What? [w:8]No, the\nflirting isn't\ndistracting me!"),
			"[noskip][func:face,blush][next]"})
			flirted = true
			can_insult = false
			currentdialogue = {"[noskip][func:face,blushshock][next]", Voice("Wh-whoa,[w:10] what?"), Voice("Are you..."),
			"[noskip][func:face,angryblush][next]",	Voice("Are you kidding\nme?![w:8] This is a\nfight!"), "[noskip][func:face,angryblush2][next]",
			Voice("Does this look\nlike some joke to\nyou?"), "[noskip][func:State,DEFENDING][next]"}
			State("ENEMYDIALOGUE")
			Encounter["nextwaves"] = { "flirtmenu" }
		elseif flirted == true and can_flirt == true then
			currentdialogue = Voice("Let's talk about\nthis after the\nfight!")
			State("ENEMYDIALOGUE")
			can_flirt = false
		elseif can_flirt == false then
			BattleDialog({"You FLIRT,[w:5] but to no avail.[w:10]\nSeems ACTing won't escalate this\rbattle..."})
		end
	elseif command == "INSULT" then
		can_flirt = false
		local insults = {
		{"[noskip][func:face,tired][next]", Voice("Huh?"), Voice("..."), "[noskip][func:face,eyebrow][next]", Voice("THAT's your idea of\nan insult?"),
		"[noskip][func:face,grin][next]", Voice("Hah! [w:10]I could\ndo better than\nTHAT any day!"), "[noskip][func:face,normal][next]"},
		{"[noskip][func:face,tired][next]", Voice("Again?"), "[noskip][func:face,conceed][next]", Voice("Well, [w:5]you're\ncertainly intent\non this!"),
		"[noskip][func:face,side][next]", Voice("Umm..."), "[noskip][func:face,grin][next]", Voice("Ooh! [w:8]I got one!"),
		"[noskip][func:face,normal][next]", Voice("Y-you're, uh...[w:8]\nnot very strong[waitall:2]...?"), "[noskip][func:face,slightlysad][next]",
		Voice("..."), "[noskip][func:face,mad][next]", Voice("Okay,[w:5] I'm not\nthe best at this!"), "[noskip][func:face,normal][next]"}
		}
		if insulted < #insults and can_insult == true then
			insulted = insulted + 1
			currentdialogue = insults[insulted]
			State("ENEMYDIALOGUE")
		elseif insulted == #insults or can_insult == false then
			BattleDialog({"You INSULT,[w:5] but to no avail.[w:10]\nSeems ACTing won't escalate this\rbattle..."})
		end
	end
end
function face(face)
	facesprite = face
	Encounter["head"].Set("face/"..face)
	Encounter["head"].SetAnimation({"face/"..face, "face/"..face.."_talk"}, 0.21)
	if talking == false then ; talking = true ; end
end
function histrousle(song)
	Audio.LoadFile("histrousle_v3")
	Audio.Volume(1)
	Encounter["wavetimer"] = math.huge
end
function stoptalking()
	talking = false
	Encounter["head"].SetAnimation({"face/"..facesprite})
end
function advancetables()
	if progress < #sequential_dialogue then
		progress = progress + 1
	end
	if randomtexts[progress] ~= nil then
		local randomtext = randomtexts[progress]
		comments = randomtext
	end
	Encounter["nextwaves"] = {attacks_list[progress]}
	Encounter["encountertext"] = Encounter.Call("RandomEncounterText")
	Encounter.Call("DefenseEnding")
end