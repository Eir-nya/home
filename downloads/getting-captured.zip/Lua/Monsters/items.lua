alt = 2
commands = {"Pieghetti", "ChocoChip"}
commands2 = {}
sprite = "blank"
name = "null"
hp = 1
def = math.huge
SetActive(false)
function HandleCustomCommand(command)
	if command == "PIEGHETTI" or command == "PIE" then
		BattleDialog({"You ate the Tomfredo Pieghetti.[w:10]\n"..HealAndReturnString(99,"gulp+heal")})
		RemoveCommandByName(command)
	elseif command == "CHOCOCHIP" or command == "COOKIE" then
		BattleDialog({"You ate the Chocolate Chip\rCookie.[w:10]\n"..HealAndReturnString(8,"gulp+heal")})
		RemoveCommandByName(command)
	end
end
function HealAndReturnString(num,sound)
	local string = nil
	if Player.hp + num >= GetMaxHP() then
		string = "Your HP was maxed out!"
	else
		string = "You recovered "..num.." HP!"
	end
	Player.hp = Player.hp + num
	Audio.PlaySound(sound)
	return string
end
function GetMaxHP()
	if Player.lv < 20 then
		return 16 + (4 * Player.lv)
	elseif Player.lv == 20 then
		return 99
	end
end
function RemoveCommandByName(command)
	for k,v in pairs(commands) do
		if string.upper(v) == string.upper(command) then
			table.remove(commands,k)
		end
	end
end
function SwapCommandByNames(command,command2)
	local found = false
	for k,v in pairs(commands) do
		if string.upper(v) == command and found == false then
			found = true
			commands[k] = command2
		end
	end
end
function SwapTables()
	local storage = commands2
	commands2 = commands
	commands = storage
	alt = alt + 1
end