local capture = GetGlobal("capture")
Player.hp = 1
mask = CreateProjectile("masks/245x130overlay2",0,0)
if capture == nil then ; Player.sprite.SendToTop() ; else ; Player.SetControlOverride(true) ; end
Encounter["createmask"] = false ; Encounter["wavetimer"] = math.huge
Arena.ResizeImmediate(245,130)
if capture == nil then ; Encounter["head"].SetAnimation({"face/shock_talk","face/shock_look_talk"},1.75) ; end
timer = 180 ; if capture ~= nil then ; timer = 0 ; Player.MoveTo(GetGlobal("x"),GetGlobal("y"),false) ; end
if capture ~= nil then
	black = CreateProjectileAbs("bg",320,240)
	black.sprite.alpha = 0
end
if capture == nil then ; SetGlobal("capture",true) ; end
function Update()
	timer = timer - 1
	if timer == 0 and capture == nil then
		SetGlobal("x",Player.x)
		SetGlobal("y",Player.y)
		Encounter["enemies"][1]["currentdialogue"] = {
		Encounter["enemies"][1].Call("Voice","..."),
		"[noskip][func:face,happy][next]", Encounter["enemies"][1].Call("Voice","Yeah![w:8] I did it!"),
		"[noskip][func:face,bite][next]", Encounter["enemies"][1].Call("Voice","[waitall:3]..."),
		"[noskip][func:face,eyebrowslowered_grin][next]",
		Encounter["enemies"][1].Call("Voice","...Anyways![w:8]\nI have defeated you\nin combat,[w:5]\nnewcomer!"),
		"[noskip][func:face,grin][next]", Encounter["enemies"][1].Call("Voice","You will be thrown\ninto the dungeon,[w:5]\nuntil..."),
		Encounter["enemies"][1].Call("Voice","Mo-[w:10][func:face,shock_look]I mean,[w:10][func:face,shock]\nthe Royal Captain,[w:5]\ncomes to get you!"),
		"[noskip][func:face,normal][next]","[noskip][func:State,DEFENDING][next]"}
		for i=1,#Encounter["enemies"][1]["currentdialogue"] do
			if string.sub(Encounter["enemies"][1]["currentdialogue"][i], 1, 2) == "[v" then
				Encounter["enemies"][1]["currentdialogue"][i] = "[noskip]"..Encounter["enemies"][1]["currentdialogue"][i]
			end
		end
		State("ENEMYDIALOGUE")
		Player.MoveTo(GetGlobal("x"),GetGlobal("y"),false)
	end
	if black ~= nil then
		black.sprite.alpha = black.sprite.alpha + 0.01
		Player.sprite.alpha = 1 - black.sprite.alpha
		if black.sprite.alpha == 1 and timer <= 90 then
			State("DONE")
		end
	end
end ; function OnHit(bullet) ; end