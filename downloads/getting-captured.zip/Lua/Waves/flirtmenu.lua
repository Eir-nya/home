Arena.ResizeImmediate(565,130)
oldtimer = Encounter["wavetimer"]
Encounter["wavetimer"] = math.huge
Player.SetControlOverride(true)
menu = CreateProjectile("flirtmenu",0,0)
Player.MoveTo(-252,30,false)
side = 0
dist = 256
function Update()
	if (Input.Right == 1 or Input.Left == 1) and side == 0 then
		Player.MoveTo(Player.x + dist,Player.y,false)
		side = 1
	elseif (Input.Right == 1 or Input.Left == 1) and side == 1 then
		Player.MoveTo(Player.x - dist,Player.y,false)
		side = 0
	end
	if Input.Confirm == 1 then
		Encounter["wavetimer"] = oldtimer
		Encounter["nextwaves"] = { "fire" }
		Audio.PlaySound("menuconfirm")
		menu.Remove()
		if side == 0 then
			Encounter["enemies"][1]["currentdialogue"] = {
			"[noskip][func:face,blush][next]",
			Encounter["enemies"][1].Call("Voice","Umm[waitall:3]...[waitall:1][w:5]\nHaha![w:8] I knew you\nwere only joking."),
			"[noskip][func:face,embarrassed][next]", Encounter["enemies"][1].Call("Voice","Let's talk about\nthis after the\nfight!"),
			"[noskip][func:face,normal][next]"}
		elseif side == 1 then
			Encounter["enemies"][1]["currentdialogue"] = {
			"[noskip][func:face,happyblush][next]", Encounter["enemies"][1].Call("Voice","Hah hah..."), "[noskip][func:face,happyblush_side][next]",
			Encounter["enemies"][1].Call("Voice","Let's talk about\nthis after the\nfight!"), "[noskip][func:face,normal][next]"}
		end
		State("ENEMYDIALOGUE")
	end
end
function OnHit(bullet)
end