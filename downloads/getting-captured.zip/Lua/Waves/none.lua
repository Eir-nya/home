function Update()
	EndWave()
end