currentstate = "NONE" -- NONE by default. This variable changes depending on the last game state (see function EnteringState)
encountertext = "Poseur strikes a pose!"
nextwaves = {"bullettest_chaserorb"}
wavetimer = 1.0
arenasize = {155, 130}
enemies = {
"poseur","spare","flee","locket" -- you have to include all the options you want at the start in the enemies list.
}
enemypositions = {
{0, 5},
{0, 0},
{0, 0},
{0, 0} -- each enemy needs a position, even if they *are* not going to be seen.
}
sparepos = 2 -- change this if you have 2 or more enemies (which you should always put first in the list, by the way)
fleepos = 3 -- same deal as above. should be one position after sparepos, if you're even using it.
locketpos = 4 -- just for the reference. if you don't want it, remove "locket" from enemies, then remove lines market with "locket code" below.
fleeavailable = true -- so that you can toggle fleeing.
locketavailable = false -- locket code
hostile = -1 -- this is for the "jumpscare" part of the HELP_tale reference.

mercymenu = false -- if you're in the menu or not

possible_attacks = {"bullettest_chaserorb","bullettest_bouncy","bullettest_touhou"}

function Update()
	if mercymenu == true and Input.Confirm == 1 then -- Player has selected Spare, Flee or ???.
		if Player.absy == 190 then -- Spare
			SwapActiveEnemies(true)
			if enemies[sparepos]["name"] ~= "[starcolor:ffffff]Spare" then -- if an enemy is spareable
				for k,v in pairs(enemies) do
					if v["canspare"] == true then
						v.Call("Spared") -- v.Call("Spare")
						break
					end
				end
			else -- if no enemy is spareable
				HandleSpare()
			end
		elseif Player.absy == 160 then -- Flee
			enemies[fleepos].Call("Flee")
			SwapActiveEnemies(true)
		elseif Player.absy == 130 then -- ??? also, locket code.
			enemies[locketpos].Call("Locket")
			SwapActiveEnemies(true) -- end locket code, for now.
		end
		Audio.PlaySound("menuconfirm")
	end -- locket code from lines 49 through 72.
	if hostile > 0 then -- if the jumpscare has been started
		hostile = hostile - 1
		Player.sprite.Scale((45 - hostile)*2,(45 - hostile)*2)
		Player.sprite.color = {1 - (hostile/100),(60/hostile)/255,(60/hostile)/255}
		Player.MoveToAbs(320,240,true)
	elseif hostile == 0 then -- the "corrupted" error message.
		local n = "                "
		local sidenotes = {}
		sidenotes[8] = (n..GarbleText("H E L P",1))
		sidenotes[9] = (n.."    "..GarbleText("M  E  ",2))
		sidenotes[15] = ("     "..GarbleText("HE AWAKENS",4))
		local string = ""
		n = "\n                                                         "
		for i=1,18 do
			if math.random(1,2)%2 == 0 then
				n = string.sub(n,1,-2)
			end
			string = string..n..GarbleText("SATAN",i*2)
			if sidenotes[i] ~= nil then
				string = string..sidenotes[i]
			end
		end
		error("attempt to ҤӒΙɭ "..GarbleText("ṨẮ†ᾼṄ",2)..string)
	end -- end locket code, for now.
end

function GarbleText(string,randomcap) -- locket code until line 85.
	symbols = {"̕","̛","̀","́","͘","̡","̢","̧","̨","̴","̵","̶","͏","͜","͝","͞","͟","͠","͢","̸","̷","͡","҉"}
	local string2 = "" -- credit to eeemo.net for the symbol reference, I guess.
	for i=1,#string do
		for j=1,randomcap do
			string2 = string2..symbols[math.random(#symbols)]
		end
		string2 = string2..string.sub(string,i,i)
	end
	return string2
end -- end locket code, for now.

function EnteringState(newstate,oldstate)
	currentstate = newstate
	if newstate == "MERCYMENU" then
		SwapActiveEnemies(false)
		State("ENEMYSELECT")
	elseif oldstate == "ENEMYSELECT" and mercymenu == true then
		SwapActiveEnemies(true)
	end
end

function SwapActiveEnemies(normal) -- enemies list will read "Poseur" if normal is true; else, it will be spare, flee and ???.
	if normal == true then
		mercymenu = false
		enemies[1].Call("SetActive",true)
		enemies[sparepos].Call("SetActive",false)
		enemies[fleepos].Call("SetActive",false)
		enemies[locketpos].Call("SetActive",false)
	else
		mercymenu = true
		enemies[1].Call("SetActive",false)
		enemies[sparepos].Call("SetActive",true)
		if fleeavailable == true then
			enemies[fleepos].Call("SetActive",true)
		else
			enemies[fleepos].Call("SetActive",false)
		end
		if locketavailable == true then -- from here to line 119 are locket code.
			enemies[sparepos]["name"] = "[starcolor:ffffff][color:ffffff]Spare" -- some trickery involving colors. In a future version of Unitale...
			enemies[fleepos]["name"] = "[starcolor:ffffff][color:ffffff]Flee[color:ffff00]" -- ...I might have to change these.
			enemies[fleepos].Call("SetActive",true)
			enemies[locketpos].Call("SetActive",true)
			return
		end -- end locket code, for now.
		for k,v in pairs(enemies) do
			if v["canspare"] ~= nil and v["canspare"] == true then
				enemies[sparepos]["name"] = "[starcolor:ffff00][color:ffff00]Spare[color:ffffff]"
				enemies[fleepos]["name"] = "Flee"
				return
			else
				enemies[sparepos]["name"] = "[starcolor:ffffff]Spare"
				enemies[fleepos]["name"] = "[starcolor:ffffff]Flee"
			end
		end
	end
end

function AudioResume()
	Audio.Unpause()
end

function EncounterStarting()
	SwapActiveEnemies(true)
end

function EnemyDialogueEnding()
	if wavetimer ~= 15 then
		nextwaves = { possible_attacks[math.random(#possible_attacks)] }
	end
end

function DefenseEnding()
    encountertext = RandomEncounterText()
end

function HandleSpare()
     State("ENEMYDIALOGUE")
end

function HandleItem(ItemID)
    BattleDialog({"Selected item " .. ItemID .. "."})
end

function StopAudio()
	Audio.Stop()
end

function LocketKill() -- from this to the end are locket codes.
	Audio.PlaySound("hostile") -- from the IT encounter by /u/N00bFlesh.
	hostile = 60
	Player.sprite.alpha = 1
	Player.SetControlOverride(true)
end