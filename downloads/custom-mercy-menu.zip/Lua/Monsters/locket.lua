sprite = "blank" -- to make it invisible
name = "???"
function Locket() -- I love HELP_tale so much, I decided to make this. It's not accurate to the AU, but it is an example of something you can do.
	Encounter["nextwaves"] = {}
	Audio.LoadFile("mus_chokedup")
	BattleDialog({
	"[noskip]You hold the locket in the air.[w:10]\r\nWith a deep breath[waitall:5]...",
	"[noskip]You reach out to the souls.",
	"[noskip][func:StopAudio][waitall:5]...",
	"[noskip][waitall:5]The souls are hostile!",
	"[noskip][starcolor:000000][func:LocketKill][func:State,DEFENDING]"
	})
end