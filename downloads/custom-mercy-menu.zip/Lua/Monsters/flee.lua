sprite = "blank" -- so it's not visible.
name = "[starcolor:ffffff]Flee"
fleecounter = 0
function Flee() -- yes, I actually went and put in all the default "Flee" lines. It took some time.
	fleecounter = fleecounter + 1
	Audio.Pause()
	Audio.PlaySound("runaway")
	strings = {}
	if fleecounter == 1 then
		strings = {"I'm outta here.","...[w:10]But you realized\rthe overworld was missing."}
	elseif fleecounter == 2 then
		strings = {"I'm outta here.","...[w:10]But the overworld was\rstill missing."}
	elseif fleecounter == 3 then
		strings = {"I'm outta here.","You walked off as if there\rwas an oveworld,[w:5] but you\rran into an invisible wall."}
	elseif fleecounter == 4 then
		strings = {"I'm outta here.","...[w:10]On second thought, the\rembarassment just now\rwas too much."}
	elseif fleecounter == 5 then
		strings = {"I'm outta here.","But you became aware\rof the skeleton inside your\rbody, and forgot to run."}
	elseif fleecounter == 6 then
		strings = {"I'm outta here.","But you needed a moment\rto forget about your\rscary skeleton."}
	elseif fleecounter == 7 then
		strings = {"I'm outta here.","...[w:10]You feel as if you\rtried this before."}
	elseif fleecounter == 8 then
		strings = {"I'm outta here.","...[w:10]Maybe if you keep\rsaying that, the\roverworld will appear."}
	elseif fleecounter == 9 then
		strings = {"I'm outta here.","...[w:10]Or not."}
	elseif fleecounter >= 10 then
		strings = {"I'm outta here.","...[w:10]But you decided to\rstay anyway."}
	end
	table.insert(strings,"[noskip][starcolor:000000][func:AudioResume][func:State,ENEMYDIALOGUE]")
	BattleDialog(strings)
end