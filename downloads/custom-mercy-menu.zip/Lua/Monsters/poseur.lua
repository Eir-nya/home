comments = {"Smells like the work\rof an enemy stand.", "Poseur is posing like his\rlife depends on it.", "Poseur's limbs shouldn't be\rmoving in this way."}
commands = {"ToggleFlee","ToggleSpare","???","Mystify"}
randomdialogue = {"Random\nDialogue\n1.", "Random\nDialogue\n2.", "Random\nDialogue\n3."}
sprite = "poseur" --Always PNG. Extension is added automatically.
name = "Poseur"
hp = 100
atk = 1
def = 1
check = "Check message goes here."
dialogbubble = "right" -- See documentation for what bubbles you have available.
canspare = false
cancheck = true
sans_trick = false

-- Happens after the slash animation but before the shaking and hit sound.
function HandleAttack(attackstatus)
    if attackstatus == -1 then
        -- player pressed fight but didn't press Z afterwards
    else
        -- player did actually attack
    end
end
 
-- This handles the commands; all-caps versions of the commands list you have above.
function HandleCustomCommand(command)
    if command == "TOGGLEFLEE" then
		if Encounter["fleeavailable"] == true then
			Encounter["fleeavailable"] = false
		elseif Encounter["fleeavailable"] == false then
			Encounter["fleeavailable"] = true
		end
        BattleDialog({"The option to flee has\rbeen toggled.","[noskip][func:State,ACTIONSELECT]"})
    elseif command == "TOGGLESPARE" then
		if canspare == false then
			canspare = true
			def = -50
		elseif canspare == true then
			canspare = false
			def = 1
		end
        BattleDialog({"The ability to spare this\renemy has been toggled.","[noskip][func:State,ACTIONSELECT]"})
    elseif command == "???" then
		Encounter["locketavailable"] = true
		Audio.PlaySound("gaster")
        BattleDialog({"HELP_tale reference active!","[noskip][func:State,ACTIONSELECT]"})
		commands = {}
	elseif command == "MYSTIFY" then
		BattleDialog({"You do something mysterious.[w:5]\nPoseur is angered.","[noskip][func:State,ACTIONSELECT]"})
		sans_trick = true
		Audio.PlaySound("gaster")
		table.remove(commands,4)
    end
end

function Spared()
	if sans_trick == false then
		Spare()
	else
		Audio.Pause()
		currentdialogue = {"...","I won't\naccept\nyour\nmercy!","[noskip][func:AudioResume][next]"}
		Encounter["nextwaves"] = { "bullettest_chaserorb", "bullettest_touhou", "bullettest_bouncy" }
		Encounter["wavetimer"] = 15
		State("ENEMYDIALOGUE")
	end
end
function AudioResume()
	Audio.LoadFile("mus_dogsong")
	Audio.Volume(1)
end