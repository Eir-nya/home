sprite = "blank" -- all the code is handled in the encounter file.
name = "[starcolor:ffffff]Spare"