currentstate = "NONE" --the initial state is always NONE.
encountertext = "Poseur strikes a pose!"
nextwaves = {"bullettest_chaserorb"}
wavetimer = 4.0
arenasize = {155, 130}
enemies = {
"poseur", "items" -- to use the custom items, just add "items"...and all the code that's different from the regular encounter file.
}
enemypositions = {
{0, 5},
{0, 0} --can be anywhere, really
}

itemmenu = false --determines whether or not you're in the item menu.

possible_attacks = {"bullettest_chaserorb","bullettest_bouncy","bullettest_touhou"}

function Update()
	if currentstate ~= "ITEMMENU" and itemoverlay ~= nil then --makes sure that "PAGE1"/"PAGE2" does not stay on screen when you leave
		itemoverlay.Remove()
		itemmenu = false
	end
	if currentstate == "ITEMMENU" then--the following code controls changing the page. However, since it's an act menu, the cursor sometimes moves incorrectly.
		if Input.Right == 1 and Player.absx == 321 and Player.absy == 190 and #enemies[2].GetVar("commands2") >= 1 then
			ChangePage() -- the reason for getting the amount of "commands2" is because, in Undertale, pressing left/right at certain positions changes it...
		elseif Input.Left == 1 and Player.absx == 65 and Player.absy == 190 and #enemies[2].GetVar("commands2") >= 2 then
			ChangePage() -- ...but only if there are items in the correct positions on the next page.
		elseif Input.Right == 1 and Player.absx == 321 and Player.absy == 160 and #enemies[2].GetVar("commands2") >= 3 then
			ChangePage() -- the only problem with this here is that, since the items are act commands, the cursor/soul will move around a bit whenever
		elseif Input.Left == 1 and Player.absx == 65 and Player.absy == 160 and #enemies[2].GetVar("commands2") == 4 then
			ChangePage() -- the page is changed. Currently there is no way to fix it, but it's better than nothing.
		end
	end
end

function ChangePage() -- changes the pages. Check "items.lua" in the Monsters folder and scroll to the bottom to see this in action.
	enemies[2].Call("SwapTables")
	itemoverlay.Remove()
	State("ITEMMENU")
end

function OnHit(bullet)
	if bullet.GetVar("safe") == nil then -- so that the "PAGE 1"/"PAGE 2" does not hurt you
		Player.Hurt(1,0)
	end
end

function EnteringState(newstate,oldstate) -- Thanks lvkuln for this amazing function! This wouldn't be possible without it.
	currentstate = newstate
	if newstate == "ITEMMENU" then -- if the player selected "ITEMS"
		if itemmenu == false then -- if it's the first time they're going in (because it technically also goes to this state when you change page)
			local commands = enemies[2].GetVar("commands")
			local commands2 = enemies[2].GetVar("commands2")
			if #commands <=3 and #commands2 > 0 then --This block will search for missing slots in page 1 and fill them in with items from page 2.
				for i=1,4-#commands do
					if #commands2 > 0 then
						local item = commands2[1]
						table.remove(commands2,1)
						table.insert(commands,item)
					end
				end
			end
			enemies[2].SetVar("commands",commands) --puts the "balanced" command tables into the monster file.
			enemies[2].SetVar("commands2",commands2)
		end
		if #enemies[2].GetVar("commands") + #enemies[2].GetVar("commands2") > 0 then -- if there are any items there
			enemies[1].Call("SetActive",false)
			enemies[2].Call("SetActive",true)
			itemmenu = true
			local alt = 0
			if enemies[2].GetVar("alt")%2 ~= 0 then --this bit gets which page the items menu is on.
				alt = 2
			else
				alt = 1
			end
			itemoverlay = CreateProjectileAbs("items_"..alt,320,240) -- creates the overlay reading "Page 1" or "Page 2"
			itemoverlay.SetVar("safe",1)
			State("ACTMENU")
		else
			State("ACTIONSELECT") --You can't enter the item menu if you don't have any items.
		end
	elseif newstate == "ENEMYDIALOGUE" then --Since it always happens right after BATTLEDIALOG, we can use it to reset the tables.
		local alt = enemies[2].GetVar("alt")
		if alt%2 ~= 0 then
			enemies[2].Call("SwapTables")
		end
	elseif oldstate == "ACTMENU" then -- if the player is leaving the "item menu" (it's actually an act menu) then
		enemies[1].Call("SetActive",true)
		enemies[2].Call("SetActive",false)
		if itemmenu == true and newstate == "ENEMYSELECT" then --if this code wasn't here, pressing Z within the item menu would display the item monster.
			itemmenu = false
			State("ACTIONSELECT")
		end
	end
end

function EnemyDialogueEnding()
	nextwaves = { possible_attacks[math.random(#possible_attacks)] }
end

function DefenseEnding()
    encountertext = RandomEncounterText()
end

function HandleSpare()
     State("ENEMYDIALOGUE")
end

function HandleItem(ItemID) -- HAH! Who needs this function NOW?!
    BattleDialog({"Selected item " .. ItemID .. "."})
end