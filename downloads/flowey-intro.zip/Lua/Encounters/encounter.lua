-- A basic encounter script skeleton you can copy and modify for your own creations.

-- music = "shine_on_you_crazy_diamond" --Always OGG. Extension is added automatically. Remove the first two lines for custom music.
encountertext = nil
nextwaves = {"bullettest_chaserorb"}
wavetimer = 4.0
arenasize = {155, 130}

enemies = {
"poseur"
}

enemypositions = {
{0, 0}
}

possible_attacks = {"bullettest_bouncy", "bullettest_chaserorb", "bullettest_touhou"}

introtimer = 0
introphase = 0

function Update()
	if introtimer ~= nil and introtimer < 901 then
		introtimer = introtimer + 1
	end
	if introtimer ~= nil and introtimer < 360 and introphase == 0 then
		dog.sprite.rotation = dog.sprite.rotation + 1
	elseif introtimer ~= nil and introtimer == 360 and introphase == 0 then
		introphase = 1
		dog.sprite.rotation = 0
		error.sprite.Set("crack_1")
		dog.sprite.Set("dogscared")
		Audio.PlaySound("break_1")
	elseif introphase == 1 and introtimer < 440 then
		error.sprite.MoveTo(320 - (((80 - (introtimer - 360)) / 7)*math.sin(introtimer)),240 + (((80 - (introtimer - 360)) / 5)*math.sin(introtimer)))
		dog.sprite.MoveTo(580 + (((80 - (introtimer - 360)) / 2)*math.sin(introtimer)),60 - (((80 - (introtimer - 360)) / 1)*math.sin(introtimer)))
	elseif introphase == 1 and introtimer == 480 then
		introphase = 2
		Audio.PlaySound("break_2")
		error.sprite.Set("crack_2")
	elseif introphase == 2 and introtimer < 570 then
		error.sprite.MoveTo(320 - (((80 - (introtimer - 480)) / 14)*math.sin(introtimer)),240 + (((80 - (introtimer - 480)) / 7)*math.sin(introtimer)))
		dog.sprite.MoveTo(580 + (((80 - (introtimer - 480)) / 4)*math.sin(introtimer)),60 - (((80 - (introtimer - 480)) / 2.5)*math.sin(introtimer)))
	elseif introphase == 2 and introtimer == 600 then
		introphase = 3
		Audio.PlaySound("break_3")
		error.sprite.Set("crack_3")
	elseif introphase == 3 and introtimer < 680 then
		error.sprite.MoveTo(320 - (((80 - (introtimer - 600)) / 20)*math.sin(introtimer)),240 + (((80 - (introtimer - 600)) / 10)*math.sin(introtimer)))
		dog.sprite.MoveTo(580 + (((80 - (introtimer - 600)) / 5)*math.sin(introtimer)),60 - (((80 - (introtimer - 600)) / 3)*math.sin(introtimer)))
	elseif introphase == 3 and introtimer == 740 then
		introphase = 4
		Audio.PlaySound("explode")
	elseif introphase == 4 and introtimer == 750 then
		error.Remove()
		dog.sprite.Set("dogfall")
		dog.SetVar("velx",0)
		dog.SetVar("vely",1)
		SetGlobal("bit1",CreateProjectileAbs("bit_1",138.5,249))
		GetGlobal("bit1").SetVar("velx",0)
		GetGlobal("bit1").SetVar("vely",0)
		SetGlobal("bit2",CreateProjectileAbs("bit_2",200,400))
		GetGlobal("bit2").SetVar("velx",0)
		GetGlobal("bit2").SetVar("vely",1)
		SetGlobal("bit3",CreateProjectileAbs("bit_3",479,389.5))
		GetGlobal("bit3").SetVar("velx",1)
		GetGlobal("bit3").SetVar("vely",2)
		SetGlobal("bit4",CreateProjectileAbs("bit_4",515,196))
		GetGlobal("bit4").SetVar("velx",2)
		GetGlobal("bit4").SetVar("vely",3)
		SetGlobal("bit5",CreateProjectileAbs("bit_5",485,112))
		GetGlobal("bit5").SetVar("velx",1)
		GetGlobal("bit5").SetVar("vely",2)
		SetGlobal("bit6",CreateProjectileAbs("bit_6",144,126))
		GetGlobal("bit6").SetVar("velx",-1)
		GetGlobal("bit6").SetVar("vely",1)
		dog.SendToTop()
	elseif introphase == 4 and introtimer ~= nil and introtimer >= 750 and introtimer < 900 then
		if dog ~= nil and GetGlobal("bit1") ~= nil and GetGlobal("bit2") ~= nil and GetGlobal("bit3") ~= nil and GetGlobal("bit4") ~= nil then
			if GetGlobal("bit5") ~= nil and GetGlobal("bit6") ~= nil then
				dog.SetVar("velx",dog.GetVar("velx") + 0.04)
				dog.SetVar("vely",dog.GetVar("vely") - 0.12)
				dog.Move(dog.GetVar("velx"),dog.GetVar("vely"))
				if introtimer%2 == 0 then
					dog.sprite.rotation = dog.sprite.rotation - 1
				end
				GetGlobal("bit1").SetVar("velx",GetGlobal("bit1").GetVar("velx") - 0.04)
				GetGlobal("bit1").SetVar("vely",GetGlobal("bit1").GetVar("vely") - 0.12)
				GetGlobal("bit1").Move(GetGlobal("bit1").GetVar("velx"),GetGlobal("bit1").GetVar("vely"))
				if introtimer%2 == 0 then
					GetGlobal("bit1").sprite.rotation = GetGlobal("bit1").sprite.rotation + 1
				end
				GetGlobal("bit2").SetVar("velx",GetGlobal("bit2").GetVar("velx") + 0.02)
				GetGlobal("bit2").SetVar("vely",GetGlobal("bit2").GetVar("vely") - 0.12)
				GetGlobal("bit2").Move(GetGlobal("bit2").GetVar("velx"),GetGlobal("bit2").GetVar("vely"))
				if introtimer%3 == 0 then
					GetGlobal("bit2").sprite.rotation = GetGlobal("bit2").sprite.rotation + 1
				end
				GetGlobal("bit3").SetVar("velx",GetGlobal("bit3").GetVar("velx") + 0.02)
				GetGlobal("bit3").SetVar("vely",GetGlobal("bit3").GetVar("vely") - 0.12)
				GetGlobal("bit3").Move(GetGlobal("bit3").GetVar("velx"),GetGlobal("bit3").GetVar("vely"))
				if introtimer%2 == 0 then
					GetGlobal("bit3").sprite.rotation = GetGlobal("bit3").sprite.rotation - 1
				end
				GetGlobal("bit4").SetVar("velx",GetGlobal("bit4").GetVar("velx") - 0.04)
				GetGlobal("bit4").SetVar("vely",GetGlobal("bit4").GetVar("vely") - 0.12)
				GetGlobal("bit4").Move(GetGlobal("bit4").GetVar("velx"),GetGlobal("bit3").GetVar("vely"))
				if introtimer%1 == 0 then
					GetGlobal("bit4").sprite.rotation = GetGlobal("bit4").sprite.rotation - 1
				end
				GetGlobal("bit5").SetVar("velx",GetGlobal("bit5").GetVar("velx") - 0.04)
				GetGlobal("bit5").SetVar("vely",GetGlobal("bit5").GetVar("vely") - 0.12)
				GetGlobal("bit5").Move(GetGlobal("bit5").GetVar("velx"),GetGlobal("bit5").GetVar("vely"))
				if introtimer%3 == 0 then
					GetGlobal("bit5").sprite.rotation = GetGlobal("bit5").sprite.rotation + 1
				end
				GetGlobal("bit6").SetVar("velx",GetGlobal("bit6").GetVar("velx") - 0.04)
				GetGlobal("bit6").SetVar("vely",GetGlobal("bit6").GetVar("vely") - 0.12)
				GetGlobal("bit6").Move(GetGlobal("bit5").GetVar("velx"),GetGlobal("bit6").GetVar("vely"))
				if introtimer%2 == 0 then
					GetGlobal("bit6").sprite.rotation = GetGlobal("bit6").sprite.rotation + 1
				end
			end
		end
	elseif introtimer == 901 then
		introtimer = 902
	end
	if introtimer ~= nil and introtimer%5 == 0 then
		State("DIALOGRESULT")
	end
	if introtimer == 902 then
		dog.Remove()
		GetGlobal("bit1").Remove()
		GetGlobal("bit2").Remove()
		GetGlobal("bit3").Remove()
		GetGlobal("bit4").Remove()
		GetGlobal("bit5").Remove()
		GetGlobal("bit6").Remove()
		Audio.Play()
		introtimer = nil
		--BattleDialog({"[starcolor:000000][noskip][next]"})
		encountertext = RandomEncounterText()
		State("ENEMYDIALOGUE")
	end
end

function OnHit(bullet)
end

function EncounterStarting()
	Audio.Stop()
	error = CreateProjectileAbs("fake_error",320,240)
	dog = CreateProjectileAbs("dog",580,60)
	State("DIALOGRESULT")
end

function EnemyDialogueStarting()
    -- Good location for setting monster dialogue depending on how the battle is going.
end

function EnemyDialogueEnding()
    -- Good location to fill the 'nextwaves' table with the attacks you want to have simultaneously.
    -- This example line below takes a random attack from 'possible_attacks'.
    nextwaves = { possible_attacks[math.random(#possible_attacks)] }
end

function DefenseEnding() --This built-in function fires after the defense round ends.
    encountertext = RandomEncounterText() --This built-in function gets a random encounter text from a random enemy.
end

function HandleSpare()
     State("ENEMYDIALOGUE")
end

function HandleItem(ItemID)
    BattleDialog({"Selected item " .. ItemID .. "."})
end