bubble = CreateSprite("UI/SpeechBubbles/intro_textbox")
bubble.MoveTo(32,394)
bubble.SetPivot(0,0.5)
bubble.alpha = 0

letters = {}
alphabet = {{"a"},{"b"},{"c"},{"d"},{"e"},{"f"},{"g",-4},{"h"},{"i"},{"j",-4},{"k"},{"l"},{"m"},{"n"},{"o"},{"p",-4},{"q",-4},{"r"},{"s"},{"t"},{"u"},{"v"},{"w"},{"x"},{"y",-4},{"z"}}
ALPHABET = {{"A"},{"B"},{"C"},{"D"},{"E"},{"F"},{"G"},{"H"},{"I"},{"J"},{"K"},{"L"},{"M"},{"N"},{"O"},{"P"},{"Q",-2},{"R"},{"S"},{"T"},{"U"},{"V"},{"W"},{"X"},{"Y"},{"Z"}}
numbers = {"0","1","2","3","4","5","6","7","8","9"}
punctuation = {{"!"},{"#"},{"$"},{"%"},{"&"},{"("},{")"},{","},{"."},{"'",nil,6},{"-",nil,6},{";",nil,2},{"@"},{"["},{"]"},{"^",nil,6},{"_"},{"`",nil,6},{"{"},{"}"},{"~",nil,4},{"+",nil,4},{"=",nil,4},{"*","asterisk",4},{"\\","backward slash"},{":","colon",4},{"/","forward slash"},{"<","left arrow",2},{"?","question mark"},{"\"","quote",6},{">","right arrow",2},{"|","vertical bar",-2},{" ","space"}}

color = {1,1,1}
voice = "v_sans"
speed = 4

num = 0
wait = 0
dialognum = 0
lettertimer = 0
command_residue = 0 -- like dog residue, but left behind by commands!
lettertimeroffset = 0

function UpdateBubble()
	-- bubble.yscale = poseur.yscale
	-- for k,v in pairs(letters) do ; if v ~= nil then
		-- v.yscale = poseur.yscale
	-- end ; end
	if currentstate == "ENEMYDIALOGUE" then
		if wait == 0 then
			lettertimer = lettertimer + 1
			if lettertimer%speed == 0 and not done then ; num = num + 1 ; if letters[num] ~= nil then
				if not letters[num].GetVar("skip") then
					letters[num].sprite.color = color
					letters[num].sprite.alpha = 1
					Audio.PlaySound("Voices/"..voice)
					-- Player.MoveToAbs(letters[num].absx,letters[num].absy,true)
					-- Player.sprite.SendToTop()
				elseif letters[num].GetVar("skip") then
					if letters[num].GetVar("command") then
						HandleCommand(letters[num].GetVar("command"))
						while string.sub(enemies[1]["currentdialogue"][dialognum],num,num) ~= "]" and num < #letters do
							num = num + 1
						end
						if letters[num - 1] ~= nil then ; letters[num-1].sprite.alpha = 0 ; end
					end
					letters[num].Remove()
				end
			end ; end
			if (Input.Cancel == 1 and not noskip and not done) or instant then
				for k,v in pairs(letters) do ; if v.isactive then
					if not v.GetVar("skip") then
						v.sprite.color = color
						v.sprite.alpha = 1
					end
					if v.GetVar("skip") and v.GetVar("command") then
						HandleCommand(v.GetVar("command"))
					end
					if v.GetVar("skip") then ; v.Remove() ; end
				end ; end
				done = true
			end
			if num >= (#letters - lettertimeroffset) + 1 and not done then
				done = true
			end
			if done and (Input.Confirm == 1) or nextd then
				instant = nil
				nextd = nil
				noskip = nil
				done = nil
				if enemies[1]["currentdialogue"][dialognum + 1] ~= nil then
					for k,v in pairs(letters) do ; if v.isactive then ; v.Remove() ; end ; end ; letters = {}
					ActivateFakeDialogue()
				else
					bubble.alpha = 0
					for k,v in pairs(letters) do ; if v.isactive then ; v.Remove() ; end ; end ; letters = {}
					nextwaves = oldwaves
					oldwaves = nil
					wavetimer = oldwavetimer
					oldwavetimer = nil
					State("DEFENDING")
					dialognum = 0
				end
			end
		else
			wait = wait - 1
		end
	end
end

function ActivateFakeDialogue()
	color = {1,1,1}
	speed = 4 ; if bg ~= nil then ; speed = 2 ; end
	dialognum = dialognum + 1
	lettertimer = 0
	lettertimeroffset = 0
	command_residue = 0
	bubble.alpha = 1
	bubble.SendToBottom()
	num = 0
	local line = 1
	local linerewind = 0 -- because it rhymes
	for j=1,#enemies[1]["currentdialogue"][dialognum] do
		if num < #enemies[1]["currentdialogue"][dialognum] and command_residue == 0 then
			num = num + 1
		end
		local character = string.sub(enemies[1]["currentdialogue"][dialognum],num,num)
		local yoffset = 0
		for i=1,#alphabet do
			if character == alphabet[i][1] then
				character = "lowercase/"..character
				if alphabet[i][2] ~= nil then
					yoffset = alphabet[i][2]
					if bg ~= nil then ; yoffset = yoffset * 2 ; end
				end
				break
			end
		end
		for i=1,#ALPHABET do
			if character == ALPHABET[i][1] then
				character = "capital/"..character
				if ALPHABET[i][2] ~= nil then
					yoffset = ALPHABET[i][2]
					if bg ~= nil then ; yoffset = yoffset * 2 ; end
				end
				break
			end
		end
		for i=1,#numbers do
			if character == numbers[i] then
				character = "numbers/"..character
				break
			end
		end
		for i=1,#punctuation do
			if character == punctuation[i][1] then
				if punctuation[i][2] ~= nil then
					character = "punctuation/"..punctuation[i][2]
				else
					character = "punctuation/"..character
				end
				if punctuation[i][3] ~= nil then
					yoffset = punctuation[i][3]
					if bg ~= nil then ; yoffset = yoffset * 2 ; end
				end
				break
			end
		end
		local xpos = 430 + ((num - linerewind)*10) ; if bg ~= nil then ; xpos = (xpos - 264) + ((num - linerewind)*6.5) ; end
		local ypos = 186 ; if bg ~= nil then ; ypos = ypos - 280 ; end
		local linescale = 16 ; if bg ~= nil then ; linescale = 36 ; end
		local letter = CreateProjectileAbs("sans/"..character,xpos,ypos + bubble.y + (bubble.yscale*bubble.height) - (line*linescale) + yoffset)
		if bg ~= nil and string.sub(character,-1,-1) ~= "]" then ; letter.sprite.Scale(2,2) ; end
		if command_residue == 0 then
			letter.sprite.Set("sans/"..character)
			letter.SetVar("character",string.sub(character,-1,-1))
			letter.sprite.SetPivot(0.5,0)
			letter.sprite.alpha = 0
			if string.sub(enemies[1]["currentdialogue"][dialognum],num,num) == " " then
				letter.SetVar("skip",true)
			end
			if string.sub(enemies[1]["currentdialogue"][dialognum],num,num) == "\n" or string.sub(enemies[1]["currentdialogue"][dialognum],num,num) == "\r" then
				line = line + 1
				linerewind = num
				letter.SetVar("skip",true)
			end
			if string.sub(enemies[1]["currentdialogue"][dialognum],num,num) == "\v" then
				linerewind = linerewind - 1
				letter.SetVar("skip",true)
			end
			if string.sub(enemies[1]["currentdialogue"][dialognum],j,j) == "[" then
				for i=j,#enemies[1]["currentdialogue"][dialognum] do
					if string.sub(enemies[1]["currentdialogue"][dialognum],i,i) == "]" then
						letter.SetVar("command",string.sub(enemies[1]["currentdialogue"][dialognum],j,i))
						local command = string.sub(enemies[1]["currentdialogue"][dialognum],j,i)
						num = i
						command_residue = #command - 1
						linerewind = linerewind + #command
						letter.SetVar("skip",true)
						HandleCommand(command,true)
						break
					end
				end
			end
		else
			command_residue = command_residue - 1
			letter.SetVar("skip",true)
			letter.sprite.alpha = 0
		end
		letter.sprite.SendToTop()
		table.insert(letters,letter)
	end
	if dialognum == 1 then
		oldwaves = nextwaves
		nextwaves = {}
		oldwavetimer = wavetimer
		wavetimer = math.huge
		State("DEFENDING")
		Player.SetControlOverride(true)
	end
	num = 0
end

function HandleCommand(command,static)
	-- DEBUG(math.floor(Time.time).." "..command)
	if static then
		if command == "[instant]" then
			instant = true
		elseif command == "[novoice]" then
			voice = "uifont"
		end
		return
	end
	if string.sub(command,1,7) == "[debug:" then
		DEBUG(string.sub(command,8,-2))
	elseif string.sub(command,1,7) == "[voice:" then
		voice = string.sub(command,8,-2)
	elseif string.sub(command,1,7) == "[speed:" then
		speed = tonumber(string.sub(command,8,-2))
	elseif string.sub(command,1,6) == "[wait:" then
		wait = tonumber(string.sub(command,7,-2))
	elseif string.sub(command,1,3) == "[w:" then
		wait = tonumber(string.sub(command,4,-2))
	elseif string.sub(command,1,7) == "[color:" then
		color = {tonumber(string.sub(command,8,10))/255,tonumber(string.sub(command,12,14)/255),tonumber(string.sub(command,16,18))/255}
	elseif string.sub(command,1,8) == "[bubble:" then
		bubble.Set("UI/SpeechBubbles/"..string.sub(command,9,-2))
	elseif string.sub(command,1,6) == "[func:" then -- can only send arguments as a single string. sorry!
		for i=7,#command do
			if string.sub(command,i,i) == "," then
				enemies[1].Call(string.sub(command,7,i-1),string.sub(command,i+1,-2))
				return
			end
		end
		enemies[1].Call(string.sub(command,7,-2))
	elseif command == "[next]" then
		nextd = true
	elseif command == "[noskip]" then
		noskip = true
	end
end