State("DIALOGRESULT")
timer = 0
bg = CreateProjectileAbs("intro_bg",320,240)
bg.SetVar("safe",true)
bg.sprite.Set("intro_bg")
bg.sprite.color = {0,0,0}
chara = CreateProjectileAbs("intro_chara/chara (1)",119,179)
chara.sprite.Set("intro_chara/chara (1)")
chara.sprite.Scale(2,2)
chara.sprite.color = {0,0,0}
chara.SendToTop()
function AnimateIntro()
	timer = timer + 1
	if timer < 20 then
		bg.sprite.color = {(timer/20), (timer/20), (timer/20)}
	elseif timer == 50 then
		bg.sprite.Set("intro_bg_textbox")
		require "Libraries/dialogue/pre-fight dialogue"
	end
	if enemies[1]["player_walk"] ~= nil then
		if walktimer == nil then
			walktimer = timer
			chara.sprite.Set("intro_chara/chara (2)")
			bg.sprite.Set("intro_bg")
		end
		if timer-walktimer <= 20 then
			chara.Move(0.5*Time.mult,0)
		elseif timer-walktimer == 21 then
			chara.sprite.Set("intro_chara/chara (1)")
		elseif timer-walktimer == 60 then
			bg.sprite.Set("intro_bg_textbox")
			walktimer = nil
			enemies[1]["player_walk"] = nil
		end
	end
	if enemies[1]["animate_soul"] ~= nil then
		if soul_timer == nil then
			soul_timer = timer
			Player.MoveToAbs(121, 165, true)
			chara.Remove()
			bg.sprite.Set("UI/sq_white")
			bg.sprite.Scale(640/4,480/4)
			bg.sprite.color = {0,0,0}
			Player.sprite.SendToTop()
		end
		local time = (timer - soul_timer)
		if time == 5 or time == 14 then
			Player.sprite.alpha = 1
			Audio.PlaySound("flicker")
		elseif time == 0 or time == 10 then
			Player.sprite.alpha = 0
		elseif time == 20 then
			Audio.PlaySound("enter battle")
		end
		if time >= 20 and time < 35 then
			Player.MoveToAbs(121 - (((time-20)/15)*(121-48)),165 - (((time-20)/15)*(165-25)),true)
		end
		if time >= 45 and time < 50 then
			Player.sprite.alpha = Player.sprite.alpha - 0.2
		end
		if time == 55 then
			error("The rest of the battle is not done!\nCome back later, maybe.")
		end
	end
end