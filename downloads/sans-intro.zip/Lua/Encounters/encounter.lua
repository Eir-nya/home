currentstate = "NONE"
encountertext = "You feel like you're going\rto have a bad time."
nextwaves = {}
wavetimer = 4.0
arenasize = {155, 130}

enemies = {
"sans"
}

enemypositions = {
{0, 0}
}

function Update()
	UpdateBubble()
	AnimateIntro()
end

function OnHit(bullet)
	if not bullet.GetVar("safe") then
		Player.Hurt(3)
	end
end

function EnteringState(newstate, oldstate)
	currentstate = newstate
	if newstate == "ENEMYDIALOGUE" then
		ActivateFakeDialogue()
	end
end

function EncounterStarting()
	require "Animations/intro"
	require "Animations/anim"
	SetGlobal("speech_count",0)
	
    Audio.Stop()
	SetGlobal("deaths",0)
	SetGlobal("dunks",0)
	SetGlobal("victories",0)
	SetGlobal("spares_player",0)
end

function DefenseEnding()
    encountertext = RandomEncounterText()
end
function HandleSpare()
     State("ENEMYDIALOGUE")
end
function HandleItem(ItemID)
    BattleDialog({"Selected item " .. ItemID .. "."})
end