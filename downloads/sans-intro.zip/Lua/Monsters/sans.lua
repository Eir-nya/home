sprite = "blank"
name = "Sans"
dialogbubble = "intro_textbox"




-- ...what? were you expecting something more?




































-- alright, fine.

intro_face = CreateSprite("intro_face/face (1)")
intro_face.MoveTo(102,399)
lastface = "face (1)"
function SetIntroFace(face)
	intro_face.Set("intro_face/"..face)
end
function IntroPlayerStep()
	player_walk = 10
end
function IntroAnimateSoul()
	animate_soul = true
end
function SetFace(face)
	lastface = face
end