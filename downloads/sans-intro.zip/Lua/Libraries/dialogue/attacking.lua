local count = attacks
local dialogue = {}
if count == 0 then
	dialogue = {
	"what?[w:10]\n you think i'm just\ngonna stand there\nand take it?"
	}
elseif count == 1 then
	dialogue = {
	"our reports showed\na massive anomaly\nin the timespace\ncontinuum.",
	"timelines jumping\nleft and right,\nstopping and\nstarting..."
	}
elseif count == 2 then
	dialogue = {
	"[noskip][func:SetFace,face (5)][next]",
	"until suddenly,[w:20]\neverything ends.",
	"[noskip][func:SetFace,face (1)][next]"
	}
elseif count == 3 then
	dialogue = {
	"[noskip][func:SetFace,face (5)][next]",
	"heh heh heh...",
	"[noskip][func:SetFace,face (6)][next]",
	"that's your fault,[w:20]\nisn't it?",
	"[noskip][func:SetFace,face (1)][next]"
	}
elseif count == 4 then
	dialogue = {
	"[noskip][func:SetFace,face (2)][next]",
	"you can't understand\nhow this feels.",
	"[noskip][func:SetFace,face (1)][next]"
	}
elseif count == 5 then
	dialogue = {
	"[noskip][func:SetFace,face (5)][next]",
	"knowing that one\nday,[w:20] without any\nwarning...",
	"[noskip][func:SetFace,face (10)][next]",
	"it's all going to\nbe reset.",
	"[noskip][func:SetFace,face (1)][next]"
	}
elseif count == 6 then
	dialogue = {
	"[noskip][func:SetBody,torso (2)][func:SetFace,face (10)][next]",
	"look.[w:20]\ni gave up trying\nto go back a long\ntime ago.",
	"[noskip][func:SetBody,torso (1)][func:SetFace,face (1)][next]"
	}
elseif count == 7 then
	dialogue = {
	"[noskip][func:SetBody,torso (2)][func:SetFace,face (5)][next]",
	"and getting to the\nsurface doesn't\nreally appeal\nanymore,[w:20] either.",
	"[noskip][func:SetBody,torso (1)][func:SetFace,face (1)][next]"
	}
elseif count == 8 then
	dialogue = {
	"[noskip][func:SetBody,torso (2)][func:SetFace,face (5)][next]",
	"cause even if we\ndo...",
	"[noskip][func:SetFace,face (6)][next]",
	"we'll just end up\nright back here,[w:20]\nwithout any memory\nof it,[w:20] right?",
	"[noskip][func:SetBody,torso (1)][func:SetFace,face (1)][next]"
	}
elseif count == 9 then
	dialogue = {
	"[noskip][func:SetBody,torso (2)][func:SetFace,face (2)][next]",
	"to be blunt...",
	"[noskip][func:SetFace,face (5)][next]",
	"it makes it kind\nof hard to give\nit my all.",
	"[noskip][func:SetBody,torso (1)][func:SetFace,face (1)][next]"
	}
elseif count == 10 then
	dialogue = {
	"[noskip][func:SetBody,torso (2)][func:SetFace,face (2)][next]",
	"... or is that just\na poor excuse for\nbeing lazy...?",
	"[noskip][func:SetFace,face (4)][next]",
	"hell if i know.",
	"[noskip][func:SetBody,torso (1)][func:SetFace,face (1)][next]"
	}
elseif count == 11 then
	dialogue = {
	"[noskip][func:SetBody,torso (2)][func:SetFace,face (5)][next]",
	"all i know is...[w:20]\nseeing what comes\nnext...",
	"[noskip][func:SetFace,face (10)][next]",
	"i can't afford not\nto care anymore."
	"[noskip][func:SetBody,torso (1)][func:SetFace,face (1)][next]"
	}
elseif count == 12 then
	SetGlobal("spares_player",GetGlobal("spares_player") + 1)
	if GetGlobal("spares_player") == 1 then
		dialogue = {
		"[noskip][func:SetFace,face (10)][func:SetSweat,sweat (3)][func:StopMusic][next]",
		"ugh...[w:15]\nthat being said...",
		"[noskip][func:SetFace,face (2)][next]",
		"you,[w:15] uh,[w:15] really\nlike swinging that\nthing around,[w:15]\nhuh?",
		"[noskip][func:SetFace,face (1)][func:PlayMusc,the_choice][next]",
		"...",
		"[noskip][func:SetFace,face (5)][next]",
		"listen.",
		"i know you didn't\nanswer me before,[w:15]\nbut...",
		"somewhere in\nthere.[w:20]\ni can feel it.",
		"[noskip][func:SetFace,face (1)][next]",
		"there's a glimmer\nof a good person\ninside of you.",
		"[noskip][func:SetFace,face (5)][next]",
		"the memory of\nsomeone who once\nwanted to do the\nright thing.",
		"[noskip][func:SetFace,face (2)][next]",
		"someone who,[w:20] in\nanother time,[w:20]\nmight have even\nbeen...",
		"[noskip][func:SetFace,face (5)][next]",
		"a friend?",
		"[noskip][func:SetFace,face (4)][next]",
		"c'mon,[w:20] buddy.",
		"[noskip][func:SetFace,face (1)][next]",
		"do you remember\nme?",
		"[noskip][func:SetFace,face (5)][next]",
		"please,[w:20] if you're\nlistening...",
		"[noskip][func:SetFace,face (10)][next]",
		"let's forget all\nthis, ok?",
		"[noskip][func:SetFace,face (4)][next]",
		"just lay down\nyour weapon,[w:20] and...",
		"[noskip][func:SetFace,face (5)][next]",
		"well,[w:20] my job\nwill be a lot\neasier.",
		"[noskip][func:SetFace,face (1)][next]"
		}
	elseif GetGlobal("spares_player") == 2 then
		dialogue = {
		"[noskip][func:SetFace,face (10)][func:SetSweat,sweat (3)][func:StopMusic][next]",
		"ugh...[w:15]\nthat being said...",
		"[noskip][func:SetFace,face (2)][next]",
		"you,[w:15] uh,[w:15] really\nlike swinging that\nthing around,[w:15]\nhuh?",
		"[noskip][func:SetFace,face (1)][func:PlayMusc,the_choice][next]",
		"...",
		"[noskip][func:SetFace,face (5)][next]",
		"listen.",
		"friendship...",
		"[noskip][func:SetFace,face (4)][next]",
		"it's really great,[w:20]\nright?",
		"let's quit fighting.",
		"[noskip][func:SetFace,face (1)][next]"
		}
	end
elseif count == 13 then
	if GetGlobal("dunked") then
		SetGlobal("dunked",nil)
		dialogue = {
		"[noskip][func:SetBody,torso (2)][func:SetFace,face (4)][next]",
		"whoa,[w:20] you look\nREALLY pissed off...",
		"[noskip][func:SetFace,face (5)][next]",
		"hehehe...",
		"[noskip][func:SetFace,face (6)][next]",
		"did i getcha?",
		"[noskip][func:SetFace,face (5)][next]",
		"well,[w:20] if you came\nback anyway...",
		"[noskip][func:SetFace,face (2)][next]",
		"i guess that means\nwe never really\nWERE friends,[w:20] huh?",
		"[noskip][func:SetFace,face (5)][next]",
		"huh.",
		"[noskip][func:SetFace,face (10)][next]",
		"don't tell that\nto the other\nsans-es,[w:20] ok?",
		"[noskip][func:SetBody,torso (1)][func:SetFace,face (1)][next]"
		}
	end
elseif count == 14 then
	dialogue = {
	"[noskip][func:SetFace,face (5)][next]",
	"sounds strange,[w:30] but\nbefore all this i\nwas secretly hoping\nwe could be friends.",
	"[noskip][func:SetFace,face (2)][next]"
	"i always thought the\nanomaly was doing\nthis cause they\nwere unhappy.",
	"and when they got\nwhat they wanted,[w:20]\nthey would stop\nall this."
	"[noskip][func:SetFace,face (1)][next]"
	}
elseif count == 15 then
	dialogue = {
	"[noskip][func:SetFace,face (4)][next]",
	"and maybe all they\nneeded was...[w:20]\ni dunno.",
	"some good food,[w:20]\nsome bad laughs,[w:20]\nsome nice friends.",
	"[noskip][func:SetFace,face (1)][next]"
	}
elseif count == 16 then
	dialogue = {
	"[noskip][func:SetFace,face (5)][next]",
	"but that's\nridiculous,[w:20]\nright?",
	"[noskip][func:SetFace,face (6)][next]",
	"yeah,[w:20] you're the\ntype of person\nwho won't EVER\nbe happy.",
	"[noskip][func:SetFace,face (1)][next]"
	}
elseif count == 17 then
	dialogue = {
	"[noskip][func:SetFace,face (6)][next]",
	"you'll keep\nconsuming timelines\nover and over,[w:20]\nuntil...",
	"[noskip][func:SetFace,face (5)][next]",
	"well.",
	"[noskip][func:SetBody,torso (2)][next]",
	"hey.",
	"[noskip][func:SetFace,face (4)][next]",
	"take it from me,[w:20]\nkid.",
	"someday...",
	"you gotta learn\nwhen to QUIT.",
	"[noskip][func:SetFace,face (1)][func:SetBody,torso (1)][next]"
	}
elseif count == 18 then
	dialogue = {
	"[noskip][func:SetFace,face (4)][next]",
	"and that day's\nTODAY.",
	"[noskip][func:SetFace,face (1)][next]"
	}
elseif count == 19 then
	dialogue = {
	"[noskip][func:SetFace,face (5)][func:SetSweat,sweat (2)][next]",
	"cause...[w:15]\ny'see...",
	"[noskip][func:SetFace,face (2)][next]",
	"all this fighting\nis really tiring\nme out.",
	"[noskip][func:SetFace,face (1)][next]"
	}
elseif count == 20 then
	dialogue = {
	"[noskip][func:SetFace,face (5)][next]",
	"and if you keep\npushing me...",
	"[noskip][func:SetFace,face (4)][next]",
	"then i'll be\nforced to use my\n[color:255,000,000]special attack[color:000,000,000].",
	"[noskip][func:SetFace,face (1)][next]"
	}
elseif count == 21 then
	dialogue = {
	"[noskip][func:SetFace,face (4)][next]",
	"yeah,[w:25] my [color:255,000,000]special\nattack[color:000,000,000].\nsound familiar?",
	"[noskip][func:SetFace,face (2)][next]",
	"well,[w:20] get ready.[w:20]\ncause after the\nnext move,[w:20] i'm\ngoing to [color:255,000,000]use it[color:000,000,000].",
	"[noskip][func:SetFace,face (4)][next]",
	"so,[w:20] if you don't\nwanna see it,[w:20] now\nwould be a good\ntime to die.",
	"[noskip][func:SetFace,face (1)][func:SetSweat,sweat (3)][next]"
	}
elseif count == 22 then
	dialogue = {
	"[noskip][func:SetFace,face (5)][func:SetSweat,sweat (4)][next]",
	"well,[w:15] here goes\nnothing...",
	"[noskip][func:SetFace,face (4)][next]",
	"are you ready?",
	"[noskip][func:SetFace,face (6)][next]",
	"survive THIS,[w:20] and\ni'll show you my\n[color:255,000,000]special attack[color:000,000,000]!",
	"[noskip][func:SetFace,face (1)][next]"
	}
end
enemies[1]["currentdialogue"] = dialogue
State("ENEMYDIALOGUE")