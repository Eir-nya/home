local count = GetGlobal("speech_count")
local dialogue = {}
if count == 0 then
	dialogue = {
	"[noskip][speed:6]it's a beautiful day\noutside.",
	"[noskip][speed:6]birds are singing,[w:20]\nflowers are\nblooming.",
	"[noskip][speed:6]on days like these,[w:20]\nkids like you...",
	"[noskip][func:IntroToggleCover,40][w:40][next]",
	"[noskip][func:IntroToggleCover,10][w:10][next]",
	"[noskip][novoice][speed:12]Should\nbe\nburning\nin hell."
	}
elseif count == 1 then
	dialogue = {
	"[noskip][speed:6]it's a beautiful day\noutside.",
	"[noskip][speed:6]birds are singing,[w:20][next]",
	"[noskip][func:IntroToggleCover,5][w:5][next]",
	"[noskip][func:IntroToggleCover,0][next]"
	}
elseif count >= 2 then
	dialogue = {
	"[noskip]ready?",
	"[noskip][func:IntroToggleCover,5][w:5][next]",
	"[noskip][func:IntroToggleCover,0][next]"
	}
end
enemies[1]["currentdialogue"] = dialogue
State("ENEMYDIALOGUE")