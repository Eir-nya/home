local dialogue = {}
dialogue = {
"[noskip][func:SetFace,face (4)][next]",
"heh,[w:5] did you"
}
enemies[1]["currentdialogue"] = dialogue
State("ENEMYDIALOGUE")