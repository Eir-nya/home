local deaths = GetGlobal("deaths")
local victories = GetGlobal("victories")
local pause_time = 60
local dialogue = {}
if victories == 0 then
	if deaths == 0 then
		dialogue = {
		"* heya.",
		"[noskip][func:SetIntroFace,face (2)][next]",
		"* you've been busy,[w:20]\n\vhuh?",
		"* ...",
		"[noskip][func:SetIntroFace,face (1)][next]",
		"* so,[w:16] i've got a\n\vquestion for ya.",
		"[noskip][func:SetIntroFace,face (3)][next]",
		"* do you think even\n\vthe worst person\n  can change...?",
		"* that everybody can be\n\va good person,[w:16] if\n\vthey just try?",
		"[noskip][novoice][func:IntroPlayerStep][w:"..pause_time.."][voice:v_sans][next]",
		"* heh heh heh heh...",
		"[noskip][func:SetIntroFace,face (2)][next]",
		"* all right.",
		"[noskip][func:SetIntroFace,face (3)][next]",
		"* well,[w:15] here's a better\n\vquestion.",
		"[noskip][func:SetIntroFace,face (4)][next]",
		"* do you wanna have\n\va bad time?",
		"[noskip][func:SetIntroFace,face (3)][next]",
		"* 'cause if you take\n\vanother step forward...",
		"[noskip][func:SetIntroFace,face (4)][next]",
		"* you are REALLY not\n\vgoing to like what\n\vhappens next.",
		"[noskip][novoice][func:IntroPlayerStep][w:"..pause_time.."][func:SetIntroFace,face (3)][voice:v_sans][next]",
		"* welp.",
		"* sorry,[w:15] old lady.",
		"* this is why i never\n\vmake promises."
		}
	elseif deaths == 1 then
		dialogue = {
		"* heya.",
		"[noskip][func:SetIntroFace,face (2)][next]",
		"* you look frustrated\n\vabout something.",
		"[noskip][func:SetIntroFace,face (4)][next]",
		"* guess i'm pretty good\n\vat my job,[w:15] huh?"
		}
	elseif deaths == 2 then
		dialogue = {
		"* hmm.[w:10]\n* that expression...",
		"[noskip][func:SetIntroFace,face (2)][next]",
		"* that's the expression\n\vof someone who's died\n\vtwice in a row.",
		"[noskip][func:SetIntroFace,face (5)][next]",
		"* suffice to say,[w:15] you\n\vlook really...[w:15]\n* unsatisfied.",
		"[noskip][func:SetIntroFace,face (3)][next]",
		"* all right.",
		"[noskip][func:SetIntroFace,face (4)][next]",
		"* how 'bout we make it\n\va third?"
		}
	elseif deaths == 3 then
		dialogue = {
		"* hmm.[w:10]\n* that expression...",
		"[noskip][func:SetIntroFace,face (2)][next]",
		"* that's the expression\n\vof someone who's died\n\vthrice in a row.",
		"[noskip][func:SetIntroFace,face (3)][next]",
		"* ...",
		"[noskip][func:SetIntroFace,face (2)][next]",
		"* hey,[w:10] what comes after\n\v[w:3]\"thrice\"[w:3], anyway?",
		"[noskip][func:SetIntroFace,face (4)][next]",
		"* wanna help me find out?"
		}
	elseif deaths == 4 then
		dialogue = {
		"* hmm.[w:10]\n* that expression...",
		"[noskip][func:SetIntroFace,face (2)][next]",
		"* that's the expression\n\vof someone who's died\n\vquice in a row.",
		"* quice?[w:5]\n* frice?",
		"[noskip][func:SetIntroFace,face (4)][next]",
		"* welp,[w:5] won't have to\n\vuse it again anyways."
		}
	elseif deaths == 5 then
		dialogue = {
		"* hmm.[w:10]\n* that expression...",
		"[noskip][func:SetIntroFace,face (2)][next]",
		"* that's the expression\n\vof someone who's died\n\vfive times in a row.",
		"[noskip][func:SetIntroFace,face (5)][next]",
		"* convenient,[w:5] huh?[w:5]\n* that's one for each\n\vfinger.",
		"[noskip][func:SetIntroFace,face (3)][next]",
		"* but soon..."
		-- "[noskip][func:SetIntroFace,face (4)][next]",
		-- "* you'll need a cool\n\vmutant hand to count\n\vall of your deaths."
		}
	elseif deaths == 6 then
		dialogue = {
		"* hmm.[w:10]\n* that expression...",
		"[noskip][func:SetIntroFace,face (2)][next]",
		"* that's the expression\n\vof someone who's died\n\vsix times in a row.",
		"[noskip][func:SetIntroFace,face (5)][next]",
		"* that's the number of\n\vfingers on a mutant\n\vhand.",
		"[noskip][func:SetIntroFace,face (3)][next]",
		"* but soon..."
		-- "[noskip][func:SetIntroFace,face (4)][next]",
		-- "* you'll need to find\n\va mutant hand with\n\veven more fingers."
		}
	elseif deaths == 7 then
		dialogue = {
		"* hmm.[w:10]\n* that expression...",
		"[noskip][func:SetIntroFace,face (2)][next]",
		"* that's the expression\n\vof someone who's died\n\vseven times in a row.",
		"[noskip][func:SetIntroFace,face (1)][next]",
		"* hey,[w:10] that's good.\n* seven's supposed to be\n\va lucky number.",
		"[noskip][func:SetIntroFace,face (5)][next]",
		"* who knows,[w:10] maybe\n\vyou'll hit the\n\vjackpot...",
		-- "[noskip][func:SetIntroFace,face (4)][next]",
		-- "* and that number will\n\vmultiply tenfold."
		}
	elseif deaths == 8 then
		dialogue = {
		"* hmm.[w:10]\n* that expression...",
		"[noskip][func:SetIntroFace,face (2)][next]",
		"* that's the expression\n\vof someone who's died\n\veight times in a row.",
		"[noskip][func:SetIntroFace,face (5)][next]",
		"* that's the number of\n\vfingers on a spider.",
		"[noskip][func:SetIntroFace,face (3)][next]",
		"* but soon..."
		-- "[noskip][func:SetIntroFace,face (4)][next]",
		-- "* wait,[w:10] don't spiders\n\vhave legs?"
		}
	elseif deaths == 9 then
		dialogue = {
		"* hmm.[w:10]\n* that expression...",
		"[noskip][func:SetIntroFace,face (2)][next]",
		"* that's the expression\n\vof someone who's died\n\vseven times in a row.",
		"* ...",
		"[noskip][func:SetIntroFace,face (5)][next]",
		"* nope,[w:10] wait,[w:10] that's\n\vdefinitely nine,[w:10] sorry.",
		"[noskip][func:SetIntroFace,face (4)][next]",
		"* or was it ten?"
		}
	elseif deaths == 10 then
		dialogue = {
		"* hmm.[w:10]\n* that expression...",
		"[noskip][func:SetIntroFace,face (2)][next]",
		"* that's the expression\n\vof someone who's died\n\vten times in a row.",
		"[noskip][func:SetIntroFace,face (5)][next]",
		"* hey,[w:10] congrats![w:10]\n* the big one-oh!",
		"[noskip][func:SetIntroFace,face (2)][next]",
		"* let's invite all your\n\vfriends over for a\n\vbid shindig.",
		"[noskip][func:SetIntroFace,face (5)][next]",
		"* we can have pie,[w:10] and\n\vhot dogs,[w:10] and...",
		"[noskip][func:SetIntroFace,face (3)][next]",
		"* hmmm...[w:3]wait.[w:5]\n* something's not right.",
		"[noskip][func:SetIntroFace,face (4)][next]",
		"* you don't have any\n\vfriends."
		}
	elseif deaths == 11 then
		dialogue = {
		"* hmm.[w:10]\n* that expression...",
		"[noskip][func:SetIntroFace,face (2)][next]",
		"* that's the expression\n\vof someone who's died\n\veleven times in a row.",
		"[noskip][func:SetIntroFace,face (5)][next]",
		"* well,[w:10] give or take.",
		"[noskip][func:SetIntroFace,face (2)][next]",
		"* there's nuance to\n\vthis stuff.",
		"[noskip][func:SetIntroFace,face (5)][next]",
		"* don't think i'll be\n\vable to count very\n\vwell from here.",
		"[noskip][func:SetIntroFace,face (2)][next]",
		"* count for me,[w:10] ok?",
		"[noskip][func:SetIntroFace,face (4)][next]",
		"* we'll start from 12."
		}
	elseif deaths >= 12 then
		dialogue = {
		"* let's just get to\n\vthe point."
		}
	end
elseif victories == 1 then
	
end
dialogue[#dialogue+1] = "[noskip][func:IntroAnimateSoul][w:100][next]"
enemies[1]["currentdialogue"] = dialogue
State("ENEMYDIALOGUE")