local count = GetGlobal("dunks")
local dialogue = {}
if count == 0 then
	"[noskip][func:StopMusic][next]",
	"[noskip][func:SetFace,face (5)][next]",
	"...",
	"you're sparing me?",
	"[noskip][func:SetFace,face (2)][next]",
	"finally.",
	"[noskip][func:SetFace,face (4)][next]",
	"buddy.[w:10]\npal.",
	"[noskip][func:SetFace,face (5)][next]",
	"i know how hard\nit must be...",
	"to make that\nchoice.",
	"to go back on\neverything you've\nworked up to.",
	"[noskip][func:SetFace,face (1)][next]",
	"i want you to\nknow...[w:20]\ni won't let it\ngo to waste.",
	"[noskip][func:SetBody,torso (2)][next]",
	"...",
	"[noskip][func:SetFace,face (4)][next]",
	"c'mere,[w:15] pal.",
	"[noskip][func:SetBody,torso (1)][SetFace,face (1)][next]"
end
enemies[1]["currentdialogue"] = dialogue
State("ENEMYDIALOGUE")