local count = GetGlobal("speech_count")
local dialogue = {}
if count == 0 then
	dialogue = {
	"[noskip][func:SetFace,face (2)][next]",
	"huh.",
	"always wondered why\npeople never use\ntheir strongest\nattack first."
	}
elseif count == 1 then
	dialogue = {
	"[noskip][func:SetFace,face (4)][next]",
	"[noskip]anyway,[w:10] as i was\nsaying,[w:10] it's a\nnice day out."
	"[noskip][func:SetBody,torso (2)][next]",
	"why not relax and\ntake a load off?",
	"[noskip][func:SetFace,face (1)][func:SetBody,torso (1)][next]",
	}
elseif count >= 2 then
	dialogue = {
	"here we go."
	}
end
enemies[1]["currentdialogue"] = dialogue
State("ENEMYDIALOGUE")